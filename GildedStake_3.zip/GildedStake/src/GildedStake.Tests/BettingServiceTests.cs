using GildedStake.Web.Data;
using GildedStake.Web.Models;
using GildedStake.Web.Models.Betting;
using GildedStake.Web.Models.Enums;
using GildedStake.Web.Services;
using GildedStake.Web.Services.Exceptions;
using Xunit;

namespace GildedStake.Tests;

public class BettingServiceTests
{
    private static async Task<(ApplicationDbContext ctx, Account account, BettingEvent evt, BettingSelection selectionA, BettingSelection selectionB)> SeedAsync(decimal openingBalance = 1000m)
    {
        var ctx = TestDbContextFactory.Create();

        var user = new User
        {
            FirstName = "Test",
            Surname = "Client",
            IdNumber = "9001015800086",
            Email = "test.client@example.com",
            PhoneNumber = "0821234567",
            DateOfBirth = new DateOnly(1990, 1, 1),
        };
        ctx.Users.Add(user);
        await ctx.SaveChangesAsync();

        var account = new Account { AccountNumber = "BET-ACC-1", AccountName = "Main", UserId = user.Id, Balance = openingBalance };
        ctx.Accounts.Add(account);
        await ctx.SaveChangesAsync();

        var evt = new BettingEvent
        {
            Name = "Test Stakes",
            Category = "Horse Racing",
            EventDateUtc = DateTime.UtcNow.AddDays(1),
            Status = EventStatus.Open,
            Selections = new List<BettingSelection>
            {
                new() { Name = "Runner A", Odds = 2.00m },
                new() { Name = "Runner B", Odds = 3.00m },
            },
        };
        ctx.BettingEvents.Add(evt);
        await ctx.SaveChangesAsync();

        var selectionA = evt.Selections.First(s => s.Name == "Runner A");
        var selectionB = evt.Selections.First(s => s.Name == "Runner B");

        return (ctx, account, evt, selectionA, selectionB);
    }

    [Fact]
    public async Task PlaceBetAsync_ValidBet_DeductsBalanceAndCreatesPendingBet()
    {
        var (ctx, account, _, selectionA, _) = await SeedAsync(openingBalance: 1000m);
        var service = new BettingService(ctx, TestDbContextFactory.Logger<BettingService>());

        var bet = await service.PlaceBetAsync(account.Id, selectionA.Id, 100m);

        Assert.Equal(BetStatus.Pending, bet.Status);
        Assert.Equal(200m, bet.PotentialPayout); // 100 * 2.00
        var reloaded = await ctx.Accounts.FindAsync(account.Id);
        Assert.Equal(900m, reloaded!.Balance);
    }

    [Fact]
    public async Task PlaceBetAsync_CreatesMatchingDebitTransaction()
    {
        var (ctx, account, evt, selectionA, _) = await SeedAsync(openingBalance: 1000m);
        var service = new BettingService(ctx, TestDbContextFactory.Logger<BettingService>());

        await service.PlaceBetAsync(account.Id, selectionA.Id, 100m);

        var transaction = ctx.Transactions.Single(t => t.AccountId == account.Id);
        Assert.Equal(GildedStake.Web.Models.Enums.TransactionType.Debit, transaction.Type);
        Assert.Equal(100m, transaction.Amount);
        Assert.Contains(evt.Name, transaction.Description);
    }

    [Fact]
    public async Task PlaceBetAsync_StakeExceedsBalance_ThrowsBusinessRuleException()
    {
        var (ctx, account, _, selectionA, _) = await SeedAsync(openingBalance: 50m);
        var service = new BettingService(ctx, TestDbContextFactory.Logger<BettingService>());

        await Assert.ThrowsAsync<BusinessRuleException>(() => service.PlaceBetAsync(account.Id, selectionA.Id, 100m));
    }

    [Fact]
    public async Task PlaceBetAsync_ZeroStake_ThrowsBusinessRuleException()
    {
        var (ctx, account, _, selectionA, _) = await SeedAsync();
        var service = new BettingService(ctx, TestDbContextFactory.Logger<BettingService>());

        await Assert.ThrowsAsync<BusinessRuleException>(() => service.PlaceBetAsync(account.Id, selectionA.Id, 0m));
    }

    [Fact]
    public async Task PlaceBetAsync_OnClosedAccount_ThrowsBusinessRuleException()
    {
        var (ctx, account, _, selectionA, _) = await SeedAsync();
        account.IsClosed = true;
        await ctx.SaveChangesAsync();
        var service = new BettingService(ctx, TestDbContextFactory.Logger<BettingService>());

        await Assert.ThrowsAsync<BusinessRuleException>(() => service.PlaceBetAsync(account.Id, selectionA.Id, 10m));
    }

    [Fact]
    public async Task PlaceBetAsync_OnClosedMarket_ThrowsBusinessRuleException()
    {
        var (ctx, account, evt, selectionA, _) = await SeedAsync();
        await new BettingService(ctx, TestDbContextFactory.Logger<BettingService>()).CloseEventAsync(evt.Id);
        var service = new BettingService(ctx, TestDbContextFactory.Logger<BettingService>());

        await Assert.ThrowsAsync<BusinessRuleException>(() => service.PlaceBetAsync(account.Id, selectionA.Id, 10m));
    }

    [Fact]
    public async Task SettleEventAsync_WinningSelection_CreditsPayoutAndMarksWon()
    {
        var (ctx, account, evt, selectionA, selectionB) = await SeedAsync(openingBalance: 1000m);
        var service = new BettingService(ctx, TestDbContextFactory.Logger<BettingService>());
        var bet = await service.PlaceBetAsync(account.Id, selectionA.Id, 100m); // balance now 900, payout would be 200

        await service.SettleEventAsync(evt.Id, selectionA.Id);

        var reloadedAccount = await ctx.Accounts.FindAsync(account.Id);
        Assert.Equal(1100m, reloadedAccount!.Balance); // 900 + 200 payout

        var reloadedBet = await ctx.Bets.FindAsync(bet.Id);
        Assert.Equal(BetStatus.Won, reloadedBet!.Status);
        Assert.NotNull(reloadedBet.SettledAtUtc);
    }

    [Fact]
    public async Task SettleEventAsync_LosingSelection_MarksLostWithNoBalanceChange()
    {
        var (ctx, account, evt, selectionA, selectionB) = await SeedAsync(openingBalance: 1000m);
        var service = new BettingService(ctx, TestDbContextFactory.Logger<BettingService>());
        var bet = await service.PlaceBetAsync(account.Id, selectionA.Id, 100m); // balance now 900

        await service.SettleEventAsync(evt.Id, selectionB.Id); // B wins, not A

        var reloadedAccount = await ctx.Accounts.FindAsync(account.Id);
        Assert.Equal(900m, reloadedAccount!.Balance); // unchanged — no payout

        var reloadedBet = await ctx.Bets.FindAsync(bet.Id);
        Assert.Equal(BetStatus.Lost, reloadedBet!.Status);
    }

    [Fact]
    public async Task SettleEventAsync_AlreadySettled_ThrowsBusinessRuleException()
    {
        var (ctx, account, evt, selectionA, _) = await SeedAsync();
        var service = new BettingService(ctx, TestDbContextFactory.Logger<BettingService>());
        await service.PlaceBetAsync(account.Id, selectionA.Id, 10m);
        await service.SettleEventAsync(evt.Id, selectionA.Id);

        await Assert.ThrowsAsync<BusinessRuleException>(() => service.SettleEventAsync(evt.Id, selectionA.Id));
    }

    [Fact]
    public async Task VoidEventAsync_RefundsStakeAndMarksVoid()
    {
        var (ctx, account, evt, selectionA, _) = await SeedAsync(openingBalance: 1000m);
        var service = new BettingService(ctx, TestDbContextFactory.Logger<BettingService>());
        var bet = await service.PlaceBetAsync(account.Id, selectionA.Id, 100m); // balance now 900

        await service.VoidEventAsync(evt.Id);

        var reloadedAccount = await ctx.Accounts.FindAsync(account.Id);
        Assert.Equal(1000m, reloadedAccount!.Balance); // fully refunded

        var reloadedBet = await ctx.Bets.FindAsync(bet.Id);
        Assert.Equal(BetStatus.Void, reloadedBet!.Status);
    }

    [Fact]
    public async Task CreateEventAsync_FewerThanTwoSelections_ThrowsBusinessRuleException()
    {
        var ctx = TestDbContextFactory.Create();
        var service = new BettingService(ctx, TestDbContextFactory.Logger<BettingService>());

        var newEvent = new BettingEvent { Name = "Solo Race", Category = "Horse Racing", EventDateUtc = DateTime.UtcNow.AddDays(1) };
        var selections = new List<BettingSelection> { new() { Name = "Only Runner", Odds = 2.00m } };

        await Assert.ThrowsAsync<BusinessRuleException>(() => service.CreateEventAsync(newEvent, selections));
    }

    [Fact]
    public async Task CreateEventAsync_DuplicateSelectionNames_ThrowsBusinessRuleException()
    {
        var ctx = TestDbContextFactory.Create();
        var service = new BettingService(ctx, TestDbContextFactory.Logger<BettingService>());

        var newEvent = new BettingEvent { Name = "Confused Race", Category = "Horse Racing", EventDateUtc = DateTime.UtcNow.AddDays(1) };
        var selections = new List<BettingSelection>
        {
            new() { Name = "Same Name", Odds = 2.00m },
            new() { Name = "Same Name", Odds = 3.00m },
        };

        await Assert.ThrowsAsync<BusinessRuleException>(() => service.CreateEventAsync(newEvent, selections));
    }
}
