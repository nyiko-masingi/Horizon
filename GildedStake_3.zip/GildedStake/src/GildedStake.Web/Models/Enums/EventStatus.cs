namespace GildedStake.Web.Models.Enums;

/// <summary>Lifecycle of a betting event (market).</summary>
public enum EventStatus
{
    /// <summary>Accepting bets.</summary>
    Open = 0,

    /// <summary>No longer accepting new bets, but not yet settled (e.g. the race has started).</summary>
    Closed = 1,

    /// <summary>A winning selection has been declared and every bet has been paid out or marked lost.</summary>
    Settled = 2,

    /// <summary>Cancelled. Every stake has been refunded.</summary>
    Voided = 3,
}
