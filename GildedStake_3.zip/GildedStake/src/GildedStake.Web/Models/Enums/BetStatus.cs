namespace GildedStake.Web.Models.Enums;

/// <summary>Lifecycle of a single bet.</summary>
public enum BetStatus
{
    /// <summary>Stake has been taken; the event has not yet been settled.</summary>
    Pending = 0,

    /// <summary>The backed selection won. The payout has been credited to the account.</summary>
    Won = 1,

    /// <summary>The backed selection did not win. The stake is not returned.</summary>
    Lost = 2,

    /// <summary>The event was voided. The stake has been refunded in full.</summary>
    Void = 3,
}
