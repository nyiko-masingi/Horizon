using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GildedStake.Web.Models.Betting;

/// <summary>
/// One backable outcome within a <see cref="BettingEvent"/> (a runner, a
/// fighter, a team) with its current decimal odds.
/// </summary>
public class BettingSelection
{
    public int Id { get; set; }

    public int BettingEventId { get; set; }
    public BettingEvent? BettingEvent { get; set; }

    [Required, StringLength(120)]
    public string Name { get; set; } = string.Empty;

    /// <summary>Decimal odds — a R100 stake at odds of 3.50 pays out R350.00 if it wins.</summary>
    [Column(TypeName = "decimal(10,2)")]
    public decimal Odds { get; set; }

    /// <summary>Set once the event is settled; true for exactly one selection.</summary>
    public bool IsWinner { get; set; }

    public ICollection<Bet> Bets { get; set; } = new List<Bet>();
}
