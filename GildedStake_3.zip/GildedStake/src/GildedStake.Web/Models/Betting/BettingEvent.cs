using System.ComponentModel.DataAnnotations;
using GildedStake.Web.Models.Enums;

namespace GildedStake.Web.Models.Betting;

/// <summary>
/// A betting market — something the house is offering odds on (a race, a
/// fight, a match). Holds one or more <see cref="BettingSelection"/>s that
/// clients' accounts can back.
/// </summary>
public class BettingEvent
{
    public int Id { get; set; }

    [Required, StringLength(120)]
    public string Name { get; set; } = string.Empty;

    [Required, StringLength(60)]
    public string Category { get; set; } = string.Empty;

    [StringLength(120)]
    public string? Venue { get; set; }

    [Required]
    public DateTime EventDateUtc { get; set; }

    public EventStatus Status { get; set; } = EventStatus.Open;

    public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;

    public DateTime? SettledAtUtc { get; set; }

    [Timestamp]
    public byte[]? RowVersion { get; set; }

    public ICollection<BettingSelection> Selections { get; set; } = new List<BettingSelection>();
}
