using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using GildedStake.Web.Models.Enums;

namespace GildedStake.Web.Models.Betting;

/// <summary>
/// A single stake placed by a betting account against one selection in an
/// event. Odds are captured at the moment the bet is placed, so a later
/// change in a selection's odds never retroactively changes an existing
/// bet's payout.
/// </summary>
public class Bet
{
    public int Id { get; set; }

    public int AccountId { get; set; }
    public Account? Account { get; set; }

    public int BettingSelectionId { get; set; }
    public BettingSelection? BettingSelection { get; set; }

    [Column(TypeName = "decimal(18,2)")]
    public decimal Stake { get; set; }

    /// <summary>Odds at the moment of placement (snapshot, not a live reference).</summary>
    [Column(TypeName = "decimal(10,2)")]
    public decimal Odds { get; set; }

    /// <summary>Stake &#215; Odds, computed once at placement.</summary>
    [Column(TypeName = "decimal(18,2)")]
    public decimal PotentialPayout { get; set; }

    public BetStatus Status { get; set; } = BetStatus.Pending;

    public DateTime PlacedAtUtc { get; set; } = DateTime.UtcNow;

    public DateTime? SettledAtUtc { get; set; }

    [Timestamp]
    public byte[]? RowVersion { get; set; }
}
