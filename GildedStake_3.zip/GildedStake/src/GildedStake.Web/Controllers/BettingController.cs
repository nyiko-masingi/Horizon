using GildedStake.Web.Common;
using GildedStake.Web.Models.Betting;
using GildedStake.Web.Services;
using GildedStake.Web.ViewModels.Betting;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace GildedStake.Web.Controllers;

/// <summary>
/// The betting board: events (markets), their selections and odds, and the
/// full bet lifecycle — placing a stake against a client's account, closing
/// a market to new bets, settling the result, or voiding it.
///
/// Every authenticated role may view; placing a bet is an operational
/// action; creating, closing, settling and voiding a market are supervisory
/// actions, since they move money across every account holding a bet on
/// that event.
/// </summary>
public class BettingController : Controller
{
    private readonly IBettingService _bettingService;
    private readonly IAccountService _accountService;
    private readonly ILogger<BettingController> _logger;

    public BettingController(IBettingService bettingService, IAccountService accountService, ILogger<BettingController> logger)
    {
        _bettingService = bettingService;
        _accountService = accountService;
        _logger = logger;
    }

    // GET /Betting
    [HttpGet]
    public async Task<IActionResult> Index(CancellationToken ct)
    {
        var events = await _bettingService.GetEventsAsync(includeClosedMarkets: true, ct);
        return View(events);
    }

    // GET /Betting/Details/5
    [HttpGet]
    public async Task<IActionResult> Details(int id, CancellationToken ct)
    {
        var bettingEvent = await _bettingService.GetEventWithSelectionsAsync(id, ct);
        if (bettingEvent is null)
        {
            return RedirectToAction("HttpStatus", "Home", new { code = 404 });
        }

        return View(bettingEvent);
    }

    // GET /Betting/Create
    [HttpGet]
    [Authorize(Roles = Roles.SupervisoryRoles)]
    public IActionResult Create() => View(new CreateEventViewModel());

    // POST /Betting/Create
    [HttpPost]
    [Authorize(Roles = Roles.SupervisoryRoles)]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(CreateEventViewModel model, CancellationToken ct)
    {
        // Trailing blank rows from the fixed-size form are just unused slots, not errors.
        var usableSelections = model.Selections.Where(s => !string.IsNullOrWhiteSpace(s.Name)).ToList();

        for (var i = model.Selections.Count - 1; i >= 0; i--)
        {
            if (string.IsNullOrWhiteSpace(model.Selections[i].Name))
            {
                ModelState.Remove($"{nameof(model.Selections)}[{i}].{nameof(SelectionInputModel.Name)}");
                ModelState.Remove($"{nameof(model.Selections)}[{i}].{nameof(SelectionInputModel.Odds)}");
            }
        }

        if (usableSelections.Count < 2)
        {
            ModelState.AddModelError(string.Empty, "An event needs at least two selections for clients to choose between.");
        }

        if (!ModelState.IsValid)
        {
            return View(model);
        }

        var newEvent = new BettingEvent
        {
            Name = model.Name.Trim(),
            Category = model.Category.Trim(),
            Venue = string.IsNullOrWhiteSpace(model.Venue) ? null : model.Venue.Trim(),
            EventDateUtc = model.EventDate.ToUniversalTime(),
        };

        var selections = usableSelections
            .Select(s => new BettingSelection { Name = s.Name.Trim(), Odds = s.Odds })
            .ToList();

        var created = await _bettingService.CreateEventAsync(newEvent, selections, ct);
        TempData["SuccessMessage"] = $"\"{created.Name}\" is open for bets with {selections.Count} selections.";
        return RedirectToAction(nameof(Details), new { id = created.Id });
    }

    // POST /Betting/Close/5
    [HttpPost]
    [Authorize(Roles = Roles.SupervisoryRoles)]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Close(int id, CancellationToken ct)
    {
        await _bettingService.CloseEventAsync(id, ct);
        TempData["SuccessMessage"] = "The market is now closed to new bets.";
        return RedirectToAction(nameof(Details), new { id });
    }

    // GET /Betting/Settle/5
    [HttpGet]
    [Authorize(Roles = Roles.SupervisoryRoles)]
    public async Task<IActionResult> Settle(int id, CancellationToken ct)
    {
        var bettingEvent = await _bettingService.GetEventWithSelectionsAsync(id, ct);
        if (bettingEvent is null)
        {
            return RedirectToAction("HttpStatus", "Home", new { code = 404 });
        }

        return View(new SettleEventViewModel
        {
            EventId = bettingEvent.Id,
            EventName = bettingEvent.Name,
            Selections = bettingEvent.Selections.ToList(),
        });
    }

    // POST /Betting/Settle/5
    [HttpPost]
    [Authorize(Roles = Roles.SupervisoryRoles)]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Settle(int id, SettleEventViewModel model, CancellationToken ct)
    {
        model.EventId = id;

        if (!ModelState.IsValid)
        {
            var bettingEvent = await _bettingService.GetEventWithSelectionsAsync(id, ct);
            model.Selections = bettingEvent?.Selections.ToList() ?? new();
            model.EventName = bettingEvent?.Name ?? model.EventName;
            return View(model);
        }

        await _bettingService.SettleEventAsync(id, model.WinningSelectionId, ct);
        TempData["SuccessMessage"] = "The event has been settled. Winning bets have been paid out.";
        return RedirectToAction(nameof(Details), new { id });
    }

    // POST /Betting/Void/5
    [HttpPost]
    [Authorize(Roles = Roles.SupervisoryRoles)]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Void(int id, CancellationToken ct)
    {
        await _bettingService.VoidEventAsync(id, ct);
        TempData["SuccessMessage"] = "The event has been voided and every stake refunded.";
        return RedirectToAction(nameof(Details), new { id });
    }

    // GET /Betting/PlaceBet?accountId=5
    [HttpGet]
    [Authorize(Roles = Roles.OperationalRoles)]
    public async Task<IActionResult> PlaceBet(int accountId, CancellationToken ct)
    {
        var account = await _accountService.GetByIdAsync(accountId, ct);
        if (account is null)
        {
            return RedirectToAction("HttpStatus", "Home", new { code = 404 });
        }

        if (account.IsClosed)
        {
            TempData["ErrorMessage"] = "This account is closed. Reopen it before placing a bet.";
            return RedirectToAction("Details", "Accounts", new { id = accountId });
        }

        var openEvents = await _bettingService.GetEventsAsync(includeClosedMarkets: false, ct);
        if (openEvents.Count == 0)
        {
            TempData["ErrorMessage"] = "There are no open markets to bet on right now.";
            return RedirectToAction("Details", "Accounts", new { id = accountId });
        }

        var model = new PlaceBetViewModel
        {
            AccountId = account.Id,
            AccountNumber = account.AccountNumber,
            AvailableBalance = account.Balance,
            OpenEvents = openEvents,
        };
        return View(model);
    }

    // POST /Betting/PlaceBet
    [HttpPost]
    [Authorize(Roles = Roles.OperationalRoles)]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> PlaceBet(PlaceBetViewModel model, CancellationToken ct)
    {
        if (!ModelState.IsValid)
        {
            var account = await _accountService.GetByIdAsync(model.AccountId, ct);
            model.AccountNumber = account?.AccountNumber ?? model.AccountNumber;
            model.AvailableBalance = account?.Balance ?? model.AvailableBalance;
            model.OpenEvents = await _bettingService.GetEventsAsync(includeClosedMarkets: false, ct);
            return View(model);
        }

        await _bettingService.PlaceBetAsync(model.AccountId, model.SelectionId, model.Stake, ct);
        TempData["SuccessMessage"] = $"Bet placed — {model.Stake:C2} staked.";
        return RedirectToAction("Details", "Accounts", new { id = model.AccountId });
    }
}
