using GildedStake.Web.Data;
using GildedStake.Web.Models;
using GildedStake.Web.Models.Betting;
using GildedStake.Web.Models.Enums;
using GildedStake.Web.Services.Exceptions;
using Microsoft.EntityFrameworkCore;

namespace GildedStake.Web.Services;

/// <summary>
/// Every balance movement a bet causes — the stake at placement, a payout at
/// settlement, a refund on void — is posted as an ordinary <see cref="Transaction"/>
/// alongside the <see cref="Bet"/> record itself. This keeps the promise made
/// everywhere else in the house: an account's balance is always, and only,
/// the sum of its posted transactions — betting activity never becomes a
/// second, competing source of truth.
/// </summary>
public class BettingService : IBettingService
{
    private readonly ApplicationDbContext _context;
    private readonly ILogger<BettingService> _logger;

    public BettingService(ApplicationDbContext context, ILogger<BettingService> logger)
    {
        _context = context;
        _logger = logger;
    }

    public async Task<List<BettingEvent>> GetEventsAsync(bool includeClosedMarkets = true, CancellationToken ct = default)
    {
        IQueryable<BettingEvent> query = _context.BettingEvents
            .Include(e => e.Selections)
            .AsNoTracking();

        if (!includeClosedMarkets)
        {
            query = query.Where(e => e.Status == EventStatus.Open);
        }

        return await query
            .OrderBy(e => e.Status == EventStatus.Open ? 0 : e.Status == EventStatus.Closed ? 1 : 2)
            .ThenBy(e => e.EventDateUtc)
            .ToListAsync(ct);
    }

    public async Task<BettingEvent?> GetEventWithSelectionsAsync(int eventId, CancellationToken ct = default) =>
        await _context.BettingEvents
            .Include(e => e.Selections.OrderBy(s => s.Name))
            .FirstOrDefaultAsync(e => e.Id == eventId, ct);

    public async Task<BettingEvent> CreateEventAsync(BettingEvent newEvent, List<BettingSelection> selections, CancellationToken ct = default)
    {
        if (selections.Count < 2)
        {
            throw new BusinessRuleException("An event needs at least two selections for clients to choose between.");
        }

        foreach (var selection in selections)
        {
            if (string.IsNullOrWhiteSpace(selection.Name))
            {
                throw new BusinessRuleException("Every selection needs a name.");
            }

            if (selection.Odds < 1.01m)
            {
                throw new BusinessRuleException($"Odds for \"{selection.Name}\" must be at least 1.01 — anything lower offers no possible return.");
            }
        }

        var duplicateNames = selections
            .Select(s => s.Name.Trim().ToLowerInvariant())
            .GroupBy(n => n)
            .Any(g => g.Count() > 1);
        if (duplicateNames)
        {
            throw new BusinessRuleException("Selections within the same event must have distinct names.");
        }

        newEvent.Status = EventStatus.Open;
        newEvent.Selections = selections;

        _context.BettingEvents.Add(newEvent);
        await _context.SaveChangesAsync(ct);

        _logger.LogInformation("Created betting event {EventId} \"{Name}\" with {Count} selections", newEvent.Id, newEvent.Name, selections.Count);
        return newEvent;
    }

    public async Task CloseEventAsync(int eventId, CancellationToken ct = default)
    {
        var bettingEvent = await _context.BettingEvents.FirstOrDefaultAsync(e => e.Id == eventId, ct)
            ?? throw new NotFoundException($"Event {eventId} was not found.");

        if (bettingEvent.Status != EventStatus.Open)
        {
            throw new BusinessRuleException("Only an open market can be closed to new bets.");
        }

        bettingEvent.Status = EventStatus.Closed;
        await _context.SaveChangesAsync(ct);
        _logger.LogInformation("Closed betting event {EventId} to new bets", eventId);
    }

    public async Task SettleEventAsync(int eventId, int winningSelectionId, CancellationToken ct = default)
    {
        var bettingEvent = await _context.BettingEvents
            .Include(e => e.Selections)
            .FirstOrDefaultAsync(e => e.Id == eventId, ct)
            ?? throw new NotFoundException($"Event {eventId} was not found.");

        if (bettingEvent.Status == EventStatus.Settled)
        {
            throw new BusinessRuleException("This event has already been settled.");
        }

        if (bettingEvent.Status == EventStatus.Voided)
        {
            throw new BusinessRuleException("This event was voided and cannot be settled.");
        }

        var winningSelection = bettingEvent.Selections.FirstOrDefault(s => s.Id == winningSelectionId)
            ?? throw new BusinessRuleException("Choose one of this event's own selections as the winner.");

        winningSelection.IsWinner = true;

        var selectionIds = bettingEvent.Selections.Select(s => s.Id).ToList();
        var pendingBets = await _context.Bets
            .Include(b => b.Account)
            .Include(b => b.BettingSelection)
            .Where(b => selectionIds.Contains(b.BettingSelectionId) && b.Status == BetStatus.Pending)
            .ToListAsync(ct);

        var now = DateTime.UtcNow;
        var today = DateOnly.FromDateTime(now);
        var wonCount = 0;

        foreach (var bet in pendingBets)
        {
            if (bet.Account is null)
            {
                continue;
            }

            if (bet.BettingSelectionId == winningSelectionId)
            {
                bet.Status = BetStatus.Won;
                bet.Account.Balance += bet.PotentialPayout;

                _context.Transactions.Add(new Transaction
                {
                    AccountId = bet.AccountId,
                    TransactionDate = today,
                    CaptureDateUtc = now,
                    Type = TransactionType.Credit,
                    Amount = bet.PotentialPayout,
                    Description = $"Winnings — {bettingEvent.Name} — {bet.BettingSelection?.Name}",
                });
                wonCount++;
            }
            else
            {
                bet.Status = BetStatus.Lost;
            }

            bet.SettledAtUtc = now;
        }

        bettingEvent.Status = EventStatus.Settled;
        bettingEvent.SettledAtUtc = now;

        await _context.SaveChangesAsync(ct);
        _logger.LogInformation("Settled betting event {EventId}: \"{Winner}\" won, {WonCount}/{Total} bets paid out",
            eventId, winningSelection.Name, wonCount, pendingBets.Count);
    }

    public async Task VoidEventAsync(int eventId, CancellationToken ct = default)
    {
        var bettingEvent = await _context.BettingEvents
            .Include(e => e.Selections)
            .FirstOrDefaultAsync(e => e.Id == eventId, ct)
            ?? throw new NotFoundException($"Event {eventId} was not found.");

        if (bettingEvent.Status == EventStatus.Settled)
        {
            throw new BusinessRuleException("A settled event cannot be voided.");
        }

        if (bettingEvent.Status == EventStatus.Voided)
        {
            throw new BusinessRuleException("This event has already been voided.");
        }

        var selectionIds = bettingEvent.Selections.Select(s => s.Id).ToList();
        var pendingBets = await _context.Bets
            .Include(b => b.Account)
            .Where(b => selectionIds.Contains(b.BettingSelectionId) && b.Status == BetStatus.Pending)
            .ToListAsync(ct);

        var now = DateTime.UtcNow;
        var today = DateOnly.FromDateTime(now);

        foreach (var bet in pendingBets)
        {
            if (bet.Account is null)
            {
                continue;
            }

            bet.Status = BetStatus.Void;
            bet.SettledAtUtc = now;
            bet.Account.Balance += bet.Stake; // full refund

            _context.Transactions.Add(new Transaction
            {
                AccountId = bet.AccountId,
                TransactionDate = today,
                CaptureDateUtc = now,
                Type = TransactionType.Credit,
                Amount = bet.Stake,
                Description = $"Stake refunded — {bettingEvent.Name} voided",
            });
        }

        bettingEvent.Status = EventStatus.Voided;
        bettingEvent.SettledAtUtc = now;

        await _context.SaveChangesAsync(ct);
        _logger.LogInformation("Voided betting event {EventId}, refunded {Count} pending bets", eventId, pendingBets.Count);
    }

    public async Task<Bet> PlaceBetAsync(int accountId, int selectionId, decimal stake, CancellationToken ct = default)
    {
        if (stake <= 0m)
        {
            throw new BusinessRuleException("The stake must be greater than zero.");
        }

        var account = await _context.Accounts.FirstOrDefaultAsync(a => a.Id == accountId, ct)
            ?? throw new NotFoundException($"Account {accountId} was not found.");

        if (account.IsClosed)
        {
            throw new BusinessRuleException("A bet cannot be placed from a closed account. Reopen the account first.");
        }

        var selection = await _context.BettingSelections
            .Include(s => s.BettingEvent)
            .FirstOrDefaultAsync(s => s.Id == selectionId, ct)
            ?? throw new NotFoundException($"Selection {selectionId} was not found.");

        if (selection.BettingEvent is null || selection.BettingEvent.Status != EventStatus.Open)
        {
            throw new BusinessRuleException("This market is not open for new bets.");
        }

        if (stake > account.Balance)
        {
            throw new BusinessRuleException(
                $"Insufficient balance. This account holds {account.Balance:C2}, which is less than the {stake:C2} stake.");
        }

        var now = DateTime.UtcNow;
        var bet = new Bet
        {
            AccountId = accountId,
            BettingSelectionId = selectionId,
            Stake = stake,
            Odds = selection.Odds,
            PotentialPayout = Math.Round(stake * selection.Odds, 2, MidpointRounding.AwayFromZero),
            Status = BetStatus.Pending,
            PlacedAtUtc = now,
        };

        account.Balance -= stake;
        _context.Bets.Add(bet);
        _context.Transactions.Add(new Transaction
        {
            AccountId = accountId,
            TransactionDate = DateOnly.FromDateTime(now),
            CaptureDateUtc = now,
            Type = TransactionType.Debit,
            Amount = stake,
            Description = $"Stake — {selection.BettingEvent.Name} — {selection.Name}",
        });

        // The stake transaction, the bet record, and the balance deduction are
        // saved together in one implicit database transaction, so the three
        // writes can never be observed independently.
        await _context.SaveChangesAsync(ct);

        _logger.LogInformation("Placed bet {BetId}: account {AccountId} staked {Stake:C2} on selection {SelectionId} at odds {Odds}",
            bet.Id, accountId, stake, selectionId, selection.Odds);
        return bet;
    }

    public async Task<List<Bet>> GetBetsForAccountAsync(int accountId, CancellationToken ct = default) =>
        await _context.Bets
            .Include(b => b.BettingSelection!)
                .ThenInclude(s => s.BettingEvent)
            .Where(b => b.AccountId == accountId)
            .OrderByDescending(b => b.PlacedAtUtc)
            .AsNoTracking()
            .ToListAsync(ct);
}
