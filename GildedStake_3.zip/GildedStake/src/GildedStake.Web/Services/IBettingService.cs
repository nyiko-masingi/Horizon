using GildedStake.Web.Models.Betting;

namespace GildedStake.Web.Services;

public interface IBettingService
{
    Task<List<BettingEvent>> GetEventsAsync(bool includeClosedMarkets = true, CancellationToken ct = default);
    Task<BettingEvent?> GetEventWithSelectionsAsync(int eventId, CancellationToken ct = default);
    Task<BettingEvent> CreateEventAsync(BettingEvent newEvent, List<BettingSelection> selections, CancellationToken ct = default);
    Task CloseEventAsync(int eventId, CancellationToken ct = default);
    Task SettleEventAsync(int eventId, int winningSelectionId, CancellationToken ct = default);
    Task VoidEventAsync(int eventId, CancellationToken ct = default);

    Task<Bet> PlaceBetAsync(int accountId, int selectionId, decimal stake, CancellationToken ct = default);
    Task<List<Bet>> GetBetsForAccountAsync(int accountId, CancellationToken ct = default);
}
