using System.ComponentModel.DataAnnotations;
using GildedStake.Web.Models.Betting;

namespace GildedStake.Web.ViewModels.Betting;

public class SettleEventViewModel
{
    public int EventId { get; set; }
    public string EventName { get; set; } = string.Empty;
    public List<BettingSelection> Selections { get; set; } = new();

    [Required(ErrorMessage = "Choose the winning selection.")]
    [Display(Name = "Winning selection")]
    public int WinningSelectionId { get; set; }
}
