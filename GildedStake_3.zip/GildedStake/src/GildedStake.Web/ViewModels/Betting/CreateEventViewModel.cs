using System.ComponentModel.DataAnnotations;

namespace GildedStake.Web.ViewModels.Betting;

public class SelectionInputModel
{
    [Required(ErrorMessage = "Every selection needs a name.")]
    [StringLength(120)]
    public string Name { get; set; } = string.Empty;

    [Required(ErrorMessage = "Every selection needs odds.")]
    [Range(1.01, 1000, ErrorMessage = "Odds must be between 1.01 and 1000.")]
    public decimal Odds { get; set; } = 2.00m;
}

public class CreateEventViewModel
{
    [Required(ErrorMessage = "Give the event a name.")]
    [StringLength(120)]
    public string Name { get; set; } = string.Empty;

    [Required(ErrorMessage = "Choose a category.")]
    [StringLength(60)]
    public string Category { get; set; } = "Horse Racing";

    [StringLength(120)]
    [Display(Name = "Venue (optional)")]
    public string? Venue { get; set; }

    [Required(ErrorMessage = "Set the event date and time.")]
    [Display(Name = "Event date & time")]
    public DateTime EventDate { get; set; } = DateTime.Today.AddDays(1).AddHours(14);

    /// <summary>Fixed-size, index-bound list so the "Add selection" control on the
    /// client can grow it without any server round-trip; unused trailing rows
    /// (blank name) are ignored on submit.</summary>
    public List<SelectionInputModel> Selections { get; set; } = new()
    {
        new SelectionInputModel(), new SelectionInputModel(), new SelectionInputModel(), new SelectionInputModel(),
        new SelectionInputModel(), new SelectionInputModel(), new SelectionInputModel(), new SelectionInputModel(),
    };

    public static readonly string[] Categories =
    {
        "Horse Racing", "Football", "Boxing", "Motorsport", "Tennis", "Golf", "Cricket", "Other",
    };
}
