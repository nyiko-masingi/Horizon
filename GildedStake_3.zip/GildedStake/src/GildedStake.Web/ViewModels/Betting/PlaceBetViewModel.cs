using System.ComponentModel.DataAnnotations;
using GildedStake.Web.Models.Betting;

namespace GildedStake.Web.ViewModels.Betting;

public class PlaceBetViewModel
{
    public int AccountId { get; set; }
    public string AccountNumber { get; set; } = string.Empty;
    public string? AccountHolderName { get; set; }
    public decimal AvailableBalance { get; set; }

    [Required(ErrorMessage = "Choose a selection to back.")]
    [Display(Name = "Selection")]
    public int SelectionId { get; set; }

    [Required(ErrorMessage = "Enter a stake.")]
    [Range(0.01, 1000000, ErrorMessage = "The stake must be greater than zero.")]
    public decimal Stake { get; set; }

    /// <summary>Every open event with its selections, for the picker.</summary>
    public List<BettingEvent> OpenEvents { get; set; } = new();
}
