using GildedStake.Web.Models;
using GildedStake.Web.Models.Betting;

namespace GildedStake.Web.ViewModels.Accounts;

public class AccountDetailsViewModel
{
    public AccountFormViewModel Form { get; set; } = new();
    public List<Transaction> Transactions { get; set; } = new();
    public List<Bet> Bets { get; set; } = new();
}
