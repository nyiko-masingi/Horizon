using GildedStake.Web.Models.Betting;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace GildedStake.Web.Data.Configurations;

public class BettingSelectionConfiguration : IEntityTypeConfiguration<BettingSelection>
{
    public void Configure(EntityTypeBuilder<BettingSelection> builder)
    {
        builder.ToTable("BettingSelections");

        builder.HasKey(s => s.Id);

        builder.Property(s => s.Name).IsRequired().HasMaxLength(120);
        builder.Property(s => s.Odds).HasColumnType("decimal(10,2)");

        builder.HasIndex(s => s.BettingEventId).HasDatabaseName("IX_BettingSelections_BettingEventId");

        builder.HasMany(s => s.Bets)
               .WithOne(b => b.BettingSelection)
               .HasForeignKey(b => b.BettingSelectionId)
               .OnDelete(DeleteBehavior.Restrict);
    }
}
