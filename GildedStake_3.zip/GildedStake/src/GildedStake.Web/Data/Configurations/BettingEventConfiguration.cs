using GildedStake.Web.Models.Betting;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace GildedStake.Web.Data.Configurations;

public class BettingEventConfiguration : IEntityTypeConfiguration<BettingEvent>
{
    public void Configure(EntityTypeBuilder<BettingEvent> builder)
    {
        builder.ToTable("BettingEvents");

        builder.HasKey(e => e.Id);

        builder.Property(e => e.Name).IsRequired().HasMaxLength(120);
        builder.Property(e => e.Category).IsRequired().HasMaxLength(60);
        builder.Property(e => e.Venue).HasMaxLength(120);
        builder.Property(e => e.Status).HasConversion<string>().HasMaxLength(10);

        builder.HasIndex(e => e.Status).HasDatabaseName("IX_BettingEvents_Status");
        builder.HasIndex(e => e.EventDateUtc).HasDatabaseName("IX_BettingEvents_EventDateUtc");

        builder.HasMany(e => e.Selections)
               .WithOne(s => s.BettingEvent)
               .HasForeignKey(s => s.BettingEventId)
               .OnDelete(DeleteBehavior.Cascade);
    }
}
