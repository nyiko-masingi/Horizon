using GildedStake.Web.Models.Betting;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace GildedStake.Web.Data.Configurations;

public class BetConfiguration : IEntityTypeConfiguration<Bet>
{
    public void Configure(EntityTypeBuilder<Bet> builder)
    {
        builder.ToTable("Bets");

        builder.HasKey(b => b.Id);

        builder.Property(b => b.Stake).HasColumnType("decimal(18,2)");
        builder.Property(b => b.Odds).HasColumnType("decimal(10,2)");
        builder.Property(b => b.PotentialPayout).HasColumnType("decimal(18,2)");
        builder.Property(b => b.Status).HasConversion<string>().HasMaxLength(10);

        builder.HasIndex(b => b.AccountId).HasDatabaseName("IX_Bets_AccountId");
        builder.HasIndex(b => b.BettingSelectionId).HasDatabaseName("IX_Bets_BettingSelectionId");

        builder.HasOne(b => b.Account)
               .WithMany(a => a.Bets)
               .HasForeignKey(b => b.AccountId)
               .OnDelete(DeleteBehavior.Restrict);
    }
}
