using GildedStake.Web.Models;
using GildedStake.Web.Models.Betting;
using GildedStake.Web.Models.Enums;
using Microsoft.EntityFrameworkCore;

namespace GildedStake.Web.Data;

/// <summary>
/// Ensures the database schema exists, provisions the reporting view and
/// stored procedure used by the presentation layer, and seeds a handful of
/// demonstration records — including live and settled betting events — so
/// the application is usable on first run.
/// </summary>
public static class DbInitializer
{
    public static async Task InitializeAsync(ApplicationDbContext context)
    {
        await context.Database.EnsureCreatedAsync();
        await ApplySqlObjectsAsync(context);

        if (!await context.Users.AnyAsync())
        {
            await SeedAsync(context);
        }
    }

    /// <summary>
    /// Creates/refreshes the SQL Server view and stored procedure that the
    /// presentation layer reads from, satisfying the requirement that data is
    /// returned to the presentation layer via views/stored procedures.
    /// </summary>
    private static async Task ApplySqlObjectsAsync(ApplicationDbContext context)
    {
        await context.Database.ExecuteSqlRawAsync("""
            IF OBJECT_ID('dbo.vw_UserAccountSummary', 'V') IS NOT NULL
                DROP VIEW dbo.vw_UserAccountSummary;
            """);

        await context.Database.ExecuteSqlRawAsync("""
            CREATE VIEW dbo.vw_UserAccountSummary AS
            SELECT
                u.Id                                                        AS UserId,
                u.FirstName                                                 AS FirstName,
                u.Surname                                                   AS Surname,
                u.IdNumber                                                  AS IdNumber,
                u.Email                                                     AS Email,
                u.PhoneNumber                                               AS PhoneNumber,
                COUNT(a.Id)                                                 AS AccountCount,
                SUM(CASE WHEN a.IsClosed = 0 THEN 1 ELSE 0 END)             AS OpenAccountCount,
                ISNULL(SUM(a.Balance), 0)                                   AS TotalBalance,
                (SELECT TOP 1 a2.AccountNumber FROM dbo.Accounts a2
                    WHERE a2.UserId = u.Id ORDER BY a2.Id)                  AS FirstAccountNumber
            FROM dbo.Users u
            LEFT JOIN dbo.Accounts a ON a.UserId = u.Id
            GROUP BY u.Id, u.FirstName, u.Surname, u.IdNumber, u.Email, u.PhoneNumber;
            """);

        await context.Database.ExecuteSqlRawAsync("""
            IF OBJECT_ID('dbo.sp_GetAccountStatement', 'P') IS NOT NULL
                DROP PROCEDURE dbo.sp_GetAccountStatement;
            """);

        await context.Database.ExecuteSqlRawAsync("""
            CREATE PROCEDURE dbo.sp_GetAccountStatement
                @AccountId INT
            AS
            BEGIN
                SET NOCOUNT ON;
                SELECT t.Id, t.AccountId, t.TransactionDate, t.CaptureDateUtc,
                       t.Type, t.Amount, t.Description, t.RowVersion
                FROM dbo.Transactions t
                WHERE t.AccountId = @AccountId
                ORDER BY t.TransactionDate DESC, t.Id DESC;
            END
            """);
    }

    private static async Task SeedAsync(ApplicationDbContext context)
    {
        var today = DateOnly.FromDateTime(DateTime.UtcNow);
        var nowUtc = DateTime.UtcNow;

        // ---------------- Clients & accounts ----------------
        var users = new List<User>
        {
            new()
            {
                FirstName = "Alessandra",
                Surname = "Winthrop",
                IdNumber = "8801015800083",
                Email = "alessandra.winthrop@example.com",
                PhoneNumber = "+27 82 555 0101",
                DateOfBirth = new DateOnly(1988, 1, 1)
            },
            new()
            {
                FirstName = "Julian",
                Surname = "Voss",
                IdNumber = "9006126800084",
                Email = "julian.voss@example.com",
                PhoneNumber = "+27 83 555 0102",
                DateOfBirth = new DateOnly(1990, 6, 12)
            },
            new()
            {
                FirstName = "Naledi",
                Surname = "Khumalo",
                IdNumber = "9412085800085",
                Email = "naledi.khumalo@example.com",
                PhoneNumber = "+27 84 555 0103",
                DateOfBirth = new DateOnly(1994, 12, 8)
            }
        };

        context.Users.AddRange(users);
        await context.SaveChangesAsync();

        var accounts = new List<Account>
        {
            new() { AccountNumber = "GS-100001", AccountName = "Primary Wagering Account", UserId = users[0].Id },
            new() { AccountNumber = "GS-100002", AccountName = "High Roller Suite", UserId = users[0].Id },
            new() { AccountNumber = "GS-100003", AccountName = "Primary Wagering Account", UserId = users[1].Id },
            new() { AccountNumber = "GS-100004", AccountName = "Primary Wagering Account", UserId = users[2].Id }
        };

        context.Accounts.AddRange(accounts);
        await context.SaveChangesAsync();

        // ---------------- Betting board ----------------
        var derby = new BettingEvent
        {
            Name = "The Derby Cup Final",
            Category = "Horse Racing",
            Venue = "Ascot Park",
            EventDateUtc = nowUtc.AddDays(2),
            Status = EventStatus.Open,
            Selections = new List<BettingSelection>
            {
                new() { Name = "Midnight Sonata", Odds = 3.50m },
                new() { Name = "Iron Duke", Odds = 4.20m },
                new() { Name = "Velvet Storm", Odds = 5.00m },
                new() { Name = "Golden Comet", Odds = 6.50m },
            },
        };

        var grandPrix = new BettingEvent
        {
            Name = "Grand Prix — Race Winner",
            Category = "Motorsport",
            Venue = "Monaco Street Circuit",
            EventDateUtc = nowUtc.AddDays(4),
            Status = EventStatus.Open,
            Selections = new List<BettingSelection>
            {
                new() { Name = "Marcus Ferrante", Odds = 2.10m },
                new() { Name = "Elena Rousseau", Odds = 3.80m },
                new() { Name = "Kai Tanaka", Odds = 5.50m },
            },
        };

        var heavyweight = new BettingEvent
        {
            Name = "Heavyweight Championship",
            Category = "Boxing",
            Venue = "The Grand Arena",
            EventDateUtc = nowUtc.AddDays(6),
            Status = EventStatus.Open,
            Selections = new List<BettingSelection>
            {
                new() { Name = "Viktor Kane", Odds = 1.80m },
                new() { Name = "Dmitri Orlov", Odds = 2.00m },
            },
        };

        var midweekClassic = new BettingEvent
        {
            Name = "Midweek Classic — Winner",
            Category = "Horse Racing",
            Venue = "Ascot Park",
            EventDateUtc = nowUtc.AddDays(-2),
            Status = EventStatus.Settled,
            SettledAtUtc = nowUtc.AddDays(-2),
            Selections = new List<BettingSelection>
            {
                new() { Name = "Silver Arrow", Odds = 2.50m, IsWinner = true },
                new() { Name = "Northern Star", Odds = 4.00m },
                new() { Name = "Copper Blaze", Odds = 7.00m },
            },
        };

        context.BettingEvents.AddRange(derby, grandPrix, heavyweight, midweekClassic);
        await context.SaveChangesAsync();

        var midnightSonata = derby.Selections.First(s => s.Name == "Midnight Sonata");
        var viktorKane = heavyweight.Selections.First(s => s.Name == "Viktor Kane");
        var northernStar = midweekClassic.Selections.First(s => s.Name == "Northern Star");

        // ---------------- Transactions (deposits + bet-driven stakes) ----------------
        var transactions = new List<Transaction>
        {
            new() { AccountId = accounts[0].Id, TransactionDate = today.AddDays(-10), Type = TransactionType.Credit, Amount = 5000m, Description = "Initial deposit" },
            new() { AccountId = accounts[1].Id, TransactionDate = today.AddDays(-3), Type = TransactionType.Credit, Amount = 25000m, Description = "Initial deposit" },
            new() { AccountId = accounts[2].Id, TransactionDate = today.AddDays(-14), Type = TransactionType.Credit, Amount = 3000m, Description = "Initial deposit" },
            new() { AccountId = accounts[3].Id, TransactionDate = today.AddDays(-1), Type = TransactionType.Credit, Amount = 800m, Description = "Initial deposit" },

            // Alessandra backs Midnight Sonata in the still-open Derby Cup Final.
            new() { AccountId = accounts[0].Id, TransactionDate = today, Type = TransactionType.Debit, Amount = 1200m, Description = $"Stake — {derby.Name} — {midnightSonata.Name}" },

            // Alessandra also backs Viktor Kane in the still-open Heavyweight Championship.
            new() { AccountId = accounts[1].Id, TransactionDate = today, Type = TransactionType.Debit, Amount = 5000m, Description = $"Stake — {heavyweight.Name} — {viktorKane.Name}" },

            // Julian backed Northern Star in the already-settled Midweek Classic — and lost.
            new() { AccountId = accounts[2].Id, TransactionDate = today.AddDays(-3), Type = TransactionType.Debit, Amount = 450m, Description = $"Stake — {midweekClassic.Name} — {northernStar.Name}" },
        };

        context.Transactions.AddRange(transactions);
        await context.SaveChangesAsync();

        // ---------------- Bets (mirroring the transactions above) ----------------
        var bets = new List<Bet>
        {
            new()
            {
                AccountId = accounts[0].Id,
                BettingSelectionId = midnightSonata.Id,
                Stake = 1200m,
                Odds = midnightSonata.Odds,
                PotentialPayout = Math.Round(1200m * midnightSonata.Odds, 2),
                Status = BetStatus.Pending,
                PlacedAtUtc = nowUtc,
            },
            new()
            {
                AccountId = accounts[1].Id,
                BettingSelectionId = viktorKane.Id,
                Stake = 5000m,
                Odds = viktorKane.Odds,
                PotentialPayout = Math.Round(5000m * viktorKane.Odds, 2),
                Status = BetStatus.Pending,
                PlacedAtUtc = nowUtc,
            },
            new()
            {
                AccountId = accounts[2].Id,
                BettingSelectionId = northernStar.Id,
                Stake = 450m,
                Odds = northernStar.Odds,
                PotentialPayout = Math.Round(450m * northernStar.Odds, 2),
                Status = BetStatus.Lost,
                PlacedAtUtc = nowUtc.AddDays(-3),
                SettledAtUtc = nowUtc.AddDays(-2),
            },
        };

        context.Bets.AddRange(bets);
        await context.SaveChangesAsync();

        // ---------------- Final balances, derived purely from posted transactions ----------------
        foreach (var account in accounts)
        {
            var balance = transactions
                .Where(t => t.AccountId == account.Id)
                .Sum(t => t.Type == TransactionType.Credit ? t.Amount : -t.Amount);
            account.Balance = balance;
        }

        await context.SaveChangesAsync();
    }
}
