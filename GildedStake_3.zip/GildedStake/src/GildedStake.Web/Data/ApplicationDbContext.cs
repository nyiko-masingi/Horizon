using GildedStake.Web.Data.Configurations;
using GildedStake.Web.Models;
using GildedStake.Web.Models.Betting;
using GildedStake.Web.Models.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace GildedStake.Web.Data;

/// <summary>
/// The house's single database context. Inherits ASP.NET Core Identity's
/// context so system (login) accounts, roles and the wagering domain
/// (clients, accounts, transactions) live in one governed database.
///
/// NOTE ON NAMING: IdentityDbContext&lt;ApplicationUser&gt; declares its own
/// <c>Users</c> property (a DbSet&lt;ApplicationUser&gt; of system accounts).
/// The wagering domain already has an unrelated, spec-mandated "User" concept
/// (a client of the house — see Models/User.cs, and the User List / User
/// Details screens). Rather than rename either concept, the collision is
/// resolved explicitly below with <c>new</c>: <see cref="Users"/> here always
/// means "clients", and system accounts are reached through
/// <c>UserManager&lt;ApplicationUser&gt;</c> instead (the idiomatic Identity
/// pattern), not through this context directly.
/// </summary>
public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
        : base(options)
    {
    }

    /// <summary>Wagering clients. Deliberately hides IdentityDbContext.Users (system accounts).</summary>
    public new DbSet<User> Users => Set<User>();

    public DbSet<Account> Accounts => Set<Account>();
    public DbSet<Transaction> Transactions => Set<Transaction>();
    public DbSet<ContactMessage> ContactMessages => Set<ContactMessage>();

    /// <summary>Keyless read model backed by the vw_UserAccountSummary SQL view.</summary>
    public DbSet<UserAccountSummary> UserAccountSummaries => Set<UserAccountSummary>();

    public DbSet<BettingEvent> BettingEvents => Set<BettingEvent>();
    public DbSet<BettingSelection> BettingSelections => Set<BettingSelection>();
    public DbSet<Bet> Bets => Set<Bet>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        // Identity's own model (AspNetUsers, AspNetRoles, AspNetUserRoles, etc.)
        // must be established first so the wagering-domain configuration below
        // layers on top of it cleanly.
        base.OnModelCreating(modelBuilder);

        modelBuilder.ApplyConfiguration(new UserConfiguration());
        modelBuilder.ApplyConfiguration(new AccountConfiguration());
        modelBuilder.ApplyConfiguration(new TransactionConfiguration());
        modelBuilder.ApplyConfiguration(new ContactMessageConfiguration());
        modelBuilder.ApplyConfiguration(new BettingEventConfiguration());
        modelBuilder.ApplyConfiguration(new BettingSelectionConfiguration());
        modelBuilder.ApplyConfiguration(new BetConfiguration());

        // The keyless read model maps onto a real SQL Server view (vw_UserAccountSummary)
        // and is only meaningful against a relational provider. Non-relational test
        // providers (e.g. the EF Core InMemory provider used by GildedStake.Tests)
        // skip it so business-rule unit tests don't need a real database view.
        if (Database.IsRelational())
        {
            modelBuilder.ApplyConfiguration(new UserAccountSummaryConfiguration());
        }
        else
        {
            // Without a relational provider there is no view to back this keyless
            // read model, so exclude it from the model entirely rather than let EF's
            // DbSet convention discover it (which would otherwise fail key validation).
            modelBuilder.Ignore<UserAccountSummary>();
        }
    }
}
