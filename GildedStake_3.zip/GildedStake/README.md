# The Gilded Stake

*A private house for the discerning wager.*

The Gilded Stake is an ASP.NET Core MVC (.NET 10) application built for the
Horizon DevCamp final capstone. It manages a wagering company's **users**,
their **betting accounts**, and every **transaction** posted against those
accounts — with server-rendered views, SQL Server persistence, and a
luxurious dark-and-gold visual identity.

## Tech stack

- **.NET 10** / ASP.NET Core MVC
- **ASP.NET Core Identity** for authentication, with a custom role-based
  access control layer (Administrator / Manager / Teller / Auditor)
- **Entity Framework Core 10** (Code First) against **Microsoft SQL Server**
- A SQL **view** (`vw_UserAccountSummary`) and a **stored procedure**
  (`sp_GetAccountStatement`) that the presentation layer reads through
- Bootstrap 5 + Bootstrap Icons + hand-written CSS design system (no build
  step required — everything loads from CDN except the two custom files in
  `wwwroot/css` and `wwwroot/js`)
- xUnit test project (`GildedStake.Tests`) covering the service layer's
  business rules against the EF Core InMemory provider

## Solution layout

```
GildedStake.sln
src/
  GildedStake.Web/       ASP.NET Core MVC application
    Common/                Roles.cs — RBAC role constants and role groupings
    Models/                EF Core entities (User, Account, Transaction, ContactMessage)
    Models/Identity/        ApplicationUser — the system (login) account, extends IdentityUser
    Data/                  DbContext (also the Identity store), Fluent API configurations,
                           DbInitializer (schema + view/SP + demo business data),
                           IdentitySeeder (roles + one demo login per role)
    Services/              Business logic layer (IUserService, IAccountService, ITransactionService, IContactService)
    ViewModels/            Form/view models with data-annotation validation
    ViewModels/Auth/        Login, Register, and admin account-management view models
    Controllers/           HomeController, UsersController, AccountsController,
                           TransactionsController, AuthController (sign in/up + admin account management)
    Middleware/             Centralised exception handling
    Views/                  Razor views + shared layout (navbar reflects sign-in state and role)
    Views/Auth/              Login, Register, AccessDenied, ManageAccounts, CreateAccount
    wwwroot/                site.css, site.js, favicon
  GildedStake.Tests/      xUnit tests for the service layer and Identity seeding (see TESTING.md)
```

## Signing in

The app requires sign-in for everything except Home, About and Contact.
On first run, four demonstration accounts are seeded automatically — one per
role — so every permission tier can be explored immediately:

| Role | Email | Password |
|---|---|---|
| Administrator | `admin@gildedstake.example` | `Admin#12345` |
| Manager | `manager@gildedstake.example` | `Manager#12345` |
| Teller | `teller@gildedstake.example` | `Teller#12345` |
| Auditor | `auditor@gildedstake.example` | `Auditor#12345` |

**Change or remove these before any real deployment** — they are clearly-labelled
demonstration credentials only (see `Data/IdentitySeeder.cs`). Anyone can also
self-register from `/Auth/Register`; new accounts are always created with
**Teller** access, and an Administrator can promote them afterwards from
**Manage Accounts** in the navbar.

> **Upgrading from a pre-RBAC copy of this project?** The database is
> provisioned with `EnsureCreated()`, which only creates a schema for a
> **brand-new** database — it will not retrofit the new Identity tables onto
> a database created by an earlier version of this app. Drop the existing
> `GildedStakeDb` database (or point the connection string at a fresh
> database name) before running this version.

## Role-based access control

| | Administrator | Manager | Teller | Auditor |
|---|:---:|:---:|:---:|:---:|
| View clients, accounts, transactions | ✅ | ✅ | ✅ | ✅ |
| Register / edit a client | ✅ | ✅ | ✅ | — |
| Open / edit an account | ✅ | ✅ | ✅ | — |
| Post a transaction | ✅ | ✅ | ✅ | — |
| View the Betting Board & odds | ✅ | ✅ | ✅ | ✅ |
| Place a bet | ✅ | ✅ | ✅ | — |
| Delete a client | ✅ | ✅ | — | — |
| Close / reopen an account | ✅ | ✅ | — | — |
| Edit a posted transaction | ✅ | ✅ | — | — |
| Create / close / settle / void a betting market | ✅ | ✅ | — | — |
| Manage system accounts & roles | ✅ | — | — | — |

Enforcement is layered, not cosmetic:

- **Server-side** — every controller action carries `[Authorize]` or
  `[Authorize(Roles = "...")]` (see `Common/Roles.cs` for the role groupings
  used throughout). A default policy set in `Program.cs` requires sign-in on
  every controller unless explicitly marked `[AllowAnonymous]`.
- **UI-level** — buttons and form fields the current role cannot use are
  hidden or disabled in the relevant Razor views, so the interface never
  offers an action that would be rejected.
- **Safety rules** — an Administrator cannot deactivate their own account
  while signed in as it, and the system will not let the last remaining
  Administrator be demoted or deactivated, so the house can never end up
  locked out of its own account management.

## Getting started

1. **Prerequisites**
   - .NET SDK 10.0.301 or later
   - A running SQL Server instance (LocalDB, a full SQL Server install, or a
     container — anything reachable from the connection string below)

2. **Configure the connection string**

   Edit `src/GildedStake.Web/appsettings.json` (or use `dotnet user-secrets`)
   and set `ConnectionStrings:GildedStakeConnection` to point at your SQL
   Server instance. The default targets LocalDB:

   ```json
   "GildedStakeConnection": "Server=(localdb)\\MSSQLLocalDB;Database=GildedStakeDb;Trusted_Connection=True;MultipleActiveResultSets=true;TrustServerCertificate=True"
   ```

3. **Restore and run**

   ```bash
   cd src/GildedStake.Web
   dotnet restore
   dotnet run
   ```

   On first run the app automatically creates the database schema, creates
   the `vw_UserAccountSummary` view and `sp_GetAccountStatement` stored
   procedure, and seeds three demonstration clients with accounts and
   transactions so the UI is immediately usable — no manual seeding step is
   required. See `Data/DbInitializer.cs`.

4. **(Optional) Generate versioned EF Core migrations**

   The app provisions its schema via `EnsureCreated()` for a zero-friction
   first run. If you'd prefer versioned migrations instead (recommended for
   a real deployment pipeline), swap `DbInitializer` to use `Migrate()` and
   generate an initial migration:

   ```bash
   dotnet tool install --global dotnet-ef
   cd src/GildedStake.Web
   dotnet ef migrations add InitialCreate
   dotnet ef database update
   ```

5. **Run the tests**

   ```bash
   cd src/GildedStake.Tests
   dotnet test
   ```

## Feature walkthrough

| Requirement | Where it lives |
|---|---|
| Sign up / sign in / sign out | `Controllers/AuthController.cs`, `Views/Auth/Login.cshtml`, `Views/Auth/Register.cshtml` |
| Role-based access control (Administrator/Manager/Teller/Auditor) | `Common/Roles.cs`, `[Authorize(Roles = ...)]` on every controller, `Program.cs` (default policy) |
| Manage system accounts & roles (Administrator only) | `AuthController.ManageAccounts/CreateAccount/ChangeRole/ToggleActive`, `Views/Auth/ManageAccounts.cshtml` |
| Navbar (Home / Users / About / Contact) on every page | `Views/Shared/_Layout.cshtml` |
| Home, About, Contact pages | `Controllers/HomeController.cs`, `Views/Home/*` |
| Working contact form | `HomeController.Contact` (POST) persists to `ContactMessages` table |
| User list: search by ID number / surname / account number, pagination (10/page), create | `Controllers/UsersController.cs`, `Views/Users/Index.cshtml` |
| User details: edit & save, add account, list linked accounts | `Controllers/UsersController.cs`, `Views/Users/Details.cshtml` |
| Account details: edit & save, add transaction, list transactions, close/reopen | `Controllers/AccountsController.cs`, `Views/Accounts/Details.cshtml` |
| Transaction details: edit & save, date picker, capture date auto-updates | `Controllers/TransactionsController.cs`, `Views/Transactions/*` |
| The Betting Board: markets, selections, odds | `Controllers/BettingController.cs`, `Views/Betting/Index.cshtml`, `Views/Betting/Details.cshtml` |
| Place a bet against a client account | `BettingController.PlaceBet`, `Views/Betting/PlaceBet.cshtml` — reachable from Account Details |
| Create / close / settle / void a market | `BettingController.Create/Close/Settle/Void`, `Views/Betting/Create.cshtml`, `Views/Betting/Settle.cshtml` |
| Business rules & validation | `Services/*Service.cs` (see inline rule comments), `ViewModels/*` (data annotations) |
| SQL Server, view/stored procedure, indexing | `Data/DbInitializer.cs`, `Data/Configurations/*` |

## Betting, end to end

Betting sits on top of the existing account/transaction ledger rather than
beside it — a bet never becomes a second source of truth for an account's
balance.

**Domain model** (`Models/Betting/`):
- **BettingEvent** — a market (a race, a fight, a match), with a category,
  venue, date, and a status: `Open` → `Closed` → `Settled`, or `Voided`.
- **BettingSelection** — one backable outcome within an event (a runner, a
  fighter), carrying decimal odds (a stake of R100 at odds of 3.50 pays
  R350.00 if it wins).
- **Bet** — a single stake placed by an account against one selection. Odds
  are captured at the moment of placement, so a later odds change never
  retroactively changes an existing bet's payout.

**The flow:**
1. A market is created (Administrator/Manager) with two or more selections
   and their odds — from the Betting Board's **New Event** button.
2. A bet is placed **from a client's Account Details page** (Administrator,
   Manager or Teller) — never from the Betting Board directly, since placing
   a bet always needs an account context. The stake is validated against the
   account's live balance, then posted as an ordinary Debit transaction *and*
   a `Bet` row, atomically, in the same way every other transaction is posted.
3. A market is **settled** (Administrator/Manager) by choosing the winning
   selection. Every pending bet on that market is resolved in one atomic
   operation: winning bets are marked `Won` and their payout is posted as a
   Credit transaction; every other bet is marked `Lost` with no further
   money movement, since the stake was already taken at placement.
4. A market can instead be **voided** (e.g. the event was cancelled) —
   every pending bet is marked `Void` and its stake refunded in full as a
   Credit transaction.

**Business rules enforced in `Services/BettingService.cs`:**
- A bet cannot be placed on a closed betting account, or on a market that
  isn't `Open`.
- A stake can never exceed the account's current balance.
- A market needs at least two selections, each with distinct names and
  odds of at least 1.01.
- A market can only be settled or voided once; a settled market can never
  be voided, and a voided market can never be settled.

## Business rules implemented

- A user can only be created once with a given ID number (unique index +
  service-level check).
- A user may have unlimited accounts; a user may only be deleted if they
  have no accounts, or all of their accounts are closed.
- Account numbers are unique across the whole house.
- Accounts can only be opened for an already-existing user, never while the
  user is still being created.
- The outstanding balance is never directly editable — it is always derived
  from posted transactions and recalculated atomically alongside every
  transaction write.
- An account cannot be closed while its balance is non-zero, and no
  transactions may be posted to (or edited on) a closed account.
- The transaction date can never be in the future; the transaction amount
  can never be zero; the system-controlled capture timestamp refreshes on
  every create/edit and cannot be set by the user.

## Design language

The UI uses a deep charcoal/black background with a warm gold accent
(`#d4af6a`), Playfair Display for headings, Inter for body copy, soft card
elevation, pill-shaped gold buttons, and a toast/flash-message system —
aiming for the feel of a private banking hall rather than a typical CRUD
scaffold.
