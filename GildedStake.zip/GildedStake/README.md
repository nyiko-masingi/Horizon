# The Gilded Stake

*A private house for the discerning wager.*

The Gilded Stake is an ASP.NET Core MVC (.NET 10) application built for the
Horizon DevCamp final capstone. It manages a wagering company's **users**,
their **betting accounts**, and every **transaction** posted against those
accounts — with server-rendered views, SQL Server persistence, and a
luxurious dark-and-gold visual identity.

## Tech stack

- **.NET 10** / ASP.NET Core MVC
- **Entity Framework Core 10** (Code First) against **Microsoft SQL Server**
- A SQL **view** (`vw_UserAccountSummary`) and a **stored procedure**
  (`sp_GetAccountStatement`) that the presentation layer reads through
- Bootstrap 5 + Bootstrap Icons + hand-written CSS design system (no build
  step required — everything loads from CDN except the two custom files in
  `wwwroot/css` and `wwwroot/js`)
- xUnit test project (`GildedStake.Tests`) covering the service layer's
  business rules against the EF Core InMemory provider

## Solution layout

```
GildedStake.sln
src/
  GildedStake.Web/       ASP.NET Core MVC application
    Models/               EF Core entities (User, Account, Transaction, ContactMessage)
    Data/                 DbContext, Fluent API configurations, DbInitializer (schema + view/SP + seed data)
    Services/              Business logic layer (IUserService, IAccountService, ITransactionService, IContactService)
    ViewModels/            Form/view models with data-annotation validation
    Controllers/           HomeController, UsersController, AccountsController, TransactionsController
    Middleware/             Centralised exception handling
    Views/                  Razor views + shared layout
    wwwroot/                site.css, site.js, favicon
  GildedStake.Tests/      xUnit tests for the service layer (see TESTING.md)
```

## Getting started

1. **Prerequisites**
   - .NET SDK 10.0.301 or later
   - A running SQL Server instance (LocalDB, a full SQL Server install, or a
     container — anything reachable from the connection string below)

2. **Configure the connection string**

   Edit `src/GildedStake.Web/appsettings.json` (or use `dotnet user-secrets`)
   and set `ConnectionStrings:GildedStakeConnection` to point at your SQL
   Server instance. The default targets LocalDB:

   ```json
   "GildedStakeConnection": "Server=(localdb)\\MSSQLLocalDB;Database=GildedStakeDb;Trusted_Connection=True;MultipleActiveResultSets=true;TrustServerCertificate=True"
   ```

3. **Restore and run**

   ```bash
   cd src/GildedStake.Web
   dotnet restore
   dotnet run
   ```

   On first run the app automatically creates the database schema, creates
   the `vw_UserAccountSummary` view and `sp_GetAccountStatement` stored
   procedure, and seeds three demonstration clients with accounts and
   transactions so the UI is immediately usable — no manual seeding step is
   required. See `Data/DbInitializer.cs`.

4. **(Optional) Generate versioned EF Core migrations**

   The app provisions its schema via `EnsureCreated()` for a zero-friction
   first run. If you'd prefer versioned migrations instead (recommended for
   a real deployment pipeline), swap `DbInitializer` to use `Migrate()` and
   generate an initial migration:

   ```bash
   dotnet tool install --global dotnet-ef
   cd src/GildedStake.Web
   dotnet ef migrations add InitialCreate
   dotnet ef database update
   ```

5. **Run the tests**

   ```bash
   cd src/GildedStake.Tests
   dotnet test
   ```

## Feature walkthrough

| Requirement | Where it lives |
|---|---|
| Navbar (Home / Users / About / Contact) on every page | `Views/Shared/_Layout.cshtml` |
| Home, About, Contact pages | `Controllers/HomeController.cs`, `Views/Home/*` |
| Working contact form | `HomeController.Contact` (POST) persists to `ContactMessages` table |
| User list: search by ID number / surname / account number, pagination (10/page), create | `Controllers/UsersController.cs`, `Views/Users/Index.cshtml` |
| User details: edit & save, add account, list linked accounts | `Controllers/UsersController.cs`, `Views/Users/Details.cshtml` |
| Account details: edit & save, add transaction, list transactions, close/reopen | `Controllers/AccountsController.cs`, `Views/Accounts/Details.cshtml` |
| Transaction details: edit & save, date picker, capture date auto-updates | `Controllers/TransactionsController.cs`, `Views/Transactions/*` |
| Business rules & validation | `Services/*Service.cs` (see inline rule comments), `ViewModels/*` (data annotations) |
| SQL Server, view/stored procedure, indexing | `Data/DbInitializer.cs`, `Data/Configurations/*` |

## Business rules implemented

- A user can only be created once with a given ID number (unique index +
  service-level check).
- A user may have unlimited accounts; a user may only be deleted if they
  have no accounts, or all of their accounts are closed.
- Account numbers are unique across the whole house.
- Accounts can only be opened for an already-existing user, never while the
  user is still being created.
- The outstanding balance is never directly editable — it is always derived
  from posted transactions and recalculated atomically alongside every
  transaction write.
- An account cannot be closed while its balance is non-zero, and no
  transactions may be posted to (or edited on) a closed account.
- The transaction date can never be in the future; the transaction amount
  can never be zero; the system-controlled capture timestamp refreshes on
  every create/edit and cannot be set by the user.

## Design language

The UI uses a deep charcoal/black background with a warm gold accent
(`#d4af6a`), Playfair Display for headings, Inter for body copy, soft card
elevation, pill-shaped gold buttons, and a toast/flash-message system —
aiming for the feel of a private banking hall rather than a typical CRUD
scaffold.
