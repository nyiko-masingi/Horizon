using GildedStake.Web.Data.Configurations;
using GildedStake.Web.Models;
using Microsoft.EntityFrameworkCore;

namespace GildedStake.Web.Data;

public class ApplicationDbContext : DbContext
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
        : base(options)
    {
    }

    public DbSet<User> Users => Set<User>();
    public DbSet<Account> Accounts => Set<Account>();
    public DbSet<Transaction> Transactions => Set<Transaction>();
    public DbSet<ContactMessage> ContactMessages => Set<ContactMessage>();

    /// <summary>Keyless read model backed by the vw_UserAccountSummary SQL view.</summary>
    public DbSet<UserAccountSummary> UserAccountSummaries => Set<UserAccountSummary>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.ApplyConfiguration(new UserConfiguration());
        modelBuilder.ApplyConfiguration(new AccountConfiguration());
        modelBuilder.ApplyConfiguration(new TransactionConfiguration());
        modelBuilder.ApplyConfiguration(new ContactMessageConfiguration());

        // The keyless read model maps onto a real SQL Server view (vw_UserAccountSummary)
        // and is only meaningful against a relational provider. Non-relational test
        // providers (e.g. the EF Core InMemory provider used by GildedStake.Tests)
        // skip it so business-rule unit tests don't need a real database view.
        if (Database.IsRelational())
        {
            modelBuilder.ApplyConfiguration(new UserAccountSummaryConfiguration());
        }
        else
        {
            // Without a relational provider there is no view to back this keyless
            // read model, so exclude it from the model entirely rather than let EF's
            // DbSet convention discover it (which would otherwise fail key validation).
            modelBuilder.Ignore<UserAccountSummary>();
        }

        base.OnModelCreating(modelBuilder);
    }
}
