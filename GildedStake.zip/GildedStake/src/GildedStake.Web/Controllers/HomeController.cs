using System.Diagnostics;
using GildedStake.Web.Models;
using GildedStake.Web.Services;
using GildedStake.Web.ViewModels.Contact;
using Microsoft.AspNetCore.Mvc;

namespace GildedStake.Web.Controllers;

public class HomeController : Controller
{
    private readonly IContactService _contactService;
    private readonly ILogger<HomeController> _logger;

    public HomeController(IContactService contactService, ILogger<HomeController> logger)
    {
        _contactService = contactService;
        _logger = logger;
    }

    public IActionResult Index() => View();

    public IActionResult About() => View();

    [HttpGet]
    public IActionResult Contact() => View(new ContactFormViewModel());

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Contact(ContactFormViewModel model, CancellationToken ct)
    {
        if (!ModelState.IsValid)
        {
            return View(model);
        }

        var message = new ContactMessage
        {
            Name = model.Name.Trim(),
            Email = model.Email.Trim(),
            Subject = model.Subject.Trim(),
            Message = model.Message.Trim()
        };

        await _contactService.SubmitAsync(message, ct);

        TempData["ContactSuccess"] = "Thank you — your message has reached our concierge team. We will respond within one business day.";
        return RedirectToAction(nameof(Contact));
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        var requestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier;
        return View("Error", requestId);
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult HttpStatus(int code)
    {
        Response.StatusCode = code;
        return View("HttpStatus", code);
    }
}
