using GildedStake.Web.Services;
using GildedStake.Web.ViewModels.Accounts;
using Microsoft.AspNetCore.Mvc;

namespace GildedStake.Web.Controllers;

public class AccountsController : Controller
{
    private readonly IAccountService _accountService;
    private readonly IUserService _userService;
    private readonly ILogger<AccountsController> _logger;

    public AccountsController(IAccountService accountService, IUserService userService, ILogger<AccountsController> logger)
    {
        _accountService = accountService;
        _userService = userService;
        _logger = logger;
    }

    // GET /Accounts/Create?userId=5
    [HttpGet]
    public async Task<IActionResult> Create(int userId, CancellationToken ct)
    {
        var user = await _userService.GetByIdAsync(userId, ct);
        if (user is null)
        {
            return RedirectToAction("HttpStatus", "Home", new { code = 404 });
        }

        var model = new AccountFormViewModel { UserId = userId, UserFullName = user.FullName };
        return View(model);
    }

    // POST /Accounts/Create
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(AccountFormViewModel model, CancellationToken ct)
    {
        if (!ModelState.IsValid)
        {
            var user = await _userService.GetByIdAsync(model.UserId, ct);
            model.UserFullName = user?.FullName;
            return View(model);
        }

        var account = await _accountService.CreateAsync(model.UserId, model.ToEntity(), ct);
        TempData["SuccessMessage"] = $"Account \"{account.AccountNumber}\" was opened successfully.";
        return RedirectToAction(nameof(Details), new { id = account.Id });
    }

    // GET /Accounts/Details/5
    [HttpGet]
    public async Task<IActionResult> Details(int id, CancellationToken ct)
    {
        var account = await _accountService.GetWithTransactionsAsync(id, ct);
        if (account is null)
        {
            return RedirectToAction("HttpStatus", "Home", new { code = 404 });
        }

        var model = new AccountDetailsViewModel
        {
            Form = AccountFormViewModel.FromEntity(account),
            Transactions = account.Transactions.ToList()
        };

        return View(model);
    }

    // POST /Accounts/Details/5
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Details(int id, AccountDetailsViewModel model, CancellationToken ct)
    {
        model.Form.Id = id;

        if (!ModelState.IsValid)
        {
            var account = await _accountService.GetWithTransactionsAsync(id, ct);
            model.Transactions = account?.Transactions.ToList() ?? new();
            return View(model);
        }

        await _accountService.UpdateAsync(model.Form.ToEntity(), ct);
        TempData["SuccessMessage"] = "Account details were saved.";
        return RedirectToAction(nameof(Details), new { id });
    }

    // POST /Accounts/Close/5
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Close(int id, CancellationToken ct)
    {
        await _accountService.CloseAsync(id, ct);
        TempData["SuccessMessage"] = "The account was closed.";
        return RedirectToAction(nameof(Details), new { id });
    }

    // POST /Accounts/Reopen/5
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Reopen(int id, CancellationToken ct)
    {
        await _accountService.ReopenAsync(id, ct);
        TempData["SuccessMessage"] = "The account was reopened.";
        return RedirectToAction(nameof(Details), new { id });
    }
}
