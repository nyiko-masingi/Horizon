using GildedStake.Web.Services;
using GildedStake.Web.ViewModels.Transactions;
using Microsoft.AspNetCore.Mvc;

namespace GildedStake.Web.Controllers;

public class TransactionsController : Controller
{
    private readonly ITransactionService _transactionService;
    private readonly IAccountService _accountService;
    private readonly ILogger<TransactionsController> _logger;

    public TransactionsController(ITransactionService transactionService, IAccountService accountService, ILogger<TransactionsController> logger)
    {
        _transactionService = transactionService;
        _accountService = accountService;
        _logger = logger;
    }

    // GET /Transactions/Create?accountId=5
    [HttpGet]
    public async Task<IActionResult> Create(int accountId, CancellationToken ct)
    {
        var account = await _accountService.GetByIdAsync(accountId, ct);
        if (account is null)
        {
            return RedirectToAction("HttpStatus", "Home", new { code = 404 });
        }

        var model = new TransactionFormViewModel { AccountId = accountId, AccountNumber = account.AccountNumber };
        return View(model);
    }

    // POST /Transactions/Create
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(TransactionFormViewModel model, CancellationToken ct)
    {
        if (model.TransactionDate > DateOnly.FromDateTime(DateTime.Today))
        {
            ModelState.AddModelError(nameof(model.TransactionDate), "The transaction date cannot be in the future.");
        }

        if (!ModelState.IsValid)
        {
            var account = await _accountService.GetByIdAsync(model.AccountId, ct);
            model.AccountNumber = account?.AccountNumber;
            return View(model);
        }

        await _transactionService.CreateAsync(model.AccountId, model.ToEntity(), ct);
        TempData["SuccessMessage"] = "The transaction was posted and the account balance updated.";
        return RedirectToAction("Details", "Accounts", new { id = model.AccountId });
    }

    // GET /Transactions/Edit/5
    [HttpGet]
    public async Task<IActionResult> Edit(int id, CancellationToken ct)
    {
        var transaction = await _transactionService.GetByIdAsync(id, ct);
        if (transaction is null)
        {
            return RedirectToAction("HttpStatus", "Home", new { code = 404 });
        }

        return View(TransactionFormViewModel.FromEntity(transaction));
    }

    // POST /Transactions/Edit/5
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, TransactionFormViewModel model, CancellationToken ct)
    {
        model.Id = id;

        if (model.TransactionDate > DateOnly.FromDateTime(DateTime.Today))
        {
            ModelState.AddModelError(nameof(model.TransactionDate), "The transaction date cannot be in the future.");
        }

        if (!ModelState.IsValid)
        {
            return View(model);
        }

        await _transactionService.UpdateAsync(model.ToEntity(), ct);
        TempData["SuccessMessage"] = "The transaction was updated and the account balance recalculated.";
        return RedirectToAction("Details", "Accounts", new { id = model.AccountId });
    }
}
