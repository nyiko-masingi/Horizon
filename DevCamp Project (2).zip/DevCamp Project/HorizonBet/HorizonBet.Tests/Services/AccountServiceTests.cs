using HorizonBet.Web.Models.Domain;
using HorizonBet.Web.Services;
using HorizonBet.Web.Services.Exceptions;
using Xunit;

namespace HorizonBet.Tests.Services;

public class AccountServiceTests
{
    private static async Task<User> SeedUserAsync(HorizonBet.Web.Data.ApplicationDbContext db)
    {
        var user = new User
        {
            IdNumber = "8001015800083",
            FirstName = "Thabo",
            LastName = "Nkosi",
            Email = "thabo@example.com",
            DateOfBirth = new DateTime(1980, 1, 1)
        };
        db.Users.Add(user);
        await db.SaveChangesAsync();
        return user;
    }

    [Fact]
    public async Task CreateAsync_Throws_WhenUserDoesNotExist()
    {
        await using var db = TestDbContextFactory.Create();
        var sut = new AccountService(db, TestDbContextFactory.Logger<AccountService>());

        var account = new Account { AccountNumber = "HB-1" };

        await Assert.ThrowsAsync<NotFoundException>(() => sut.CreateAsync(userId: 999, account));
    }

    [Fact]
    public async Task CreateAsync_Throws_WhenAccountNumberAlreadyExists()
    {
        await using var db = TestDbContextFactory.Create();
        var sut = new AccountService(db, TestDbContextFactory.Logger<AccountService>());
        var user = await SeedUserAsync(db);

        await sut.CreateAsync(user.UserId, new Account { AccountNumber = "HB-1" });

        await Assert.ThrowsAsync<ConflictException>(() => sut.CreateAsync(user.UserId, new Account { AccountNumber = "HB-1" }));
    }

    [Fact]
    public async Task CreateAsync_StartsWithZeroBalanceAndOpenStatus()
    {
        await using var db = TestDbContextFactory.Create();
        var sut = new AccountService(db, TestDbContextFactory.Logger<AccountService>());
        var user = await SeedUserAsync(db);

        var account = await sut.CreateAsync(user.UserId, new Account { AccountNumber = "HB-1", Balance = 999 });

        Assert.Equal(0m, account.Balance);
        Assert.Equal(AccountStatus.Open, account.Status);
    }

    [Fact]
    public async Task UpdateAsync_NeverChangesBalance()
    {
        await using var db = TestDbContextFactory.Create();
        var sut = new AccountService(db, TestDbContextFactory.Logger<AccountService>());
        var user = await SeedUserAsync(db);
        var account = await sut.CreateAsync(user.UserId, new Account { AccountNumber = "HB-1" });

        var tracked = await db.Accounts.FindAsync(account.AccountId);
        tracked!.Balance = 500;
        await db.SaveChangesAsync();

        await sut.UpdateAsync(new Account { AccountId = account.AccountId, AccountNumber = "HB-1-RENAMED", AccountType = AccountType.Casino, Balance = 9999 });

        var reloaded = await sut.GetByIdAsync(account.AccountId);
        Assert.Equal(500m, reloaded!.Balance);
        Assert.Equal("HB-1-RENAMED", reloaded.AccountNumber);
    }

    [Fact]
    public async Task CloseAsync_Throws_WhenBalanceIsNotZero()
    {
        await using var db = TestDbContextFactory.Create();
        var sut = new AccountService(db, TestDbContextFactory.Logger<AccountService>());
        var user = await SeedUserAsync(db);
        var account = await sut.CreateAsync(user.UserId, new Account { AccountNumber = "HB-1" });

        var tracked = await db.Accounts.FindAsync(account.AccountId);
        tracked!.Balance = 100;
        await db.SaveChangesAsync();

        await Assert.ThrowsAsync<BusinessRuleException>(() => sut.CloseAsync(account.AccountId));
    }

    [Fact]
    public async Task CloseAsync_Succeeds_WhenBalanceIsZero()
    {
        await using var db = TestDbContextFactory.Create();
        var sut = new AccountService(db, TestDbContextFactory.Logger<AccountService>());
        var user = await SeedUserAsync(db);
        var account = await sut.CreateAsync(user.UserId, new Account { AccountNumber = "HB-1" });

        await sut.CloseAsync(account.AccountId);

        var reloaded = await sut.GetByIdAsync(account.AccountId);
        Assert.Equal(AccountStatus.Closed, reloaded!.Status);
        Assert.NotNull(reloaded.DateClosed);
    }

    [Fact]
    public async Task ReopenAsync_SetsStatusBackToOpen()
    {
        await using var db = TestDbContextFactory.Create();
        var sut = new AccountService(db, TestDbContextFactory.Logger<AccountService>());
        var user = await SeedUserAsync(db);
        var account = await sut.CreateAsync(user.UserId, new Account { AccountNumber = "HB-1" });
        await sut.CloseAsync(account.AccountId);

        await sut.ReopenAsync(account.AccountId);

        var reloaded = await sut.GetByIdAsync(account.AccountId);
        Assert.Equal(AccountStatus.Open, reloaded!.Status);
        Assert.Null(reloaded.DateClosed);
    }
}
