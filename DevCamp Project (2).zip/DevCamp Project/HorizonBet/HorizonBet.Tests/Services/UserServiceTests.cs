using HorizonBet.Web.Models.Domain;
using HorizonBet.Web.Services;
using HorizonBet.Web.Services.Exceptions;
using Xunit;

namespace HorizonBet.Tests.Services;

public class UserServiceTests
{
    private static User NewUser(string idNumber = "8001015800083") => new()
    {
        IdNumber = idNumber,
        FirstName = "Thabo",
        LastName = "Nkosi",
        Email = "thabo@example.com",
        DateOfBirth = new DateTime(1980, 1, 1)
    };

    [Fact]
    public async Task CreateAsync_PersistsUser_WhenIdNumberIsUnique()
    {
        await using var db = TestDbContextFactory.Create();
        var sut = new UserService(db, TestDbContextFactory.Logger<UserService>());

        var created = await sut.CreateAsync(NewUser());

        Assert.NotEqual(0, created.UserId);
        Assert.Equal(1, db.Users.Count());
    }

    [Fact]
    public async Task CreateAsync_Throws_WhenIdNumberAlreadyExists()
    {
        await using var db = TestDbContextFactory.Create();
        var sut = new UserService(db, TestDbContextFactory.Logger<UserService>());

        await sut.CreateAsync(NewUser());

        await Assert.ThrowsAsync<ConflictException>(() => sut.CreateAsync(NewUser()));
    }

    [Fact]
    public async Task UpdateAsync_Throws_WhenIdNumberBelongsToAnotherUser()
    {
        await using var db = TestDbContextFactory.Create();
        var sut = new UserService(db, TestDbContextFactory.Logger<UserService>());

        var userA = await sut.CreateAsync(NewUser("8001015800083"));
        var userB = await sut.CreateAsync(NewUser("9203125800084"));

        userB.IdNumber = userA.IdNumber;

        await Assert.ThrowsAsync<ConflictException>(() => sut.UpdateAsync(userB));
    }

    [Fact]
    public async Task UpdateAsync_Succeeds_WhenIdNumberUnchanged()
    {
        await using var db = TestDbContextFactory.Create();
        var sut = new UserService(db, TestDbContextFactory.Logger<UserService>());

        var user = await sut.CreateAsync(NewUser());
        user.FirstName = "Sipho";

        await sut.UpdateAsync(user);

        var reloaded = await sut.GetByIdAsync(user.UserId);
        Assert.Equal("Sipho", reloaded!.FirstName);
    }

    [Fact]
    public async Task DeleteAsync_Throws_WhenUserHasAnOpenAccount()
    {
        await using var db = TestDbContextFactory.Create();
        var sut = new UserService(db, TestDbContextFactory.Logger<UserService>());

        var user = await sut.CreateAsync(NewUser());
        db.Accounts.Add(new Account { UserId = user.UserId, AccountNumber = "HB-1", Status = AccountStatus.Open });
        await db.SaveChangesAsync();

        await Assert.ThrowsAsync<BusinessRuleException>(() => sut.DeleteAsync(user.UserId));
    }

    [Fact]
    public async Task DeleteAsync_Succeeds_WhenUserHasNoAccounts()
    {
        await using var db = TestDbContextFactory.Create();
        var sut = new UserService(db, TestDbContextFactory.Logger<UserService>());

        var user = await sut.CreateAsync(NewUser());

        await sut.DeleteAsync(user.UserId);

        Assert.Null(await sut.GetByIdAsync(user.UserId));
    }

    [Fact]
    public async Task DeleteAsync_Succeeds_WhenAllAccountsAreClosed()
    {
        await using var db = TestDbContextFactory.Create();
        var sut = new UserService(db, TestDbContextFactory.Logger<UserService>());

        var user = await sut.CreateAsync(NewUser());
        db.Accounts.Add(new Account { UserId = user.UserId, AccountNumber = "HB-1", Status = AccountStatus.Closed, Balance = 0 });
        await db.SaveChangesAsync();

        await sut.DeleteAsync(user.UserId);

        Assert.Null(await sut.GetByIdAsync(user.UserId));
    }

    [Fact]
    public async Task GetByIdAsync_ReturnsNull_WhenUserDoesNotExist()
    {
        await using var db = TestDbContextFactory.Create();
        var sut = new UserService(db, TestDbContextFactory.Logger<UserService>());

        Assert.Null(await sut.GetByIdAsync(999));
    }
}
