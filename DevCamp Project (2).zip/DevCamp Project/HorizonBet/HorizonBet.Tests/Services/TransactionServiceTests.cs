using HorizonBet.Web.Data;
using HorizonBet.Web.Models.Domain;
using HorizonBet.Web.Services;
using HorizonBet.Web.Services.Exceptions;
using Xunit;

namespace HorizonBet.Tests.Services;

public class TransactionServiceTests
{
    private static async Task<Account> SeedOpenAccountAsync(ApplicationDbContext db, decimal balance = 0m)
    {
        var user = new User
        {
            IdNumber = "8001015800083",
            FirstName = "Thabo",
            LastName = "Nkosi",
            Email = "thabo@example.com",
            DateOfBirth = new DateTime(1980, 1, 1)
        };
        db.Users.Add(user);
        await db.SaveChangesAsync();

        var account = new Account { UserId = user.UserId, AccountNumber = "HB-1", Status = AccountStatus.Open, Balance = balance };
        db.Accounts.Add(account);
        await db.SaveChangesAsync();
        return account;
    }

    [Fact]
    public async Task CreateAsync_Throws_WhenAccountIsClosed()
    {
        await using var db = TestDbContextFactory.Create();
        var sut = new TransactionService(db, TestDbContextFactory.Logger<TransactionService>());
        var account = await SeedOpenAccountAsync(db);
        account.Status = AccountStatus.Closed;
        await db.SaveChangesAsync();

        var tx = new Transaction { TransactionDate = DateTime.Today, Type = TransactionType.Credit, Amount = 100 };

        await Assert.ThrowsAsync<BusinessRuleException>(() => sut.CreateAsync(account.AccountId, tx));
    }

    [Fact]
    public async Task CreateAsync_Throws_WhenTransactionDateIsInTheFuture()
    {
        await using var db = TestDbContextFactory.Create();
        var sut = new TransactionService(db, TestDbContextFactory.Logger<TransactionService>());
        var account = await SeedOpenAccountAsync(db);

        var tx = new Transaction { TransactionDate = DateTime.Today.AddDays(1), Type = TransactionType.Credit, Amount = 100 };

        await Assert.ThrowsAsync<BusinessRuleException>(() => sut.CreateAsync(account.AccountId, tx));
    }

    [Fact]
    public async Task CreateAsync_Throws_WhenAmountIsZero()
    {
        await using var db = TestDbContextFactory.Create();
        var sut = new TransactionService(db, TestDbContextFactory.Logger<TransactionService>());
        var account = await SeedOpenAccountAsync(db);

        var tx = new Transaction { TransactionDate = DateTime.Today, Type = TransactionType.Credit, Amount = 0 };

        await Assert.ThrowsAsync<BusinessRuleException>(() => sut.CreateAsync(account.AccountId, tx));
    }

    [Fact]
    public async Task CreateAsync_Credit_IncreasesAccountBalance()
    {
        await using var db = TestDbContextFactory.Create();
        var sut = new TransactionService(db, TestDbContextFactory.Logger<TransactionService>());
        var account = await SeedOpenAccountAsync(db, balance: 100m);

        await sut.CreateAsync(account.AccountId, new Transaction { TransactionDate = DateTime.Today, Type = TransactionType.Credit, Amount = 50 });

        var reloaded = await db.Accounts.FindAsync(account.AccountId);
        Assert.Equal(150m, reloaded!.Balance);
    }

    [Fact]
    public async Task CreateAsync_Debit_DecreasesAccountBalance()
    {
        await using var db = TestDbContextFactory.Create();
        var sut = new TransactionService(db, TestDbContextFactory.Logger<TransactionService>());
        var account = await SeedOpenAccountAsync(db, balance: 100m);

        await sut.CreateAsync(account.AccountId, new Transaction { TransactionDate = DateTime.Today, Type = TransactionType.Debit, Amount = 30 });

        var reloaded = await db.Accounts.FindAsync(account.AccountId);
        Assert.Equal(70m, reloaded!.Balance);
    }

    [Fact]
    public async Task CreateAsync_SetsCaptureDate_RegardlessOfInput()
    {
        await using var db = TestDbContextFactory.Create();
        var sut = new TransactionService(db, TestDbContextFactory.Logger<TransactionService>());
        var account = await SeedOpenAccountAsync(db);

        var tx = new Transaction
        {
            TransactionDate = DateTime.Today,
            Type = TransactionType.Credit,
            Amount = 20,
            CaptureDate = new DateTime(2000, 1, 1) // caller-supplied value must be ignored
        };

        var created = await sut.CreateAsync(account.AccountId, tx);

        Assert.True(created.CaptureDate > new DateTime(2000, 1, 2));
    }

    [Fact]
    public async Task UpdateAsync_ReversesOldAmountAndAppliesNewAmount()
    {
        await using var db = TestDbContextFactory.Create();
        var sut = new TransactionService(db, TestDbContextFactory.Logger<TransactionService>());
        var account = await SeedOpenAccountAsync(db, balance: 0m);

        var created = await sut.CreateAsync(account.AccountId, new Transaction { TransactionDate = DateTime.Today, Type = TransactionType.Credit, Amount = 100 });
        Assert.Equal(100m, (await db.Accounts.FindAsync(account.AccountId))!.Balance);

        await sut.UpdateAsync(new Transaction { TransactionId = created.TransactionId, TransactionDate = DateTime.Today, Type = TransactionType.Credit, Amount = 40 });

        var reloaded = await db.Accounts.FindAsync(account.AccountId);
        Assert.Equal(40m, reloaded!.Balance);
    }

    [Fact]
    public async Task UpdateAsync_Throws_WhenAccountIsClosed()
    {
        await using var db = TestDbContextFactory.Create();
        var sut = new TransactionService(db, TestDbContextFactory.Logger<TransactionService>());
        var account = await SeedOpenAccountAsync(db, balance: 0m);
        var created = await sut.CreateAsync(account.AccountId, new Transaction { TransactionDate = DateTime.Today, Type = TransactionType.Credit, Amount = 100 });

        var tracked = await db.Accounts.FindAsync(account.AccountId);
        tracked!.Balance = 0;
        tracked.Status = AccountStatus.Closed;
        await db.SaveChangesAsync();

        await Assert.ThrowsAsync<BusinessRuleException>(() =>
            sut.UpdateAsync(new Transaction { TransactionId = created.TransactionId, TransactionDate = DateTime.Today, Type = TransactionType.Credit, Amount = 50 }));
    }
}
