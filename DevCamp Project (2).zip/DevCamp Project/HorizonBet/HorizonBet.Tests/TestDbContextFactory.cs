using HorizonBet.Web.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging.Abstractions;

namespace HorizonBet.Tests;

/// <summary>
/// Builds an isolated, per-test EF Core InMemory database. Each test gets its own database name so
/// tests never interfere with one another.
///
/// Note: the "vw_UserAccountSummary" view and "sp_GetAccountStatement" stored procedure that
/// UserService.SearchAsync and TransactionService.GetForAccountAsync rely on only exist in a real
/// SQL Server database (see Database/Scripts). The InMemory provider cannot execute raw SQL or
/// populate keyless view-backed entities, so those two read paths are covered by manual/integration
/// testing against SQL Server instead (see TESTING.md) - everything else is exercised here.
/// </summary>
internal static class TestDbContextFactory
{
    public static ApplicationDbContext Create()
    {
        var options = new DbContextOptionsBuilder<ApplicationDbContext>()
            .UseInMemoryDatabase(Guid.NewGuid().ToString())
            .Options;

        return new ApplicationDbContext(options);
    }

    public static Microsoft.Extensions.Logging.ILogger<T> Logger<T>() => NullLogger<T>.Instance;
}
