/*
    vw_UserAccountSummary
    ----------------------
    Backs the Users list/search page (HorizonBet.Web.Services.UserService.SearchAsync).
    Pre-computes the account count per user in the database so the presentation layer never has
    to load every account just to display a count. The view is composable - the application adds
    its own WHERE / ORDER BY / OFFSET-FETCH (Skip/Take) on top of it for search + pagination.

    Run this once against the HorizonBetDb database after applying EF Core migrations:
        sqlcmd -S (localdb)\mssqllocaldb -d HorizonBetDb -i Database\Scripts\01_Views.sql
        sqlcmd -S (localdb)\mssqllocaldb -d HorizonBetDb -i Database\Scripts\02_StoredProcedures.sql
*/
IF OBJECT_ID('dbo.vw_UserAccountSummary', 'V') IS NOT NULL
    DROP VIEW dbo.vw_UserAccountSummary;
GO

CREATE VIEW dbo.vw_UserAccountSummary
AS
    SELECT
        u.UserId,
        u.IdNumber,
        u.FirstName,
        u.LastName,
        u.Email,
        u.PhoneNumber,
        u.DateOfBirth,
        u.DateCreated,
        COUNT(a.AccountId) AS AccountCount
    FROM dbo.Users u
    LEFT JOIN dbo.Accounts a ON a.UserId = u.UserId
    GROUP BY
        u.UserId, u.IdNumber, u.FirstName, u.LastName, u.Email,
        u.PhoneNumber, u.DateOfBirth, u.DateCreated;
GO
