/*
    sp_GetAccountStatement
    -----------------------
    Backs the Account Details page's transaction list (HorizonBet.Web.Services.TransactionService.GetForAccountAsync).
    Returns every transaction for one account, most recent first. Its result-set shape mirrors the
    Transactions table exactly so EF Core can map rows straight back onto the Transaction entity via
    FromSqlInterpolated - no further LINQ composition is applied on top (SQL Server stored procedures
    are not composable), so the ordering/filtering happens entirely inside the procedure.
*/
IF OBJECT_ID('dbo.sp_GetAccountStatement', 'P') IS NOT NULL
    DROP PROCEDURE dbo.sp_GetAccountStatement;
GO

CREATE PROCEDURE dbo.sp_GetAccountStatement
    @AccountId INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        t.TransactionId,
        t.AccountId,
        t.TransactionDate,
        t.CaptureDate,
        t.Type,
        t.Amount,
        t.Description
    FROM dbo.Transactions t
    WHERE t.AccountId = @AccountId
    ORDER BY t.TransactionDate DESC, t.TransactionId DESC;
END
GO
