# Rubric Mapping

Line-by-line walkthrough of how Horizon Bet satisfies each item on the DevCamp Capstone Project Rubric
(target band: 9–10 / max marks on every technical criterion).

## 1.1 Architecture and MVC Separation (10)

Four clean layers, each with a single responsibility:

- **Models** (`Models/Domain/*.cs`) — `User`, `Account`, `Transaction` hold data and the handful of
  invariants that don't need a database round-trip (`Account.Close()`, `Account.ApplyTransaction()`,
  `Transaction.EnsureAmountNotZero()`, etc.).
- **Services** (`Services/*.cs`) — all business rules that *do* need the database (uniqueness checks,
  cross-entity checks like "does this user have open accounts") live here, behind `IUserService`,
  `IAccountService`, `ITransactionService`.
- **Controllers** (`Controllers/*.cs`) — thin: bind a ViewModel, call one service method, map the result
  back to a ViewModel or redirect. No LINQ-to-EF, no business rules, no direct `DbContext` usage anywhere
  in a controller.
- **Views** (`Views/**/*.cshtml`) — render `ViewModels` only; zero business logic, only display/formatting
  (badges for status, currency formatting, etc.).

Dependency flow is one-directional: `Controller → Service → DbContext`, documented in README.md Section 1.

## 1.2 Backend Programming: Controllers & Models (10)

- Every controller action that touches the database is `async`/`await` and takes a `CancellationToken`.
- Actions return `IActionResult` consistently (`View(...)`, `RedirectToAction(...)`, `BadRequest()`).
- `ViewModels` (not entities) are what every form binds to (`UserCreateViewModel`, `UserDetailsViewModel`,
  `AccountDetailsViewModel`, `TransactionEditViewModel`, `AddAccountViewModel`) — entities never reach a
  View or a form post, so overposting a field like `Balance` or `Status` is structurally impossible, not
  just discouraged.
- IDs always come from the route (`int id`), never trusted from the posted body alone — e.g.
  `UsersController.Edit(int id, UserDetailsViewModel model)` 400s if `id != model.UserId`.
- Domain invariants live on the entities themselves (`Account.Close()`, `Account.ApplyTransaction()`,
  `User.EnsureCanBeDeleted()`) rather than being re-implemented ad-hoc in each service method.
- `AsNoTracking()` is used for every read-only query (`UserService.GetByIdAsync`,
  `AccountService.GetByIdAsync`, `TransactionService.GetByIdAsync/GetForAccountAsync`).

## 1.3 Service Logic/Quality (5)

- Multi-step writes (posting a transaction *and* updating the account balance) are wrapped in an explicit
  `Database.BeginTransactionAsync()` / `CommitAsync()` / `RollbackAsync()` block in
  `TransactionService.CreateAsync` and `UpdateAsync` — see the `try`/`catch` around both.
- Domain exceptions (`NotFoundException`, `ConflictException`, `BusinessRuleException`) give callers a
  consistent, typed way to react instead of bubbling up raw `DbUpdateException`s.
- `UserServiceTests`, `AccountServiceTests`, `TransactionServiceTests` (21 tests total) cover the happy
  paths and the edge cases (duplicate keys, closed accounts, zero amounts, future dates) with EF Core
  InMemory — see [TESTING.md](TESTING.md).
- Methods are short and single-purpose; no method does more than "validate → mutate → save".

## 1.4 Database & Persistence (10)

- Fluent API configuration per entity (`Data/Configurations/*.cs`) — explicit keys, max lengths, decimal
  precision, enum-to-string conversions, and `DeleteBehavior.Restrict` on both foreign keys (deleting a
  user/account is only ever done through the service layer's own guarded `DeleteAsync`/`Close` methods).
- Migrations are generated via the standard `dotnet ef migrations add` workflow and checked into
  `Data/Migrations/` (see README.md Section 3) — no ad-hoc `EnsureCreated()` shortcuts.
- Deterministic seed data (`Data/SeedData.cs`, wired up via `HasData` in each configuration) — two users,
  three accounts, three transactions, all with fixed IDs/dates so the migration is reproducible.
- Read queries use `AsNoTracking()` throughout; the Users list uses `Skip`/`Take` pagination
  (`UserService.SearchAsync`) capped at a configurable page size (default 10, per the spec's optional
  requirement).
- A SQL **view** (`vw_UserAccountSummary`) and a **stored procedure** (`sp_GetAccountStatement`) return
  data to the presentation layer per the spec's explicit database requirement — see README.md Section 4
  and `Database/Scripts/`.
- Indexing: unique indexes on `Users.IdNumber` and `Accounts.AccountNumber` (enforcing two business rules
  at the database layer as well as the service layer), plus supporting indexes on `Users.LastName`,
  `Accounts.UserId`, `Accounts(UserId, Status)`, and `Transactions(AccountId, TransactionDate)` for the
  queries the app actually runs.
- Optimistic concurrency: `Account.RowVersion` is a `[Timestamp]` column, guarding against two staff
  members editing the same account at once.

## 1.5 Input Validation & Error Handling (10)

- Data Annotations on every ViewModel (`[Required]`, `[EmailAddress]`, `[Range]`, `[StringLength]`, plus a
  custom `[NotInFuture]` attribute for the transaction date) validated both client-side (unobtrusive
  jQuery validation, wired up globally in `_Layout.cshtml`) and server-side (`ModelState.IsValid` checked
  in every POST action).
- Domain-level rules that can't be expressed as an attribute (uniqueness, "closed account" checks) are
  enforced in the service layer and surface back to the user as inline `ModelState` errors on the same
  form, not a generic failure page.
- `ExceptionHandlingMiddleware` centralises anything that *isn't* caught locally in a controller: maps
  `NotFoundException → 404`, `ConflictException → 409`, `BusinessRuleException → 400`, logs each one, and
  hands off to `UseStatusCodePagesWithReExecute` for a friendly, on-brand error page
  (`Views/Home/Error.cshtml`) — no raw exception details or stack traces are ever shown to the user.
  Genuinely unexpected exceptions still fall through to `UseExceptionHandler("/Home/Error")`.

## 1.6 CRUD (5)

Full Create/Read/Update/Delete on every main entity:

- **Users**: Create (`/Users/Create`), Read (`/Users` list + `/Users/Details/{id}`), Update (`/Users/Edit`),
  Delete (`/Users/Delete`, with confirmation dialog and a business-rule guard).
- **Accounts**: Create (`/Accounts/Create`, from the User Details page), Read (`/Accounts/Details/{id}`),
  Update (`/Accounts/Edit`), "soft delete" via Close/Reopen (deletion isn't in the spec for accounts —
  closing is the equivalent lifecycle action, and it's reversible).
- **Transactions**: Create (`/Transactions/Create`), Read (listed on Account Details), Update
  (`/Transactions/Edit`) — the spec doesn't call for transaction deletion (financial records should be
  corrected, not erased), so editing is the supported correction path.

Every delete/close path confirms with the user first and handles the "can't do that yet" edge cases
(duplicate keys, non-zero balance, open accounts) without crashing.

## 1.7 Views (10)

- One shared `_Layout.cshtml` with a single, consistent navbar (`asp-controller`/`asp-action` tag helpers,
  never a hard-coded `href`) and active-link highlighting.
- Partial reuse: `Views/Transactions/_Form.cshtml` is shared between Create and Edit instead of being
  duplicated.
- No business logic in a view — badges, currency formatting (`.ToString("C")`), and date formatting are
  the only "logic" present, and none of it makes a decision that changes what data exists.
- Empty states everywhere data could be missing (no users found, no accounts yet, no transactions yet)
  with a clear next action, not a blank table.
- Tag helpers (`asp-for`, `asp-validation-for`, `asp-items`) are used throughout instead of raw HTML
  `<input>`/`<select>`, keeping model binding and client validation automatically in sync with the
  ViewModels.

## 1.8 User Experience (10)

- Bootstrap 5 responsive grid throughout — the layout reflows correctly on mobile (navbar collapses to a
  hamburger menu).
- Every form shows inline, field-level validation messages instantly (unobtrusive validation) rather than
  only on submit.
- Native HTML5 `<input type="date">` date picker for transaction dates, with a `max` attribute that
  physically prevents picking a future date in the browser, backed by server-side validation too.
- Destructive actions (delete user, close account) require an explicit confirm dialog.
- Disabled buttons come with an explanatory note next to them (e.g. "This user cannot be deleted while
  they have open accounts") instead of silently doing nothing.
- Success/error banners (`TempData`) confirm the outcome of every action, and auto-dismiss after a few
  seconds (`wwwroot/js/site.js`) so they don't clutter the page.
- Bootstrap Icons are used consistently to reinforce actions (pencil = edit, trash = delete, lock/unlock =
  close/reopen).

## 1.9 Testing Documentation (10)

See [TESTING.md](TESTING.md): what's automated (21 xUnit tests over the service layer, with rationale for
what is and isn't covered by the InMemory provider), how to run them (`dotnet test`), and a 20-item manual
test checklist covering the view/stored-procedure-backed reads and full end-to-end UI flows, with expected
results for each.

## 1.10 Presentation (10) / 1.11 Project Orientation (5) / 1.12 Professionalism (5)

These three criteria are assessed live (a demo, a Q&A, and delivery/commit history) rather than something
that can be satisfied by the codebase alone. What the codebase can do to support them:

- The architecture walkthrough in this document and README.md Section 1 gives a ready-made narrative for
  the presentation ("problem → Users → Accounts → Transactions → limits").
- Small, single-purpose files and methods throughout make it straightforward to trace a request end-to-end
  live during Q&A (e.g. "capture a transaction" → `TransactionsController.Create` →
  `TransactionService.CreateAsync` → `Account.ApplyTransaction` → the DB transaction commit).
- Commit little and often as you build on top of this scaffold, with messages that describe *why*, to
  satisfy 1.12 — the codebase itself can't do that part for you.
