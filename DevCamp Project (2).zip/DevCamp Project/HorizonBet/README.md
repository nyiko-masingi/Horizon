# Horizon Bet — User, Account & Transaction Management

An ASP.NET Core MVC (.NET 10) solution built for the Horizon DevCamp capstone project. Horizon Bet is a
fictional betting company; this app is the internal tool staff use to register clients ("Users"), open
betting accounts for them, and capture the debit/credit transactions that make up each account's
balance history.

> **Build environment note:** this solution was authored on a machine with no .NET SDK installed, so it
> could not be compiled or run locally before hand-off. Every file was written carefully against the
> ASP.NET Core MVC APIs, but you should do a first build (Section 2) before relying on it, and report
> back anything that doesn't compile so it can be fixed immediately.
>
> The app targets `net10.0` and uses EF Core **8.0.10** packages (referencing an older-targeted NuGet
> package from a newer app is fully supported by .NET's compatibility model). If you'd rather have
> everything on matching EF Core 10.x packages, run `dotnet add package Microsoft.EntityFrameworkCore.SqlServer`
> (repeat for `.Design`/`.Tools`/`.InMemory`) with no version specified to pick up the latest compatible release.

---

## 1. Solution layout

```
HorizonBet/
├── HorizonBet.sln
├── HorizonBet.Web/                  ASP.NET Core MVC application
│   ├── Controllers/                 Home, Users, Accounts, Transactions
│   ├── Models/
│   │   ├── Domain/                  User, Account, Transaction entities + enums
│   │   ├── ReadModels/              UserAccountSummary (keyless, backs vw_UserAccountSummary)
│   │   └── ViewModels/              Everything a View binds to - entities never reach a View
│   ├── Data/
│   │   ├── ApplicationDbContext.cs
│   │   ├── Configurations/          Fluent API config per entity (keys, indexes, relationships)
│   │   ├── SeedData.cs              Deterministic seed rows applied via migrations
│   │   └── Migrations/              Created by `dotnet ef migrations add` (see Section 3)
│   ├── Services/                    Business logic layer (Controllers never talk to EF directly)
│   │   ├── Interfaces/
│   │   └── Exceptions/              NotFoundException, ConflictException, BusinessRuleException
│   ├── Middleware/                  ExceptionHandlingMiddleware (centralised error → status code)
│   ├── Views/                       Razor views, shared _Layout with the navbar
│   └── wwwroot/                     site.css, site.js, logo.svg
├── HorizonBet.Tests/                 xUnit + EF Core InMemory service-layer tests
└── Database/Scripts/                 SQL view + stored procedure (see Section 4)
```

**Architecture:** Controllers → Services → EF Core (`ApplicationDbContext`) → SQL Server. Views only
ever see `ViewModels`; domain entities never leak into a Razor view or get bound directly from a form,
so nothing can overpost a field like `Balance` from the browser.

---

## 2. Prerequisites

| Tool | Notes |
|---|---|
| [.NET 10 SDK](https://dotnet.microsoft.com/download/dotnet/10.0) | `dotnet --version` should report `10.x` |
| SQL Server (LocalDB, Express, or Developer) | LocalDB ships with the Visual Studio "ASP.NET and web development" workload, or install it standalone |
| EF Core CLI tool | `dotnet tool install --global dotnet-ef` (skip if already installed) |

---

## 3. First-time setup

Run these from the `HorizonBet/` folder (the one containing `HorizonBet.sln`).

```bash
# 1. Restore & build
dotnet restore
dotnet build

# 2. Generate the initial EF Core migration (creates HorizonBet.Web/Data/Migrations/*)
dotnet ef migrations add InitialCreate --project HorizonBet.Web --startup-project HorizonBet.Web

# 3. Create/update the database (uses the connection string in appsettings.json)
dotnet ef database update --project HorizonBet.Web --startup-project HorizonBet.Web
```

Step 3 is actually optional on its own — `Program.cs` calls `db.Database.Migrate()` automatically every
time the app starts, so the database will also be created/updated the first time you `dotnet run`. Step
2 (generating the migration) is the one thing you must do yourself, once, before the first run — commit
the resulting `Data/Migrations` folder to source control afterwards.

### 3a. Add the search view and stored procedure

Per the spec's database requirement, list/search data and account statements are returned to the
presentation layer via a SQL **view** and a **stored procedure** rather than ad-hoc LINQ. Run these once
against the database created in step 3:

```bash
sqlcmd -S "(localdb)\mssqllocaldb" -d HorizonBetDb -i Database/Scripts/01_Views.sql
sqlcmd -S "(localdb)\mssqllocaldb" -d HorizonBetDb -i Database/Scripts/02_StoredProcedures.sql
```

(Swap the `-S` server name/`-d` database name if you pointed `appsettings.json` at a different SQL
Server instance.) See [Database/Scripts](Database/Scripts) for what each script does and why.

### 3b. Run the app

```bash
dotnet run --project HorizonBet.Web
```

Browse to the HTTPS URL printed in the console (e.g. `https://localhost:7031`). Seed data (two users,
three accounts, three transactions) is inserted automatically by the initial migration so there's
something to look at immediately.

### 3c. Run the tests

```bash
dotnet test
```

See [TESTING.md](TESTING.md) for what's covered and how to read the results.

---

## 4. Database objects

| Object | Purpose | Used by |
|---|---|---|
| `vw_UserAccountSummary` | Pre-aggregates each user's account count in the database | `UserService.SearchAsync` — the Users list/search/pagination page |
| `sp_GetAccountStatement` | Returns every transaction for one account, most recent first | `TransactionService.GetForAccountAsync` — the Account Details page |

Indexes (all defined in `Data/Configurations/*.cs`, applied by the EF Core migration):

- Unique index on `Users.IdNumber` — enforces "a user can only be created once with the same ID number"
- Unique index on `Accounts.AccountNumber` — enforces "you cannot have duplicated account numbers"
- `Users.LastName`, `Accounts.UserId`, `Accounts(UserId, Status)`, `Transactions(AccountId, TransactionDate)` — support the search, account-listing, and delete-eligibility queries the app runs most often

---

## 5. Business rules implemented

| Rule | Where enforced |
|---|---|
| A user can only be created once with the same ID number | `UserService.CreateAsync`/`UpdateAsync` (checked against the DB) + unique index as a DB-level backstop |
| A user can have unlimited accounts | No cap anywhere in the model |
| A user can only be deleted once every account is closed (or they have none) | `User.EnsureCanBeDeleted()`, called from `UserService.DeleteAsync` |
| Account numbers cannot be duplicated | `AccountService.CreateAsync`/`UpdateAsync` + unique index |
| New accounts can only be added once the user already exists | `AccountService.CreateAsync` checks the user exists first; the UI only exposes "add account" from the User Details page, never during Create |
| The balance can never be edited directly | `AccountEditViewModel`/`AccountService.UpdateAsync` only ever map `AccountNumber`/`AccountType` — any posted `Balance` value is ignored |
| Balance updates whenever a transaction is added or an existing amount is changed | `Account.ApplyTransaction`/`ReverseTransaction`, called inside a DB transaction in `TransactionService` |
| An account can't be closed with a non-zero balance | `Account.Close()` |
| No transactions on a closed account | `Account.EnsureOpenForTransactions()`, checked on both create and edit |
| Transaction date can never be in the future | `[NotInFuture]` validation attribute (client + server) and `Transaction.EnsureTransactionDateNotInFuture()` (service-level backstop) |
| New transactions only after the account exists | Transactions are only ever created via `/Transactions/Create?accountId=`, reached from an existing Account Details page |
| Capture date is system-set, never user-editable | Not bound from the form at all; `TransactionService` always overwrites it with `DateTime.UtcNow` on both create and edit |
| Transaction amount can never be zero | `[Range(0.01, ...)]` + `Transaction.EnsureAmountNotZero()` |

---

## 6. Known limitations / assumptions

- **Contact form**: fully validates and gives the user feedback, but there's no real mail server in this
  environment to actually deliver the message — a production deployment would plug an email/notification
  service into `HomeController.Contact`.
- **Social links** on the Contact page point to the real platform homepages (Facebook/X/Instagram/WhatsApp)
  since Horizon Bet doesn't have real accounts on any of them — they're there to demonstrate working links,
  per the spec.
- **No authentication/authorization** — the spec doesn't call for a login system, so none was added.
- Currency is displayed with the server's default culture formatting (`ToString("C")`); for a real ZAR
  deployment you'd pin the culture to `en-ZA`.

---

## 7. Rubric mapping

See [RUBRIC_MAPPING.md](RUBRIC_MAPPING.md) for a line-by-line walkthrough of how the implementation meets
each item on the grading rubric.
