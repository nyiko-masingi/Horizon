using HorizonBet.Web.Services.Exceptions;

namespace HorizonBet.Web.Middleware;

/// <summary>
/// Centralized handling for the domain exceptions that a controller did not (or could not) catch locally
/// - e.g. a GET request for an id that no longer exists. Maps them to the right HTTP status code and lets
/// <c>UseStatusCodePagesWithReExecute</c> render a friendly error page for that code. Anything else is left
/// to bubble up to <c>UseExceptionHandler</c>, which renders a generic error page and logs the failure.
/// </summary>
public class ExceptionHandlingMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<ExceptionHandlingMiddleware> _logger;

    public ExceptionHandlingMiddleware(RequestDelegate next, ILogger<ExceptionHandlingMiddleware> logger)
    {
        _next = next;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        try
        {
            await _next(context);
        }
        catch (NotFoundException ex)
        {
            _logger.LogWarning(ex, "Not found while handling {Method} {Path}", context.Request.Method, context.Request.Path);
            await WriteStatusAsync(context, StatusCodes.Status404NotFound, ex.Message);
        }
        catch (ConflictException ex)
        {
            _logger.LogWarning(ex, "Conflict while handling {Method} {Path}", context.Request.Method, context.Request.Path);
            await WriteStatusAsync(context, StatusCodes.Status409Conflict, ex.Message);
        }
        catch (BusinessRuleException ex)
        {
            _logger.LogWarning(ex, "Business rule violation while handling {Method} {Path}", context.Request.Method, context.Request.Path);
            await WriteStatusAsync(context, StatusCodes.Status400BadRequest, ex.Message);
        }
    }

    private static Task WriteStatusAsync(HttpContext context, int statusCode, string message)
    {
        if (context.Response.HasStarted)
        {
            return Task.CompletedTask;
        }

        context.Items["ErrorMessage"] = message;
        context.Response.Clear();
        context.Response.StatusCode = statusCode;
        return Task.CompletedTask;
    }
}
