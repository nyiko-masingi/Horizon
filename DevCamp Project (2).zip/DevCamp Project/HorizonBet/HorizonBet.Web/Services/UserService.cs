using HorizonBet.Web.Data;
using HorizonBet.Web.Models.Domain;
using HorizonBet.Web.Models.ReadModels;
using HorizonBet.Web.Services.Exceptions;
using HorizonBet.Web.Services.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace HorizonBet.Web.Services;

public class UserService : IUserService
{
    private readonly ApplicationDbContext _db;
    private readonly ILogger<UserService> _logger;

    public UserService(ApplicationDbContext db, ILogger<UserService> logger)
    {
        _db = db;
        _logger = logger;
    }

    public async Task<PagedResult<UserAccountSummary>> SearchAsync(string? searchTerm, int page, int pageSize, CancellationToken ct = default)
    {
        page = page < 1 ? 1 : page;
        pageSize = pageSize is < 1 or > 100 ? 10 : pageSize;

        // Reads from vw_UserAccountSummary (Database/Scripts/01_Views.sql) so the account count is
        // computed in the database instead of being loaded and counted in C#.
        var query = _db.UserAccountSummaries.AsNoTracking();

        if (!string.IsNullOrWhiteSpace(searchTerm))
        {
            var term = searchTerm.Trim();

            // Matches on ID number, surname, or an account number belonging to the user (per spec).
            var matchingUserIds = await _db.Accounts.AsNoTracking()
                .Where(a => EF.Functions.Like(a.AccountNumber, $"%{term}%"))
                .Select(a => a.UserId)
                .Distinct()
                .ToListAsync(ct);

            query = query.Where(u =>
                EF.Functions.Like(u.IdNumber, $"%{term}%") ||
                EF.Functions.Like(u.LastName, $"%{term}%") ||
                matchingUserIds.Contains(u.UserId));
        }

        var totalCount = await query.CountAsync(ct);

        var items = await query
            .OrderBy(u => u.LastName).ThenBy(u => u.FirstName)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .ToListAsync(ct);

        return new PagedResult<UserAccountSummary>
        {
            Items = items,
            Page = page,
            PageSize = pageSize,
            TotalCount = totalCount
        };
    }

    public async Task<User?> GetByIdAsync(int userId, CancellationToken ct = default) =>
        await _db.Users
            .Include(u => u.Accounts)
            .AsNoTracking()
            .FirstOrDefaultAsync(u => u.UserId == userId, ct);

    public async Task<User> CreateAsync(User user, CancellationToken ct = default)
    {
        var idNumberTaken = await _db.Users.AsNoTracking().AnyAsync(u => u.IdNumber == user.IdNumber, ct);
        if (idNumberTaken)
        {
            throw new ConflictException($"A user with ID number '{user.IdNumber}' already exists.");
        }

        user.DateCreated = DateTime.UtcNow;
        _db.Users.Add(user);
        await _db.SaveChangesAsync(ct);

        _logger.LogInformation("Created user {UserId} ({IdNumber})", user.UserId, user.IdNumber);
        return user;
    }

    public async Task UpdateAsync(User user, CancellationToken ct = default)
    {
        var existing = await _db.Users.FirstOrDefaultAsync(u => u.UserId == user.UserId, ct)
            ?? throw new NotFoundException($"User with id {user.UserId} was not found.");

        var idNumberTaken = await _db.Users.AsNoTracking()
            .AnyAsync(u => u.IdNumber == user.IdNumber && u.UserId != user.UserId, ct);
        if (idNumberTaken)
        {
            throw new ConflictException($"A user with ID number '{user.IdNumber}' already exists.");
        }

        existing.IdNumber = user.IdNumber;
        existing.FirstName = user.FirstName;
        existing.LastName = user.LastName;
        existing.Email = user.Email;
        existing.PhoneNumber = user.PhoneNumber;
        existing.DateOfBirth = user.DateOfBirth;
        // DateCreated is deliberately never overwritten here - it is set once, at creation time.

        await _db.SaveChangesAsync(ct);
        _logger.LogInformation("Updated user {UserId}", user.UserId);
    }

    public async Task DeleteAsync(int userId, CancellationToken ct = default)
    {
        var user = await _db.Users
            .Include(u => u.Accounts)
            .FirstOrDefaultAsync(u => u.UserId == userId, ct)
            ?? throw new NotFoundException($"User with id {userId} was not found.");

        user.EnsureCanBeDeleted();

        _db.Users.Remove(user);
        await _db.SaveChangesAsync(ct);
        _logger.LogInformation("Deleted user {UserId}", userId);
    }
}
