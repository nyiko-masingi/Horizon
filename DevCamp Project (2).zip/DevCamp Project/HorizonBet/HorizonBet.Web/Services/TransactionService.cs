using HorizonBet.Web.Data;
using HorizonBet.Web.Models.Domain;
using HorizonBet.Web.Services.Exceptions;
using HorizonBet.Web.Services.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace HorizonBet.Web.Services;

public class TransactionService : ITransactionService
{
    private readonly ApplicationDbContext _db;
    private readonly ILogger<TransactionService> _logger;

    public TransactionService(ApplicationDbContext db, ILogger<TransactionService> logger)
    {
        _db = db;
        _logger = logger;
    }

    public async Task<Transaction?> GetByIdAsync(int transactionId, CancellationToken ct = default) =>
        await _db.Transactions
            .Include(t => t.Account)
            .AsNoTracking()
            .FirstOrDefaultAsync(t => t.TransactionId == transactionId, ct);

    public async Task<List<Transaction>> GetForAccountAsync(int accountId, CancellationToken ct = default) =>
        // Calls the sp_GetAccountStatement stored procedure (Database/Scripts/02_StoredProcedures.sql)
        // rather than a LINQ query, per the requirement that data returned to the presentation layer
        // go through stored procedures/views. The result is a plain list - no further LINQ composition
        // is applied on top, since SQL Server does not support composing over a stored procedure call.
        await _db.Transactions
            .FromSqlInterpolated($"EXEC dbo.sp_GetAccountStatement @AccountId = {accountId}")
            .AsNoTracking()
            .ToListAsync(ct);

    public async Task<Transaction> CreateAsync(int accountId, Transaction transaction, CancellationToken ct = default)
    {
        var account = await _db.Accounts.FirstOrDefaultAsync(a => a.AccountId == accountId, ct)
            ?? throw new NotFoundException($"Account with id {accountId} was not found.");

        account.EnsureOpenForTransactions();
        transaction.EnsureTransactionDateNotInFuture();
        transaction.EnsureAmountNotZero();

        transaction.AccountId = accountId;
        transaction.CaptureDate = DateTime.UtcNow;

        await using var dbTransaction = await _db.Database.BeginTransactionAsync(ct);
        try
        {
            _db.Transactions.Add(transaction);
            account.ApplyTransaction(transaction.Type, transaction.Amount);

            await _db.SaveChangesAsync(ct);
            await dbTransaction.CommitAsync(ct);
        }
        catch
        {
            await dbTransaction.RollbackAsync(ct);
            throw;
        }

        _logger.LogInformation("Created transaction {TransactionId} on account {AccountId}", transaction.TransactionId, accountId);
        return transaction;
    }

    public async Task UpdateAsync(Transaction transaction, CancellationToken ct = default)
    {
        var existing = await _db.Transactions
            .Include(t => t.Account)
            .FirstOrDefaultAsync(t => t.TransactionId == transaction.TransactionId, ct)
            ?? throw new NotFoundException($"Transaction with id {transaction.TransactionId} was not found.");

        var account = existing.Account
            ?? throw new NotFoundException($"Account for transaction {transaction.TransactionId} was not found.");

        account.EnsureOpenForTransactions();
        transaction.EnsureTransactionDateNotInFuture();
        transaction.EnsureAmountNotZero();

        await using var dbTransaction = await _db.Database.BeginTransactionAsync(ct);
        try
        {
            // Reverse the old amount's effect, apply the new one, so the balance never drifts.
            account.ReverseTransaction(existing.Type, existing.Amount);

            existing.TransactionDate = transaction.TransactionDate;
            existing.Type = transaction.Type;
            existing.Amount = transaction.Amount;
            existing.Description = transaction.Description;
            // Capture date is always reset to "now" on edit - the caller can never override it.
            existing.CaptureDate = DateTime.UtcNow;

            account.ApplyTransaction(existing.Type, existing.Amount);

            await _db.SaveChangesAsync(ct);
            await dbTransaction.CommitAsync(ct);
        }
        catch
        {
            await dbTransaction.RollbackAsync(ct);
            throw;
        }

        _logger.LogInformation("Updated transaction {TransactionId}", transaction.TransactionId);
    }
}
