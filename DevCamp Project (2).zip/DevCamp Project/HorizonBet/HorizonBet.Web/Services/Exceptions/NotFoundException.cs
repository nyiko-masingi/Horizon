namespace HorizonBet.Web.Services.Exceptions;

/// <summary>Thrown when an entity looked up by id does not exist.</summary>
public class NotFoundException : Exception
{
    public NotFoundException(string message) : base(message) { }
}
