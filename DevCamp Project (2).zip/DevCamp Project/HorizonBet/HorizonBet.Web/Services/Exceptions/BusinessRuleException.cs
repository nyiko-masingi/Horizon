namespace HorizonBet.Web.Services.Exceptions;

/// <summary>Thrown when an action would violate a documented business rule (e.g. closing an account with a non-zero balance).</summary>
public class BusinessRuleException : Exception
{
    public BusinessRuleException(string message) : base(message) { }
}
