namespace HorizonBet.Web.Services.Exceptions;

/// <summary>Thrown when a uniqueness constraint (e.g. duplicate ID number/account number) is violated.</summary>
public class ConflictException : Exception
{
    public ConflictException(string message) : base(message) { }
}
