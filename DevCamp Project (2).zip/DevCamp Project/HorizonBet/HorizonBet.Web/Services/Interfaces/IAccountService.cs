using HorizonBet.Web.Models.Domain;
using HorizonBet.Web.Services.Exceptions;

namespace HorizonBet.Web.Services.Interfaces;

public interface IAccountService
{
    /// <summary>Loads a single account together with its owning user and transactions. Returns null if not found.</summary>
    Task<Account?> GetByIdAsync(int accountId, CancellationToken ct = default);

    /// <summary>Creates a new account for an existing user. Throws <see cref="NotFoundException"/> if the user doesn't exist
    /// and <see cref="ConflictException"/> if the account number is already in use.</summary>
    Task<Account> CreateAsync(int userId, Account account, CancellationToken ct = default);

    /// <summary>Updates the editable fields of an account (account number/type only - never the balance).</summary>
    Task UpdateAsync(Account account, CancellationToken ct = default);

    /// <summary>Throws <see cref="BusinessRuleException"/> if the balance is not zero.</summary>
    Task CloseAsync(int accountId, CancellationToken ct = default);

    Task ReopenAsync(int accountId, CancellationToken ct = default);
}
