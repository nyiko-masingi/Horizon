using HorizonBet.Web.Models.Domain;
using HorizonBet.Web.Models.ReadModels;
using HorizonBet.Web.Services.Exceptions;

namespace HorizonBet.Web.Services.Interfaces;

public interface IUserService
{
    /// <summary>Searches users by ID number, surname, or an account number belonging to them; paginated.</summary>
    Task<PagedResult<UserAccountSummary>> SearchAsync(string? searchTerm, int page, int pageSize, CancellationToken ct = default);

    /// <summary>Loads a single user together with their accounts. Returns null if not found.</summary>
    Task<User?> GetByIdAsync(int userId, CancellationToken ct = default);

    Task<User> CreateAsync(User user, CancellationToken ct = default);

    Task UpdateAsync(User user, CancellationToken ct = default);

    /// <summary>Deletes a user. Throws <see cref="BusinessRuleException"/> if the user still has open accounts.</summary>
    Task DeleteAsync(int userId, CancellationToken ct = default);
}
