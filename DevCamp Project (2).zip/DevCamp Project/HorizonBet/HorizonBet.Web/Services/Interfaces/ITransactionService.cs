using HorizonBet.Web.Models.Domain;

namespace HorizonBet.Web.Services.Interfaces;

public interface ITransactionService
{
    Task<Transaction?> GetByIdAsync(int transactionId, CancellationToken ct = default);

    /// <summary>Returns all transactions for an account, most recent first, via the sp_GetAccountStatement stored procedure.</summary>
    Task<List<Transaction>> GetForAccountAsync(int accountId, CancellationToken ct = default);

    /// <summary>Creates a transaction and atomically updates the owning account's balance.</summary>
    Task<Transaction> CreateAsync(int accountId, Transaction transaction, CancellationToken ct = default);

    /// <summary>Edits a transaction and atomically reverses its old balance effect before applying the new one.
    /// The capture date is always reset to "now" and can never be supplied by the caller.</summary>
    Task UpdateAsync(Transaction transaction, CancellationToken ct = default);
}
