using HorizonBet.Web.Data;
using HorizonBet.Web.Models.Domain;
using HorizonBet.Web.Services.Exceptions;
using HorizonBet.Web.Services.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace HorizonBet.Web.Services;

public class AccountService : IAccountService
{
    private readonly ApplicationDbContext _db;
    private readonly ILogger<AccountService> _logger;

    public AccountService(ApplicationDbContext db, ILogger<AccountService> logger)
    {
        _db = db;
        _logger = logger;
    }

    public async Task<Account?> GetByIdAsync(int accountId, CancellationToken ct = default) =>
        await _db.Accounts
            .Include(a => a.User)
            .AsNoTracking()
            .FirstOrDefaultAsync(a => a.AccountId == accountId, ct);

    public async Task<Account> CreateAsync(int userId, Account account, CancellationToken ct = default)
    {
        // Business rule: new accounts can only be added for a user that already exists.
        var userExists = await _db.Users.AsNoTracking().AnyAsync(u => u.UserId == userId, ct);
        if (!userExists)
        {
            throw new NotFoundException($"User with id {userId} was not found.");
        }

        var accountNumberTaken = await _db.Accounts.AsNoTracking()
            .AnyAsync(a => a.AccountNumber == account.AccountNumber, ct);
        if (accountNumberTaken)
        {
            throw new ConflictException($"Account number '{account.AccountNumber}' is already in use.");
        }

        account.UserId = userId;
        account.Balance = 0m;
        account.Status = AccountStatus.Open;
        account.DateOpened = DateTime.UtcNow;
        account.DateClosed = null;

        _db.Accounts.Add(account);
        await _db.SaveChangesAsync(ct);

        _logger.LogInformation("Created account {AccountId} ({AccountNumber}) for user {UserId}", account.AccountId, account.AccountNumber, userId);
        return account;
    }

    public async Task UpdateAsync(Account account, CancellationToken ct = default)
    {
        var existing = await _db.Accounts.FirstOrDefaultAsync(a => a.AccountId == account.AccountId, ct)
            ?? throw new NotFoundException($"Account with id {account.AccountId} was not found.");

        var accountNumberTaken = await _db.Accounts.AsNoTracking()
            .AnyAsync(a => a.AccountNumber == account.AccountNumber && a.AccountId != account.AccountId, ct);
        if (accountNumberTaken)
        {
            throw new ConflictException($"Account number '{account.AccountNumber}' is already in use.");
        }

        // Deliberately only the editable fields are mapped - Balance/Status/UserId can never be
        // changed through this method, regardless of what a caller supplies.
        existing.AccountNumber = account.AccountNumber;
        existing.AccountType = account.AccountType;

        await _db.SaveChangesAsync(ct);
        _logger.LogInformation("Updated account {AccountId}", account.AccountId);
    }

    public async Task CloseAsync(int accountId, CancellationToken ct = default)
    {
        var account = await _db.Accounts.FirstOrDefaultAsync(a => a.AccountId == accountId, ct)
            ?? throw new NotFoundException($"Account with id {accountId} was not found.");

        account.Close();

        await _db.SaveChangesAsync(ct);
        _logger.LogInformation("Closed account {AccountId}", accountId);
    }

    public async Task ReopenAsync(int accountId, CancellationToken ct = default)
    {
        var account = await _db.Accounts.FirstOrDefaultAsync(a => a.AccountId == accountId, ct)
            ?? throw new NotFoundException($"Account with id {accountId} was not found.");

        account.Reopen();

        await _db.SaveChangesAsync(ct);
        _logger.LogInformation("Reopened account {AccountId}", accountId);
    }
}
