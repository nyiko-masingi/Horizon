using System.ComponentModel.DataAnnotations;
using HorizonBet.Web.Models.Domain;

namespace HorizonBet.Web.Models.ViewModels;

public class AccountDetailsViewModel
{
    public int AccountId { get; set; }

    [Required, StringLength(20)]
    [Display(Name = "Account Number")]
    public string AccountNumber { get; set; } = string.Empty;

    [Display(Name = "Account Type")]
    public AccountType AccountType { get; set; }

    // Read-only in the UI - the balance can only ever change via a posted transaction.
    public decimal Balance { get; set; }

    public AccountStatus Status { get; set; }

    public DateTime DateOpened { get; set; }

    public DateTime? DateClosed { get; set; }

    public int UserId { get; set; }

    [Display(Name = "Account Holder")]
    public string UserFullName { get; set; } = string.Empty;

    public List<TransactionListItemViewModel> Transactions { get; set; } = new();
}

public class TransactionListItemViewModel
{
    public int TransactionId { get; set; }
    public DateTime TransactionDate { get; set; }
    public DateTime CaptureDate { get; set; }
    public TransactionType Type { get; set; }
    public decimal Amount { get; set; }
    public string? Description { get; set; }
}
