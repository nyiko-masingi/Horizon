namespace HorizonBet.Web.Models.ViewModels;

public class UserListViewModel
{
    public string? SearchTerm { get; set; }

    public List<UserListItemViewModel> Users { get; set; } = new();

    public int Page { get; set; } = 1;

    public int PageSize { get; set; } = 10;

    public int TotalCount { get; set; }

    public int TotalPages => PageSize <= 0 ? 0 : (int)Math.Ceiling(TotalCount / (double)PageSize);

    public bool HasPreviousPage => Page > 1;

    public bool HasNextPage => Page < TotalPages;
}

public class UserListItemViewModel
{
    public int UserId { get; set; }
    public string IdNumber { get; set; } = string.Empty;
    public string FirstName { get; set; } = string.Empty;
    public string LastName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public int AccountCount { get; set; }
}
