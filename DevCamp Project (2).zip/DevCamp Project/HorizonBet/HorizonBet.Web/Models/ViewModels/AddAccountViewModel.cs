using System.ComponentModel.DataAnnotations;
using HorizonBet.Web.Models.Domain;

namespace HorizonBet.Web.Models.ViewModels;

/// <summary>Bound from the "add a new account" sub-form on the User Details page.</summary>
public class AddAccountViewModel
{
    public int UserId { get; set; }

    [Required(ErrorMessage = "Please enter an account number.")]
    [StringLength(20)]
    [Display(Name = "Account Number")]
    public string AccountNumber { get; set; } = string.Empty;

    [Display(Name = "Account Type")]
    public AccountType AccountType { get; set; } = AccountType.General;
}
