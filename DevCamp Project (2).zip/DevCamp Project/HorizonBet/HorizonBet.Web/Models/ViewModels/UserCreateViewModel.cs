using System.ComponentModel.DataAnnotations;

namespace HorizonBet.Web.Models.ViewModels;

public class UserCreateViewModel
{
    [Required(ErrorMessage = "ID number is required.")]
    [StringLength(13, MinimumLength = 5, ErrorMessage = "ID number must be between 5 and 13 characters.")]
    [Display(Name = "ID Number")]
    public string IdNumber { get; set; } = string.Empty;

    [Required, StringLength(100)]
    [Display(Name = "First Name")]
    public string FirstName { get; set; } = string.Empty;

    [Required, StringLength(100)]
    [Display(Name = "Surname")]
    public string LastName { get; set; } = string.Empty;

    [Required, EmailAddress, StringLength(256)]
    public string Email { get; set; } = string.Empty;

    [Phone, StringLength(20)]
    [Display(Name = "Phone Number")]
    public string? PhoneNumber { get; set; }

    [Required]
    [DataType(DataType.Date)]
    [Display(Name = "Date of Birth")]
    public DateTime DateOfBirth { get; set; } = DateTime.Today.AddYears(-18);
}
