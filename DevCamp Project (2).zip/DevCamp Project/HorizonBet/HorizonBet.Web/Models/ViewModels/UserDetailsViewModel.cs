using System.ComponentModel.DataAnnotations;
using HorizonBet.Web.Models.Domain;

namespace HorizonBet.Web.Models.ViewModels;

public class UserDetailsViewModel
{
    public int UserId { get; set; }

    [Required(ErrorMessage = "ID number is required.")]
    [StringLength(13, MinimumLength = 5, ErrorMessage = "ID number must be between 5 and 13 characters.")]
    [Display(Name = "ID Number")]
    public string IdNumber { get; set; } = string.Empty;

    [Required, StringLength(100)]
    [Display(Name = "First Name")]
    public string FirstName { get; set; } = string.Empty;

    [Required, StringLength(100)]
    [Display(Name = "Surname")]
    public string LastName { get; set; } = string.Empty;

    [Required, EmailAddress, StringLength(256)]
    public string Email { get; set; } = string.Empty;

    [Phone, StringLength(20)]
    [Display(Name = "Phone Number")]
    public string? PhoneNumber { get; set; }

    [Required]
    [DataType(DataType.Date)]
    [Display(Name = "Date of Birth")]
    public DateTime DateOfBirth { get; set; }

    [Display(Name = "Client Since")]
    public DateTime DateCreated { get; set; }

    public List<AccountListItemViewModel> Accounts { get; set; } = new();

    public bool CanBeDeleted => Accounts.All(a => a.Status == AccountStatus.Closed);

    // --- "Add new account" sub-form (only used/validated when the user submits it) ---

    [StringLength(20)]
    [Display(Name = "New Account Number")]
    public string? NewAccountNumber { get; set; }

    [Display(Name = "New Account Type")]
    public AccountType NewAccountType { get; set; } = AccountType.General;
}

public class AccountListItemViewModel
{
    public int AccountId { get; set; }
    public string AccountNumber { get; set; } = string.Empty;
    public AccountType AccountType { get; set; }
    public decimal Balance { get; set; }
    public AccountStatus Status { get; set; }
}
