using System.ComponentModel.DataAnnotations;
using HorizonBet.Web.Models.Domain;

namespace HorizonBet.Web.Models.ViewModels;

public class TransactionEditViewModel
{
    /// <summary>0 when creating a new transaction.</summary>
    public int TransactionId { get; set; }

    public int AccountId { get; set; }

    [Display(Name = "Account Number")]
    public string AccountNumber { get; set; } = string.Empty;

    [Required(ErrorMessage = "Please pick a transaction date.")]
    [DataType(DataType.Date)]
    [NotInFuture]
    [Display(Name = "Transaction Date")]
    public DateTime TransactionDate { get; set; } = DateTime.Today;

    [Required]
    [Display(Name = "Type")]
    public TransactionType Type { get; set; } = TransactionType.Credit;

    [Required(ErrorMessage = "Please enter an amount.")]
    [Range(0.01, 1_000_000_000, ErrorMessage = "The amount must be greater than zero.")]
    public decimal Amount { get; set; }

    [StringLength(250)]
    public string? Description { get; set; }

    /// <summary>Read-only - set by the system on create/edit, never posted back as an editable field.</summary>
    [Display(Name = "Captured On")]
    public DateTime? CaptureDate { get; set; }

    public bool IsNew => TransactionId == 0;
}
