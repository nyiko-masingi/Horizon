using System.ComponentModel.DataAnnotations;

namespace HorizonBet.Web.Models.ViewModels;

public class ContactViewModel
{
    [Required, StringLength(100)]
    [Display(Name = "Your Name")]
    public string Name { get; set; } = string.Empty;

    [Required, EmailAddress, StringLength(256)]
    [Display(Name = "Your Email")]
    public string Email { get; set; } = string.Empty;

    [Required, StringLength(150)]
    public string Subject { get; set; } = string.Empty;

    [Required, StringLength(2000)]
    public string Message { get; set; } = string.Empty;

    public bool Submitted { get; set; }
}
