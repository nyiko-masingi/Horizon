using System.ComponentModel.DataAnnotations;

namespace HorizonBet.Web.Models.ViewModels;

/// <summary>Validation for the "transaction date can never be in the future" business rule, applied client- and server-side.</summary>
public class NotInFutureAttribute : ValidationAttribute
{
    public NotInFutureAttribute()
    {
        ErrorMessage = "The date cannot be in the future.";
    }

    public override bool IsValid(object? value)
    {
        if (value is not DateTime date)
        {
            return true; // let [Required] handle missing values
        }

        return date.Date <= DateTime.UtcNow.Date;
    }
}
