namespace HorizonBet.Web.Models.ViewModels;

public class ErrorViewModel
{
    public string? RequestId { get; set; }

    public int StatusCode { get; set; } = 500;

    public string? Message { get; set; }

    public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);

    public string Title => StatusCode switch
    {
        404 => "Not found",
        409 => "Conflict",
        400 => "Bad request",
        _ => "Something went wrong"
    };
}
