namespace HorizonBet.Web.Models.ReadModels;

/// <summary>
/// Keyless read model backed by the SQL view "vw_UserAccountSummary" (see Database/Scripts/01_Views.sql).
/// Used by the Users list/search page so that account counts are computed in the database rather than in C#.
/// </summary>
public class UserAccountSummary
{
    public int UserId { get; set; }
    public string IdNumber { get; set; } = string.Empty;
    public string FirstName { get; set; } = string.Empty;
    public string LastName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string? PhoneNumber { get; set; }
    public DateTime DateOfBirth { get; set; }
    public DateTime DateCreated { get; set; }
    public int AccountCount { get; set; }
}
