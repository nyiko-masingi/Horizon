namespace HorizonBet.Web.Models.Domain;

public enum AccountType
{
    Sports = 0,
    Casino = 1,
    General = 2
}
