namespace HorizonBet.Web.Models.Domain;

public enum AccountStatus
{
    Open = 0,
    Closed = 1
}
