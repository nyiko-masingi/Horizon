using System.ComponentModel.DataAnnotations;
using HorizonBet.Web.Services.Exceptions;

namespace HorizonBet.Web.Models.Domain;

/// <summary>A single debit or credit posted against an <see cref="Account"/>.</summary>
public class Transaction
{
    public int TransactionId { get; set; }

    public int AccountId { get; set; }

    public Account? Account { get; set; }

    /// <summary>The date the transaction is dated for (chosen via a date picker). Can never be in the future.</summary>
    [DataType(DataType.Date)]
    public DateTime TransactionDate { get; set; }

    /// <summary>The date/time the transaction record was captured or last modified. Set by the system only; never user-editable.</summary>
    public DateTime CaptureDate { get; set; } = DateTime.UtcNow;

    public TransactionType Type { get; set; }

    /// <summary>Always a positive magnitude; direction is carried by <see cref="Type"/>. Can never be zero.</summary>
    [Range(0.01, double.MaxValue)]
    public decimal Amount { get; set; }

    [StringLength(250)]
    public string? Description { get; set; }

    /// <summary>Business rule: the transaction date can never be in the future.</summary>
    public void EnsureTransactionDateNotInFuture()
    {
        if (TransactionDate.Date > DateTime.UtcNow.Date)
        {
            throw new BusinessRuleException("The transaction date cannot be in the future.");
        }
    }

    /// <summary>Business rule: the transaction amount can never be zero.</summary>
    public void EnsureAmountNotZero()
    {
        if (Amount == 0m)
        {
            throw new BusinessRuleException("The transaction amount cannot be zero.");
        }
    }
}
