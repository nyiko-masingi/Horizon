using System.ComponentModel.DataAnnotations;
using HorizonBet.Web.Services.Exceptions;

namespace HorizonBet.Web.Models.Domain;

/// <summary>A registered client of Horizon Bet who may hold one or more betting accounts.</summary>
public class User
{
    public int UserId { get; set; }

    [Required, StringLength(13, MinimumLength = 5)]
    public string IdNumber { get; set; } = string.Empty;

    [Required, StringLength(100)]
    public string FirstName { get; set; } = string.Empty;

    [Required, StringLength(100)]
    public string LastName { get; set; } = string.Empty;

    [Required, StringLength(256)]
    public string Email { get; set; } = string.Empty;

    [StringLength(20)]
    public string? PhoneNumber { get; set; }

    public DateTime DateOfBirth { get; set; }

    public DateTime DateCreated { get; set; } = DateTime.UtcNow;

    public ICollection<Account> Accounts { get; set; } = new List<Account>();

    public string FullName => $"{FirstName} {LastName}";

    /// <summary>Business rule: a user may only be deleted once every account they hold is closed (or they hold none).</summary>
    public bool CanBeDeleted() => Accounts.All(a => a.Status == AccountStatus.Closed);

    /// <summary>Throws if deletion would violate the "no open accounts" invariant.</summary>
    public void EnsureCanBeDeleted()
    {
        if (!CanBeDeleted())
        {
            throw new BusinessRuleException(
                $"'{FullName}' cannot be deleted while they have one or more open accounts.");
        }
    }
}
