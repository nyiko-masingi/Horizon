using System.ComponentModel.DataAnnotations;
using HorizonBet.Web.Services.Exceptions;

namespace HorizonBet.Web.Models.Domain;

/// <summary>A betting account owned by a single <see cref="User"/>, holding zero or more transactions.</summary>
public class Account
{
    public int AccountId { get; set; }

    [Required, StringLength(20)]
    public string AccountNumber { get; set; } = string.Empty;

    public AccountType AccountType { get; set; } = AccountType.General;

    /// <summary>Outstanding balance. Never directly settable by a user — only ever changed via <see cref="ApplyTransaction"/> / <see cref="ReverseTransaction"/>.</summary>
    public decimal Balance { get; set; }

    public AccountStatus Status { get; set; } = AccountStatus.Open;

    public DateTime DateOpened { get; set; } = DateTime.UtcNow;

    public DateTime? DateClosed { get; set; }

    public int UserId { get; set; }

    public User? User { get; set; }

    public ICollection<Transaction> Transactions { get; set; } = new List<Transaction>();

    /// <summary>Optimistic concurrency token.</summary>
    [Timestamp]
    public byte[]? RowVersion { get; set; }

    /// <summary>Business rule: no transactions may be posted to a closed account.</summary>
    public void EnsureOpenForTransactions()
    {
        if (Status == AccountStatus.Closed)
        {
            throw new BusinessRuleException(
                $"Account '{AccountNumber}' is closed and cannot accept new or edited transactions.");
        }
    }

    /// <summary>Business rule: an account can only be closed once its balance is exactly zero.</summary>
    public void Close()
    {
        if (Status == AccountStatus.Closed)
        {
            return;
        }

        if (Balance != 0m)
        {
            throw new BusinessRuleException(
                $"Account '{AccountNumber}' cannot be closed while its balance is {Balance:C} (must be zero).");
        }

        Status = AccountStatus.Closed;
        DateClosed = DateTime.UtcNow;
    }

    public void Reopen()
    {
        if (Status == AccountStatus.Open)
        {
            return;
        }

        Status = AccountStatus.Open;
        DateClosed = null;
    }

    /// <summary>Applies a transaction's signed effect to the running balance. Credits increase the balance, debits decrease it.</summary>
    public void ApplyTransaction(TransactionType type, decimal amount) => Balance += SignedAmount(type, amount);

    /// <summary>Reverses a previously-applied transaction's effect (used before re-applying an edited amount/type).</summary>
    public void ReverseTransaction(TransactionType type, decimal amount) => Balance -= SignedAmount(type, amount);

    private static decimal SignedAmount(TransactionType type, decimal amount) =>
        type == TransactionType.Credit ? amount : -amount;
}
