namespace HorizonBet.Web.Models.Domain;

public enum TransactionType
{
    Credit = 0,
    Debit = 1
}
