using HorizonBet.Web.Models.Domain;
using HorizonBet.Web.Models.ViewModels;
using HorizonBet.Web.Services.Exceptions;
using HorizonBet.Web.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace HorizonBet.Web.Controllers;

public class UsersController : Controller
{
    private const int PageSize = 10;

    private readonly IUserService _userService;

    public UsersController(IUserService userService)
    {
        _userService = userService;
    }

    // GET /Users?searchTerm=&page=1
    public async Task<IActionResult> Index(string? searchTerm, int page = 1, CancellationToken ct = default)
    {
        var result = await _userService.SearchAsync(searchTerm, page, PageSize, ct);

        var vm = new UserListViewModel
        {
            SearchTerm = searchTerm,
            Page = result.Page,
            PageSize = result.PageSize,
            TotalCount = result.TotalCount,
            Users = result.Items.Select(u => new UserListItemViewModel
            {
                UserId = u.UserId,
                IdNumber = u.IdNumber,
                FirstName = u.FirstName,
                LastName = u.LastName,
                Email = u.Email,
                AccountCount = u.AccountCount
            }).ToList()
        };

        return View(vm);
    }

    // GET /Users/Create
    public IActionResult Create() => View(new UserCreateViewModel());

    // POST /Users/Create
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(UserCreateViewModel model, CancellationToken ct)
    {
        if (!ModelState.IsValid)
        {
            return View(model);
        }

        var user = new User
        {
            IdNumber = model.IdNumber.Trim(),
            FirstName = model.FirstName.Trim(),
            LastName = model.LastName.Trim(),
            Email = model.Email.Trim(),
            PhoneNumber = model.PhoneNumber?.Trim(),
            DateOfBirth = model.DateOfBirth
        };

        try
        {
            var created = await _userService.CreateAsync(user, ct);
            TempData["SuccessMessage"] = $"User '{created.FullName}' was created.";
            return RedirectToAction(nameof(Details), new { id = created.UserId });
        }
        catch (ConflictException ex)
        {
            ModelState.AddModelError(nameof(model.IdNumber), ex.Message);
            return View(model);
        }
    }

    // GET /Users/Details/5
    public async Task<IActionResult> Details(int id, CancellationToken ct)
    {
        var user = await _userService.GetByIdAsync(id, ct)
            ?? throw new NotFoundException($"User with id {id} was not found.");

        var vm = ToDetailsViewModel(user);
        ApplyAddAccountTempData(vm);
        return View(vm);
    }

    // POST /Users/Edit/5
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, UserDetailsViewModel model, CancellationToken ct)
    {
        if (id != model.UserId)
        {
            return BadRequest();
        }

        if (!ModelState.IsValid)
        {
            await RehydrateAccountsAsync(model, ct);
            return View("Details", model);
        }

        var user = new User
        {
            UserId = id,
            IdNumber = model.IdNumber.Trim(),
            FirstName = model.FirstName.Trim(),
            LastName = model.LastName.Trim(),
            Email = model.Email.Trim(),
            PhoneNumber = model.PhoneNumber?.Trim(),
            DateOfBirth = model.DateOfBirth
        };

        try
        {
            await _userService.UpdateAsync(user, ct);
            TempData["SuccessMessage"] = "User details were updated.";
            return RedirectToAction(nameof(Details), new { id });
        }
        catch (ConflictException ex)
        {
            ModelState.AddModelError(nameof(model.IdNumber), ex.Message);
            await RehydrateAccountsAsync(model, ct);
            return View("Details", model);
        }
    }

    // POST /Users/Delete/5
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Delete(int id, CancellationToken ct)
    {
        try
        {
            await _userService.DeleteAsync(id, ct);
            TempData["SuccessMessage"] = "User was deleted.";
        }
        catch (BusinessRuleException ex)
        {
            TempData["ErrorMessage"] = ex.Message;
        }

        return RedirectToAction(nameof(Index));
    }

    private static UserDetailsViewModel ToDetailsViewModel(User user) => new()
    {
        UserId = user.UserId,
        IdNumber = user.IdNumber,
        FirstName = user.FirstName,
        LastName = user.LastName,
        Email = user.Email,
        PhoneNumber = user.PhoneNumber,
        DateOfBirth = user.DateOfBirth,
        DateCreated = user.DateCreated,
        Accounts = user.Accounts
            .OrderBy(a => a.AccountNumber)
            .Select(a => new AccountListItemViewModel
            {
                AccountId = a.AccountId,
                AccountNumber = a.AccountNumber,
                AccountType = a.AccountType,
                Balance = a.Balance,
                Status = a.Status
            }).ToList()
    };

    private async Task RehydrateAccountsAsync(UserDetailsViewModel model, CancellationToken ct)
    {
        var existing = await _userService.GetByIdAsync(model.UserId, ct);
        if (existing is null)
        {
            return;
        }

        model.DateCreated = existing.DateCreated;
        model.Accounts = existing.Accounts
            .OrderBy(a => a.AccountNumber)
            .Select(a => new AccountListItemViewModel
            {
                AccountId = a.AccountId,
                AccountNumber = a.AccountNumber,
                AccountType = a.AccountType,
                Balance = a.Balance,
                Status = a.Status
            }).ToList();
    }

    private void ApplyAddAccountTempData(UserDetailsViewModel vm)
    {
        if (TempData["AddAccountNumber"] is string number)
        {
            vm.NewAccountNumber = number;
        }

        if (TempData["AddAccountError"] is string error)
        {
            ModelState.AddModelError(string.Empty, error);
        }
    }
}
