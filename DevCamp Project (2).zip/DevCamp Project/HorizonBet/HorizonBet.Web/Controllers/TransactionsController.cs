using HorizonBet.Web.Models.Domain;
using HorizonBet.Web.Models.ViewModels;
using HorizonBet.Web.Services.Exceptions;
using HorizonBet.Web.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace HorizonBet.Web.Controllers;

public class TransactionsController : Controller
{
    private readonly ITransactionService _transactionService;
    private readonly IAccountService _accountService;

    public TransactionsController(ITransactionService transactionService, IAccountService accountService)
    {
        _transactionService = transactionService;
        _accountService = accountService;
    }

    // GET /Transactions/Create?accountId=5
    public async Task<IActionResult> Create(int accountId, CancellationToken ct)
    {
        var account = await _accountService.GetByIdAsync(accountId, ct)
            ?? throw new NotFoundException($"Account with id {accountId} was not found.");

        if (account.Status == AccountStatus.Closed)
        {
            TempData["ErrorMessage"] = $"Account '{account.AccountNumber}' is closed - no transactions can be captured against it.";
            return RedirectToAction("Details", "Accounts", new { id = accountId });
        }

        var model = new TransactionEditViewModel
        {
            AccountId = accountId,
            AccountNumber = account.AccountNumber,
            TransactionDate = DateTime.Today
        };

        return View(model);
    }

    // POST /Transactions/Create
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(TransactionEditViewModel model, CancellationToken ct)
    {
        if (!ModelState.IsValid)
        {
            return View(model);
        }

        var transaction = new Transaction
        {
            TransactionDate = model.TransactionDate,
            Type = model.Type,
            Amount = model.Amount,
            Description = model.Description?.Trim()
        };

        try
        {
            await _transactionService.CreateAsync(model.AccountId, transaction, ct);
            TempData["SuccessMessage"] = "Transaction was captured.";
            return RedirectToAction("Details", "Accounts", new { id = model.AccountId });
        }
        catch (BusinessRuleException ex)
        {
            ModelState.AddModelError(string.Empty, ex.Message);
            return View(model);
        }
    }

    // GET /Transactions/Edit/5
    public async Task<IActionResult> Edit(int id, CancellationToken ct)
    {
        var transaction = await _transactionService.GetByIdAsync(id, ct)
            ?? throw new NotFoundException($"Transaction with id {id} was not found.");

        if (transaction.Account is { Status: AccountStatus.Closed })
        {
            TempData["ErrorMessage"] = "This account is closed - its transactions can no longer be edited.";
            return RedirectToAction("Details", "Accounts", new { id = transaction.AccountId });
        }

        var model = new TransactionEditViewModel
        {
            TransactionId = transaction.TransactionId,
            AccountId = transaction.AccountId,
            AccountNumber = transaction.Account?.AccountNumber ?? string.Empty,
            TransactionDate = transaction.TransactionDate,
            Type = transaction.Type,
            Amount = transaction.Amount,
            Description = transaction.Description,
            CaptureDate = transaction.CaptureDate
        };

        return View(model);
    }

    // POST /Transactions/Edit/5
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, TransactionEditViewModel model, CancellationToken ct)
    {
        if (id != model.TransactionId)
        {
            return BadRequest();
        }

        if (!ModelState.IsValid)
        {
            return View(model);
        }

        var transaction = new Transaction
        {
            TransactionId = id,
            TransactionDate = model.TransactionDate,
            Type = model.Type,
            Amount = model.Amount,
            Description = model.Description?.Trim()
        };

        try
        {
            await _transactionService.UpdateAsync(transaction, ct);
            TempData["SuccessMessage"] = "Transaction was updated.";
            return RedirectToAction("Details", "Accounts", new { id = model.AccountId });
        }
        catch (BusinessRuleException ex)
        {
            ModelState.AddModelError(string.Empty, ex.Message);
            return View(model);
        }
    }
}
