using HorizonBet.Web.Models.Domain;
using HorizonBet.Web.Models.ViewModels;
using HorizonBet.Web.Services.Exceptions;
using HorizonBet.Web.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace HorizonBet.Web.Controllers;

public class AccountsController : Controller
{
    private readonly IAccountService _accountService;
    private readonly ITransactionService _transactionService;

    public AccountsController(IAccountService accountService, ITransactionService transactionService)
    {
        _accountService = accountService;
        _transactionService = transactionService;
    }

    // GET /Accounts/Details/5
    public async Task<IActionResult> Details(int id, CancellationToken ct)
    {
        var account = await _accountService.GetByIdAsync(id, ct)
            ?? throw new NotFoundException($"Account with id {id} was not found.");

        var transactions = await _transactionService.GetForAccountAsync(id, ct);

        return View(ToDetailsViewModel(account, transactions));
    }

    // POST /Accounts/Edit/5
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, AccountDetailsViewModel model, CancellationToken ct)
    {
        if (id != model.AccountId)
        {
            return BadRequest();
        }

        // Only AccountNumber/AccountType are validated - Balance/Status/Transactions are never bound from this form.
        ModelState.Remove(nameof(model.Transactions));

        if (!ModelState.IsValid)
        {
            await RehydrateAsync(model, ct);
            return View("Details", model);
        }

        var account = new Account
        {
            AccountId = id,
            AccountNumber = model.AccountNumber.Trim(),
            AccountType = model.AccountType
        };

        try
        {
            await _accountService.UpdateAsync(account, ct);
            TempData["SuccessMessage"] = "Account details were updated.";
        }
        catch (ConflictException ex)
        {
            ModelState.AddModelError(nameof(model.AccountNumber), ex.Message);
            await RehydrateAsync(model, ct);
            return View("Details", model);
        }

        return RedirectToAction(nameof(Details), new { id });
    }

    // POST /Accounts/Create - adds a new account for an existing user (reached from the User Details page).
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(AddAccountViewModel model, CancellationToken ct)
    {
        if (ModelState.IsValid)
        {
            try
            {
                var account = new Account { AccountNumber = model.AccountNumber.Trim(), AccountType = model.AccountType };
                await _accountService.CreateAsync(model.UserId, account, ct);
                TempData["SuccessMessage"] = $"Account '{model.AccountNumber}' was added.";
                return RedirectToAction("Details", "Users", new { id = model.UserId });
            }
            catch (ConflictException ex)
            {
                TempData["AddAccountError"] = ex.Message;
            }
            catch (NotFoundException ex)
            {
                TempData["AddAccountError"] = ex.Message;
            }
        }
        else
        {
            TempData["AddAccountError"] = "Please enter a valid account number.";
        }

        TempData["AddAccountNumber"] = model.AccountNumber;
        return RedirectToAction("Details", "Users", new { id = model.UserId });
    }

    // POST /Accounts/Close/5
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Close(int id, CancellationToken ct)
    {
        try
        {
            await _accountService.CloseAsync(id, ct);
            TempData["SuccessMessage"] = "Account was closed.";
        }
        catch (BusinessRuleException ex)
        {
            TempData["ErrorMessage"] = ex.Message;
        }

        return RedirectToAction(nameof(Details), new { id });
    }

    // POST /Accounts/Reopen/5
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Reopen(int id, CancellationToken ct)
    {
        await _accountService.ReopenAsync(id, ct);
        TempData["SuccessMessage"] = "Account was reopened.";
        return RedirectToAction(nameof(Details), new { id });
    }

    private static AccountDetailsViewModel ToDetailsViewModel(Account account, IEnumerable<Transaction> transactions) => new()
    {
        AccountId = account.AccountId,
        AccountNumber = account.AccountNumber,
        AccountType = account.AccountType,
        Balance = account.Balance,
        Status = account.Status,
        DateOpened = account.DateOpened,
        DateClosed = account.DateClosed,
        UserId = account.UserId,
        UserFullName = account.User?.FullName ?? string.Empty,
        Transactions = transactions.Select(t => new TransactionListItemViewModel
        {
            TransactionId = t.TransactionId,
            TransactionDate = t.TransactionDate,
            CaptureDate = t.CaptureDate,
            Type = t.Type,
            Amount = t.Amount,
            Description = t.Description
        }).ToList()
    };

    private async Task RehydrateAsync(AccountDetailsViewModel model, CancellationToken ct)
    {
        var existing = await _accountService.GetByIdAsync(model.AccountId, ct);
        if (existing is null)
        {
            return;
        }

        var transactions = await _transactionService.GetForAccountAsync(model.AccountId, ct);

        model.Balance = existing.Balance;
        model.Status = existing.Status;
        model.DateOpened = existing.DateOpened;
        model.DateClosed = existing.DateClosed;
        model.UserId = existing.UserId;
        model.UserFullName = existing.User?.FullName ?? string.Empty;
        model.Transactions = transactions.Select(t => new TransactionListItemViewModel
        {
            TransactionId = t.TransactionId,
            TransactionDate = t.TransactionDate,
            CaptureDate = t.CaptureDate,
            Type = t.Type,
            Amount = t.Amount,
            Description = t.Description
        }).ToList();
    }
}
