using System.Diagnostics;
using HorizonBet.Web.Models.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace HorizonBet.Web.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    // GET /
    public IActionResult Index() => View();

    // GET /Home/About
    public IActionResult About() => View();

    // GET /Home/Contact
    public IActionResult Contact() => View(new ContactViewModel());

    // POST /Home/Contact
    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Contact(ContactViewModel model)
    {
        if (!ModelState.IsValid)
        {
            model.Submitted = false;
            return View(model);
        }

        // No real mail server in this environment - a genuine deployment would hand this off to an
        // email/notification service here. The form still fully validates and gives the user feedback.
        _logger.LogInformation("Contact message received from {Name} <{Email}>: {Subject}", model.Name, model.Email, model.Subject);

        ModelState.Clear();
        return View(new ContactViewModel { Submitted = true });
    }

    [Route("/Home/Error/{statusCode:int?}")]
    public IActionResult Error(int? statusCode = null)
    {
        var message = HttpContext.Items["ErrorMessage"] as string;

        var vm = new ErrorViewModel
        {
            RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier,
            StatusCode = statusCode ?? 500,
            Message = message
        };

        Response.StatusCode = vm.StatusCode;
        return View(vm);
    }
}
