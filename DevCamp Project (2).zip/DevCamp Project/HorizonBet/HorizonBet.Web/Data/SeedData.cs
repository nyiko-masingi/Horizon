using HorizonBet.Web.Models.Domain;

namespace HorizonBet.Web.Data;

/// <summary>
/// Deterministic seed data applied via EF Core migrations (IEntityTypeConfiguration.HasData).
/// Values are fixed (no DateTime.Now/Guid.NewGuid) so the generated migration is stable and repeatable.
/// </summary>
public static class SeedData
{
    public static readonly User[] Users =
    {
        new User
        {
            UserId = 1,
            IdNumber = "8001015800083",
            FirstName = "Thabo",
            LastName = "Nkosi",
            Email = "thabo.nkosi@example.com",
            PhoneNumber = "0821234567",
            DateOfBirth = new DateTime(1980, 1, 1),
            DateCreated = new DateTime(2026, 1, 1)
        },
        new User
        {
            UserId = 2,
            IdNumber = "9203125800084",
            FirstName = "Aisha",
            LastName = "Patel",
            Email = "aisha.patel@example.com",
            PhoneNumber = "0837654321",
            DateOfBirth = new DateTime(1992, 3, 12),
            DateCreated = new DateTime(2026, 1, 2)
        }
    };

    public static readonly Account[] Accounts =
    {
        new Account
        {
            AccountId = 1,
            AccountNumber = "HB-100001",
            UserId = 1,
            AccountType = AccountType.Sports,
            Balance = 250.00m,
            Status = AccountStatus.Open,
            DateOpened = new DateTime(2026, 1, 5)
        },
        new Account
        {
            AccountId = 2,
            AccountNumber = "HB-100002",
            UserId = 1,
            AccountType = AccountType.Casino,
            Balance = 0m,
            Status = AccountStatus.Open,
            DateOpened = new DateTime(2026, 1, 6)
        },
        new Account
        {
            AccountId = 3,
            AccountNumber = "HB-100003",
            UserId = 2,
            AccountType = AccountType.General,
            Balance = 500.00m,
            Status = AccountStatus.Open,
            DateOpened = new DateTime(2026, 1, 7)
        }
    };

    public static readonly Transaction[] Transactions =
    {
        new Transaction
        {
            TransactionId = 1,
            AccountId = 1,
            TransactionDate = new DateTime(2026, 1, 10),
            CaptureDate = new DateTime(2026, 1, 10),
            Type = TransactionType.Credit,
            Amount = 300.00m,
            Description = "Initial deposit"
        },
        new Transaction
        {
            TransactionId = 2,
            AccountId = 1,
            TransactionDate = new DateTime(2026, 1, 15),
            CaptureDate = new DateTime(2026, 1, 15),
            Type = TransactionType.Debit,
            Amount = 50.00m,
            Description = "Sports bet - soccer match"
        },
        new Transaction
        {
            TransactionId = 3,
            AccountId = 3,
            TransactionDate = new DateTime(2026, 1, 8),
            CaptureDate = new DateTime(2026, 1, 8),
            Type = TransactionType.Credit,
            Amount = 500.00m,
            Description = "Initial deposit"
        }
    };
}
