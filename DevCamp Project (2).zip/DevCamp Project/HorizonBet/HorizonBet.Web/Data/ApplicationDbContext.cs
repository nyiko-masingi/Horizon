using HorizonBet.Web.Models.Domain;
using HorizonBet.Web.Models.ReadModels;
using Microsoft.EntityFrameworkCore;

namespace HorizonBet.Web.Data;

public class ApplicationDbContext : DbContext
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

    public DbSet<User> Users => Set<User>();
    public DbSet<Account> Accounts => Set<Account>();
    public DbSet<Transaction> Transactions => Set<Transaction>();

    /// <summary>Keyless read model mapped to the "vw_UserAccountSummary" SQL view (Database/Scripts/01_Views.sql).</summary>
    public DbSet<UserAccountSummary> UserAccountSummaries => Set<UserAccountSummary>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(ApplicationDbContext).Assembly);

        modelBuilder.Entity<UserAccountSummary>(builder =>
        {
            builder.HasNoKey();
            builder.ToView("vw_UserAccountSummary");
        });
    }
}
