using HorizonBet.Web.Models.Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HorizonBet.Web.Data.Configurations;

public class UserConfiguration : IEntityTypeConfiguration<User>
{
    public void Configure(EntityTypeBuilder<User> builder)
    {
        builder.ToTable("Users");

        builder.HasKey(u => u.UserId);

        builder.Property(u => u.IdNumber)
            .IsRequired()
            .HasMaxLength(13);

        // Business rule: a user can only be created once with the same ID number.
        builder.HasIndex(u => u.IdNumber)
            .IsUnique()
            .HasDatabaseName("IX_Users_IdNumber");

        builder.Property(u => u.FirstName).IsRequired().HasMaxLength(100);
        builder.Property(u => u.LastName).IsRequired().HasMaxLength(100);

        // Supports the "search by surname" requirement on the user list page.
        builder.HasIndex(u => u.LastName).HasDatabaseName("IX_Users_LastName");

        builder.Property(u => u.Email).IsRequired().HasMaxLength(256);
        builder.Property(u => u.PhoneNumber).HasMaxLength(20);
        builder.Property(u => u.DateOfBirth).HasColumnType("date");
        builder.Property(u => u.DateCreated).HasColumnType("datetime2");

        builder.HasMany(u => u.Accounts)
            .WithOne(a => a.User)
            .HasForeignKey(a => a.UserId)
            .OnDelete(DeleteBehavior.Restrict);

        builder.HasData(HorizonBet.Web.Data.SeedData.Users);
    }
}
