using HorizonBet.Web.Models.Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HorizonBet.Web.Data.Configurations;

public class AccountConfiguration : IEntityTypeConfiguration<Account>
{
    public void Configure(EntityTypeBuilder<Account> builder)
    {
        builder.ToTable("Accounts");

        builder.HasKey(a => a.AccountId);

        builder.Property(a => a.AccountNumber)
            .IsRequired()
            .HasMaxLength(20);

        // Business rule: account numbers cannot be duplicated.
        builder.HasIndex(a => a.AccountNumber)
            .IsUnique()
            .HasDatabaseName("IX_Accounts_AccountNumber");

        // Supports "list accounts for a user" lookups from the User Details page.
        builder.HasIndex(a => a.UserId).HasDatabaseName("IX_Accounts_UserId");

        // Supports the "does this user have any open accounts?" check used when deleting a user.
        builder.HasIndex(a => new { a.UserId, a.Status }).HasDatabaseName("IX_Accounts_UserId_Status");

        builder.Property(a => a.AccountType).HasConversion<string>().HasMaxLength(20);
        builder.Property(a => a.Status).HasConversion<string>().HasMaxLength(10);

        builder.Property(a => a.Balance).HasColumnType("decimal(18,2)");
        builder.Property(a => a.DateOpened).HasColumnType("datetime2");
        builder.Property(a => a.DateClosed).HasColumnType("datetime2");

        builder.Property(a => a.RowVersion).IsRowVersion();

        builder.HasMany(a => a.Transactions)
            .WithOne(t => t.Account)
            .HasForeignKey(t => t.AccountId)
            .OnDelete(DeleteBehavior.Restrict);

        builder.HasData(HorizonBet.Web.Data.SeedData.Accounts);
    }
}
