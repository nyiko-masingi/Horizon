using HorizonBet.Web.Models.Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HorizonBet.Web.Data.Configurations;

public class TransactionConfiguration : IEntityTypeConfiguration<Transaction>
{
    public void Configure(EntityTypeBuilder<Transaction> builder)
    {
        builder.ToTable("Transactions");

        builder.HasKey(t => t.TransactionId);

        builder.Property(t => t.Amount).HasColumnType("decimal(18,2)");
        builder.Property(t => t.Type).HasConversion<string>().HasMaxLength(10);
        builder.Property(t => t.TransactionDate).HasColumnType("date");
        builder.Property(t => t.CaptureDate).HasColumnType("datetime2");
        builder.Property(t => t.Description).HasMaxLength(250);

        // Supports the "list transactions for an account, ordered by date" query used on the Account Details page.
        builder.HasIndex(t => new { t.AccountId, t.TransactionDate })
            .HasDatabaseName("IX_Transactions_AccountId_TransactionDate");

        builder.HasData(HorizonBet.Web.Data.SeedData.Transactions);
    }
}
