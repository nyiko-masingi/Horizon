# Testing Documentation

## What's tested

`HorizonBet.Tests` is an xUnit project that exercises the **service layer** — the business rules from
the spec — using the EF Core **InMemory** provider. Each test spins up a brand-new, isolated in-memory
database (a fresh GUID-named database per test) so tests never interfere with one another and require
no real SQL Server instance to run.

| Test class | Covers |
|---|---|
| `UserServiceTests` | Create with unique/duplicate ID number, update with duplicate ID number, delete blocked by open accounts, delete allowed with no/closed accounts, get-by-id miss returns null |
| `AccountServiceTests` | Create against a missing user, create with duplicate account number, new accounts always start at zero balance/Open, update never changes the balance even if one is posted, close blocked by non-zero balance, close/reopen happy paths |
| `TransactionServiceTests` | Create blocked on a closed account, create blocked for a future date, create blocked for a zero amount, credit increases balance, debit decreases balance, capture date is always system-set regardless of input, edit reverses the old amount and applies the new one, edit blocked on a closed account |

### Why the view/stored-procedure paths aren't unit tested here

`UserService.SearchAsync` reads from the `vw_UserAccountSummary` SQL view and
`TransactionService.GetForAccountAsync` calls the `sp_GetAccountStatement` stored procedure (see
[Database/Scripts](Database/Scripts)). Both are deliberate design choices per the spec's requirement
that data returned to the presentation layer go through views/stored procedures. The EF Core InMemory
provider can't execute raw SQL and can't have rows inserted into a keyless (view-backed) entity type, so
these two methods are **manually verified against a real LocalDB instance** instead (see the checklist
below) rather than mocked into a false sense of coverage.

## Running the automated tests

```bash
dotnet test
```

Expect all tests to pass with no `#REF!`-style surprises — a failing test here means a business rule
regressed, not an environment issue (no database/network is required for this project).

## Manual test checklist (view/stored-procedure paths + full UI flows)

Run these against a `dotnet run` instance with the database set up per [README.md](README.md) Section 3.

| # | Scenario | Steps | Expected result |
|---|---|---|---|
| 1 | Search by surname | Users → type a seeded surname (e.g. `Nkosi`) → Search | Only matching user(s) shown, account count correct |
| 2 | Search by ID number | Users → search `8001015800083` | Thabo Nkosi shown |
| 3 | Search by account number | Users → search `HB-100003` | Aisha Patel shown (the account owner, not the account itself) |
| 4 | Pagination | Register 11+ users, revisit Users list | Page 1 shows 10, page 2 shows the rest, Previous/Next work |
| 5 | Duplicate ID number | Users → Create → reuse a seeded ID number | Form redisplays with a validation error, no duplicate row created |
| 6 | Add account before user exists | N/A — UI only exposes "Add Account" from an existing user's Details page | Confirms the rule structurally, not just at runtime |
| 7 | Duplicate account number | User Details → Add Account → reuse `HB-100001` | Error banner shown, no duplicate account created |
| 8 | Balance can't be edited | Account Details → try tampering with the balance via browser dev tools before submitting Edit | Balance in the database is unchanged after save |
| 9 | Capture a transaction | Account Details → Add Transaction → pick today's date, Credit, amount 25 | Balance increases by 25, transaction appears at the top of the list |
| 10 | Future-dated transaction rejected | Transactions/Create → try to pick tomorrow via the date picker | Browser blocks it (`max` attribute) and server-side validation also rejects it if bypassed |
| 11 | Zero-amount transaction rejected | Transactions/Create → amount `0` | Validation error, no transaction created |
| 12 | Edit a transaction | Edit an existing transaction's amount | Balance reflects the reversal + new amount, `Captured` timestamp updates |
| 13 | Close account with balance | Account Details → Close Account while balance ≠ 0 | Button disabled / error shown, account stays open |
| 14 | Close + reopen | Zero out a balance (offsetting transactions), Close, then Reopen | Status flips both ways, `DateClosed` set/cleared correctly |
| 15 | No transactions on closed account | Try to reach Transactions/Create for a closed account (direct URL) | Redirected back to Account Details with an error message |
| 16 | Delete user with open account | Users → Details → Delete | Delete button disabled with an explanatory note |
| 17 | Delete user with only closed accounts | Close all of a user's accounts → Delete | User removed, redirected to Users list |
| 18 | 404 handling | Visit `/Users/Details/999999` | Friendly 404 error page, not a stack trace |
| 19 | Contact form | Contact page → fill in and submit | Success confirmation panel shown |
| 20 | Navbar consistency | Click through Home/Users/About/Contact | Same navbar, same active-link highlighting, on every page |

## Known gaps

- No automated UI/E2E tests (e.g. Playwright/Selenium) are included — the manual checklist above covers
  that surface instead, given the project's scope and timeline.
- Load/performance testing against a large seeded dataset was not performed; indexing choices are
  documented in README.md Section 4 but not benchmarked.
