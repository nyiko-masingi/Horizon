# Testing Documentation — The Gilded Stake

## What is tested

Automated unit tests target the **service layer**, since that is where every
business rule from the specification is enforced. Tests run against the EF
Core **InMemory** provider so they execute quickly with no SQL Server
dependency, in a fresh, isolated database per test.

| Test class | Business rules covered |
|---|---|
| `UserServiceTests` | Duplicate ID number is rejected; a user with an open account cannot be deleted; a user with only closed accounts (or no accounts) can be deleted |
| `AccountServiceTests` | New accounts open at a zero balance; duplicate account numbers are rejected; accounts can only be created for an existing user; an account cannot be closed with a non-zero balance; closing/reopening flips `IsClosed` correctly |
| `TransactionServiceTests` | Credit increases balance, debit decreases balance; zero-amount transactions are rejected; future-dated transactions are rejected; transactions cannot be posted to a closed account; editing a transaction's amount correctly recalculates the account balance |
| `IdentitySeederTests` | Every role (Administrator/Manager/Teller/Auditor) is seeded; one active demo account is seeded per role with the correct role assignment; seeding is idempotent (safe to run on every app start without duplicating accounts); the documented demo password authenticates the seeded Administrator account |

## How to run

```bash
cd src/GildedStake.Tests
dotnet test
```

Expected result: all tests pass. No external services or SQL Server instance
are required for this suite.

## Manual / exploratory test plan

The following happy-path and edge-case scenarios were walked through manually
against a local SQL Server instance during development:

### Happy path

1. Open **Home** → confirm hero, feature cards and navigation flow diagram render.
2. Open **About** and **Contact** → confirm content renders and the navbar is
   identical across all pages.
3. Submit the **Contact** form with valid data → success toast appears and a
   row is persisted to `ContactMessages`.
4. Go to **Users** → **Register New Client** → submit a valid user →
   redirected to the new client's **Details** page.
5. From a client's **Details** page → **New Account** → submit a valid
   account → redirected to the **Account Details** page showing a zero
   balance.
6. From an account's **Details** page → **New Transaction** → post a Credit
   of R500 → balance updates to R500.00 and the transaction appears at the
   top of the ledger.
7. Post a Debit of R120 → balance updates to R380.00.
8. Edit the R120 debit to R200 → balance recalculates to R300.00.
9. Attempt to **Close** the account while the balance is R300.00 → rejected
   with a clear message; reduce the balance to zero (post a balancing
   transaction) → close succeeds → **Reopen** succeeds.
10. From the **Users** list, search `"Winthrop"`, then the seeded ID number,
    then a seeded account number → each returns the expected single match.
11. Delete a client who has no accounts → succeeds and disappears from the list.

### Role-based access control

| Scenario | Expected result |
|---|---|
| Sign in as each of the four seeded demo accounts | Each signs in successfully and lands on Home with a "Welcome back" toast |
| Sign in with an incorrect password | Rejected with a generic "Invalid email or password" message |
| Self-register a new account | Account is created with Teller access and the user is signed in immediately |
| Register with an email already in use | Rejected with a clear "already exists" message |
| Auditor visits Users/Accounts | Can view every screen; all form fields are disabled and Save/Delete/Close/New buttons are hidden |
| Teller attempts to delete a client or close an account (via direct URL) | Redirected to Access Denied, even though no button exposes the action in their UI |
| Teller posts a transaction, then tries to edit it | Posting succeeds; the edit link is not shown, and navigating to the edit URL directly is redirected to Access Denied |
| Manager closes an account, then reopens it | Both actions succeed |
| Administrator opens Manage Accounts | Sees every system account with its role and status |
| Administrator changes another account's role via the dropdown | Role updates immediately and is reflected next time that user signs in (or within 5 minutes if already signed in) |
| Administrator deactivates another account | That account can no longer sign in ("This account has been deactivated") |
| Administrator attempts to deactivate their own account | Blocked with a clear message; the control is also hidden in the UI |
| Administrator attempts to demote or deactivate the only remaining Administrator | Blocked with a clear message |
| Anonymous visitor opens Home, About or Contact | Loads normally, no sign-in required |
| Anonymous visitor opens Users | Redirected to Sign In, then returned to Users after a successful login |

### Edge cases / negative tests

| Scenario | Expected result |
|---|---|
| Create a user with an ID number that already exists | Friendly validation error, no duplicate row created |
| Create an account with a duplicate account number | Friendly validation error |
| Post a transaction dated tomorrow | Client-side `max` on the date field blocks it; server also rejects it if bypassed |
| Post a transaction with amount `0` | Rejected with "amount cannot be zero" |
| Try to close an account with a non-zero balance | Rejected with the exact outstanding balance shown |
| Try to post/edit a transaction on a closed account | Rejected; user is told to reopen the account first |
| Try to delete a user with an open account | Rejected with a clear explanation |
| Navigate to `/Users/Details/99999` (non-existent id) | Redirected to a themed 404 page |
| Submit the Contact form with an invalid email | Inline field-level validation message, form not submitted |

## Known gaps / future work

- Role changes and deactivations take effect on the account's next security
  stamp validation (up to 5 minutes for an already-open session) rather than
  instantaneously — see `Program.cs` (`SecurityStampValidatorOptions`).
- Pagination is applied to the Users list only, per the (optional) spec item;
  account and transaction lists are not paginated since the spec does not
  request it, though they are scrollable within their card.
- The reporting view (`vw_UserAccountSummary`) currently powers only the
  Users list; it could be extended with a dedicated "Reports" page in a
  future iteration.
