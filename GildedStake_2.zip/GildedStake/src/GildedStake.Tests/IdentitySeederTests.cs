using GildedStake.Web.Common;
using GildedStake.Web.Data;
using GildedStake.Web.Models.Identity;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Xunit;

namespace GildedStake.Tests;

public class IdentitySeederTests
{
    /// <summary>
    /// Builds a minimal, real ASP.NET Core Identity stack (UserManager +
    /// RoleManager backed by the EF Core InMemory provider) so
    /// <see cref="IdentitySeeder"/> can be exercised exactly as it runs in
    /// production, without needing a full web host.
    /// </summary>
    private static ServiceProvider BuildIdentityServices()
    {
        var services = new ServiceCollection();
        services.AddLogging();
        services.AddDbContext<ApplicationDbContext>(options =>
            options.UseInMemoryDatabase(Guid.NewGuid().ToString()));

        services
            .AddIdentityCore<ApplicationUser>(options =>
            {
                options.Password.RequiredLength = 8;
                options.Password.RequireNonAlphanumeric = false;
            })
            .AddRoles<IdentityRole>()
            .AddEntityFrameworkStores<ApplicationDbContext>()
            .AddDefaultTokenProviders();

        return services.BuildServiceProvider();
    }

    [Fact]
    public async Task SeedAsync_CreatesEveryRole()
    {
        await using var provider = BuildIdentityServices();
        await IdentitySeeder.SeedAsync(provider);

        var roleManager = provider.GetRequiredService<RoleManager<IdentityRole>>();
        foreach (var role in Roles.All)
        {
            Assert.True(await roleManager.RoleExistsAsync(role), $"Role '{role}' should have been seeded.");
        }
    }

    [Fact]
    public async Task SeedAsync_CreatesOneActiveAccountPerRole()
    {
        await using var provider = BuildIdentityServices();
        await IdentitySeeder.SeedAsync(provider);

        var userManager = provider.GetRequiredService<UserManager<ApplicationUser>>();

        var admin = await userManager.FindByEmailAsync("admin@gildedstake.example");
        Assert.NotNull(admin);
        Assert.True(admin!.IsActive);
        Assert.Contains(Roles.Administrator, await userManager.GetRolesAsync(admin));

        var manager = await userManager.FindByEmailAsync("manager@gildedstake.example");
        Assert.NotNull(manager);
        Assert.Contains(Roles.Manager, await userManager.GetRolesAsync(manager!));

        var teller = await userManager.FindByEmailAsync("teller@gildedstake.example");
        Assert.NotNull(teller);
        Assert.Contains(Roles.Teller, await userManager.GetRolesAsync(teller!));

        var auditor = await userManager.FindByEmailAsync("auditor@gildedstake.example");
        Assert.NotNull(auditor);
        Assert.Contains(Roles.Auditor, await userManager.GetRolesAsync(auditor!));
    }

    [Fact]
    public async Task SeedAsync_IsIdempotent_DoesNotDuplicateAccountsOnSecondRun()
    {
        await using var provider = BuildIdentityServices();
        await IdentitySeeder.SeedAsync(provider);
        await IdentitySeeder.SeedAsync(provider); // run again, as happens on every app restart

        var userManager = provider.GetRequiredService<UserManager<ApplicationUser>>();
        var matches = userManager.Users.Count(u => u.Email == "admin@gildedstake.example");
        Assert.Equal(1, matches);
    }

    [Fact]
    public async Task SeededAdminPassword_SignsInSuccessfully()
    {
        await using var provider = BuildIdentityServices();
        await IdentitySeeder.SeedAsync(provider);

        var userManager = provider.GetRequiredService<UserManager<ApplicationUser>>();
        var admin = await userManager.FindByEmailAsync("admin@gildedstake.example");

        Assert.NotNull(admin);
        var passwordValid = await userManager.CheckPasswordAsync(admin!, "Admin#12345");
        Assert.True(passwordValid, "The documented demo password should authenticate the seeded Administrator account.");
    }
}
