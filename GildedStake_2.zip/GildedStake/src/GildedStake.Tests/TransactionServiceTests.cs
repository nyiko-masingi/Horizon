using GildedStake.Web.Data;
using GildedStake.Web.Models;
using GildedStake.Web.Models.Enums;
using GildedStake.Web.Services;
using GildedStake.Web.Services.Exceptions;
using Xunit;

namespace GildedStake.Tests;

public class TransactionServiceTests
{
    private static async Task<(ApplicationDbContext ctx, Account account)> SeedAccountAsync()
    {
        var ctx = TestDbContextFactory.Create();
        var user = new User
        {
            FirstName = "Grace",
            Surname = "Hopper",
            IdNumber = "9001015800084",
            Email = "grace@example.com",
            PhoneNumber = "0821111111",
            DateOfBirth = new DateOnly(1990, 1, 1)
        };
        ctx.Users.Add(user);
        await ctx.SaveChangesAsync();

        var account = new Account { AccountNumber = "TX-ACC-1", AccountName = "Main", UserId = user.Id };
        ctx.Accounts.Add(account);
        await ctx.SaveChangesAsync();

        return (ctx, account);
    }

    [Fact]
    public async Task CreateAsync_CreditTransaction_IncreasesBalance()
    {
        var (ctx, account) = await SeedAccountAsync();
        var service = new TransactionService(ctx, TestDbContextFactory.Logger<TransactionService>());

        await service.CreateAsync(account.Id, new Transaction
        {
            TransactionDate = DateOnly.FromDateTime(DateTime.UtcNow),
            Type = TransactionType.Credit,
            Amount = 500m
        });

        var reloaded = await ctx.Accounts.FindAsync(account.Id);
        Assert.Equal(500m, reloaded!.Balance);
    }

    [Fact]
    public async Task CreateAsync_DebitTransaction_DecreasesBalance()
    {
        var (ctx, account) = await SeedAccountAsync();
        var service = new TransactionService(ctx, TestDbContextFactory.Logger<TransactionService>());

        await service.CreateAsync(account.Id, new Transaction { TransactionDate = DateOnly.FromDateTime(DateTime.UtcNow), Type = TransactionType.Credit, Amount = 1000m });
        await service.CreateAsync(account.Id, new Transaction { TransactionDate = DateOnly.FromDateTime(DateTime.UtcNow), Type = TransactionType.Debit, Amount = 300m });

        var reloaded = await ctx.Accounts.FindAsync(account.Id);
        Assert.Equal(700m, reloaded!.Balance);
    }

    [Fact]
    public async Task CreateAsync_ZeroAmount_ThrowsBusinessRuleException()
    {
        var (ctx, account) = await SeedAccountAsync();
        var service = new TransactionService(ctx, TestDbContextFactory.Logger<TransactionService>());

        await Assert.ThrowsAsync<BusinessRuleException>(() =>
            service.CreateAsync(account.Id, new Transaction { TransactionDate = DateOnly.FromDateTime(DateTime.UtcNow), Type = TransactionType.Credit, Amount = 0m }));
    }

    [Fact]
    public async Task CreateAsync_FutureDate_ThrowsBusinessRuleException()
    {
        var (ctx, account) = await SeedAccountAsync();
        var service = new TransactionService(ctx, TestDbContextFactory.Logger<TransactionService>());

        await Assert.ThrowsAsync<BusinessRuleException>(() =>
            service.CreateAsync(account.Id, new Transaction
            {
                TransactionDate = DateOnly.FromDateTime(DateTime.UtcNow.AddDays(1)),
                Type = TransactionType.Credit,
                Amount = 50m
            }));
    }

    [Fact]
    public async Task CreateAsync_OnClosedAccount_ThrowsBusinessRuleException()
    {
        var (ctx, account) = await SeedAccountAsync();
        var accountService = new AccountService(ctx, TestDbContextFactory.Logger<AccountService>());
        var transactionService = new TransactionService(ctx, TestDbContextFactory.Logger<TransactionService>());

        await accountService.CloseAsync(account.Id); // balance is already zero

        await Assert.ThrowsAsync<BusinessRuleException>(() =>
            transactionService.CreateAsync(account.Id, new Transaction
            {
                TransactionDate = DateOnly.FromDateTime(DateTime.UtcNow),
                Type = TransactionType.Credit,
                Amount = 50m
            }));
    }

    [Fact]
    public async Task UpdateAsync_ChangingAmount_RecalculatesBalanceCorrectly()
    {
        var (ctx, account) = await SeedAccountAsync();
        var service = new TransactionService(ctx, TestDbContextFactory.Logger<TransactionService>());

        var created = await service.CreateAsync(account.Id, new Transaction
        {
            TransactionDate = DateOnly.FromDateTime(DateTime.UtcNow),
            Type = TransactionType.Credit,
            Amount = 200m
        });

        // Simulate a real edit: a brand-new, detached Transaction instance carrying only
        // the updated fields, as the controller would build from a posted form — not a
        // mutation of the still-tracked object returned by CreateAsync.
        var edited = new Transaction
        {
            Id = created.Id,
            AccountId = created.AccountId,
            TransactionDate = created.TransactionDate,
            Type = created.Type,
            Amount = 350m,
            Description = created.Description
        };

        await service.UpdateAsync(edited);

        var reloaded = await ctx.Accounts.FindAsync(account.Id);
        Assert.Equal(350m, reloaded!.Balance);
    }
}
