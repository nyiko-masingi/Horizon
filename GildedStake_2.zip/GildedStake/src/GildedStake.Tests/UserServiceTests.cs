using GildedStake.Web.Models;
using GildedStake.Web.Services;
using GildedStake.Web.Services.Exceptions;
using Xunit;

namespace GildedStake.Tests;

public class UserServiceTests
{
    private static User BuildUser(string idNumber, string surname = "Turing") => new()
    {
        FirstName = "Alan",
        Surname = surname,
        IdNumber = idNumber,
        Email = $"{surname.ToLowerInvariant()}@example.com",
        PhoneNumber = "0829999999",
        DateOfBirth = new DateOnly(1985, 5, 5)
    };

    [Fact]
    public async Task CreateAsync_DuplicateIdNumber_ThrowsBusinessRuleException()
    {
        var ctx = TestDbContextFactory.Create();
        var service = new UserService(ctx, TestDbContextFactory.Logger<UserService>());

        await service.CreateAsync(BuildUser("7500015800080"));

        await Assert.ThrowsAsync<BusinessRuleException>(() =>
            service.CreateAsync(BuildUser("7500015800080", "Hopper")));
    }

    [Fact]
    public async Task DeleteAsync_UserWithOpenAccount_ThrowsBusinessRuleException()
    {
        var ctx = TestDbContextFactory.Create();
        var userService = new UserService(ctx, TestDbContextFactory.Logger<UserService>());
        var accountService = new AccountService(ctx, TestDbContextFactory.Logger<AccountService>());

        var user = await userService.CreateAsync(BuildUser("6600015800081"));
        await accountService.CreateAsync(user.Id, new Account { AccountNumber = "DEL-001", AccountName = "Main" });

        await Assert.ThrowsAsync<BusinessRuleException>(() => userService.DeleteAsync(user.Id));
    }

    [Fact]
    public async Task DeleteAsync_UserWithOnlyClosedAccounts_Succeeds()
    {
        var ctx = TestDbContextFactory.Create();
        var userService = new UserService(ctx, TestDbContextFactory.Logger<UserService>());
        var accountService = new AccountService(ctx, TestDbContextFactory.Logger<AccountService>());

        var user = await userService.CreateAsync(BuildUser("6600015800082", "Babbage"));
        var account = await accountService.CreateAsync(user.Id, new Account { AccountNumber = "DEL-002", AccountName = "Main" });
        await accountService.CloseAsync(account.Id); // balance is zero, so this succeeds

        await userService.DeleteAsync(user.Id);

        var reloaded = await userService.GetByIdAsync(user.Id);
        Assert.Null(reloaded);
    }

    [Fact]
    public async Task DeleteAsync_UserWithNoAccounts_Succeeds()
    {
        var ctx = TestDbContextFactory.Create();
        var userService = new UserService(ctx, TestDbContextFactory.Logger<UserService>());

        var user = await userService.CreateAsync(BuildUser("6600015800083", "Lovelace"));
        await userService.DeleteAsync(user.Id);

        var reloaded = await userService.GetByIdAsync(user.Id);
        Assert.Null(reloaded);
    }
}
