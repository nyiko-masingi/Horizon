using GildedStake.Web.Data;
using GildedStake.Web.Models;
using GildedStake.Web.Models.Enums;
using GildedStake.Web.Services;
using GildedStake.Web.Services.Exceptions;
using Xunit;

namespace GildedStake.Tests;

public class AccountServiceTests
{
    private static async Task<(ApplicationDbContext ctx, User user)> SeedUserAsync()
    {
        var ctx = TestDbContextFactory.Create();
        var user = new User
        {
            FirstName = "Ada",
            Surname = "Lovelace",
            IdNumber = "8001015800083",
            Email = "ada@example.com",
            PhoneNumber = "0820000000",
            DateOfBirth = new DateOnly(1980, 1, 1)
        };
        ctx.Users.Add(user);
        await ctx.SaveChangesAsync();
        return (ctx, user);
    }

    [Fact]
    public async Task CreateAsync_NewAccount_OpensWithZeroBalance()
    {
        var (ctx, user) = await SeedUserAsync();
        var service = new AccountService(ctx, TestDbContextFactory.Logger<AccountService>());

        var account = await service.CreateAsync(user.Id, new Account { AccountNumber = "ACC-001", AccountName = "Main" });

        Assert.Equal(0m, account.Balance);
        Assert.False(account.IsClosed);
    }

    [Fact]
    public async Task CreateAsync_DuplicateAccountNumber_ThrowsBusinessRuleException()
    {
        var (ctx, user) = await SeedUserAsync();
        var service = new AccountService(ctx, TestDbContextFactory.Logger<AccountService>());
        await service.CreateAsync(user.Id, new Account { AccountNumber = "ACC-DUP", AccountName = "First" });

        await Assert.ThrowsAsync<BusinessRuleException>(() =>
            service.CreateAsync(user.Id, new Account { AccountNumber = "ACC-DUP", AccountName = "Second" }));
    }

    [Fact]
    public async Task CreateAsync_UnknownUser_ThrowsNotFoundException()
    {
        var ctx = TestDbContextFactory.Create();
        var service = new AccountService(ctx, TestDbContextFactory.Logger<AccountService>());

        await Assert.ThrowsAsync<NotFoundException>(() =>
            service.CreateAsync(999, new Account { AccountNumber = "ACC-X", AccountName = "Ghost" }));
    }

    [Fact]
    public async Task CloseAsync_WithNonZeroBalance_ThrowsBusinessRuleException()
    {
        var (ctx, user) = await SeedUserAsync();
        var accountService = new AccountService(ctx, TestDbContextFactory.Logger<AccountService>());
        var transactionService = new TransactionService(ctx, TestDbContextFactory.Logger<TransactionService>());

        var account = await accountService.CreateAsync(user.Id, new Account { AccountNumber = "ACC-002", AccountName = "Main" });
        await transactionService.CreateAsync(account.Id, new Transaction
        {
            TransactionDate = DateOnly.FromDateTime(DateTime.UtcNow),
            Type = TransactionType.Credit,
            Amount = 100m
        });

        await Assert.ThrowsAsync<BusinessRuleException>(() => accountService.CloseAsync(account.Id));
    }

    [Fact]
    public async Task CloseAsync_WithZeroBalance_Succeeds()
    {
        var (ctx, user) = await SeedUserAsync();
        var accountService = new AccountService(ctx, TestDbContextFactory.Logger<AccountService>());
        var account = await accountService.CreateAsync(user.Id, new Account { AccountNumber = "ACC-003", AccountName = "Main" });

        await accountService.CloseAsync(account.Id);

        var reloaded = await accountService.GetByIdAsync(account.Id);
        Assert.True(reloaded!.IsClosed);
    }

    [Fact]
    public async Task ReopenAsync_ClosedAccount_ReopensSuccessfully()
    {
        var (ctx, user) = await SeedUserAsync();
        var accountService = new AccountService(ctx, TestDbContextFactory.Logger<AccountService>());
        var account = await accountService.CreateAsync(user.Id, new Account { AccountNumber = "ACC-004", AccountName = "Main" });
        await accountService.CloseAsync(account.Id);

        await accountService.ReopenAsync(account.Id);

        var reloaded = await accountService.GetByIdAsync(account.Id);
        Assert.False(reloaded!.IsClosed);
    }
}
