using GildedStake.Web.Services.Exceptions;
using Microsoft.EntityFrameworkCore;

namespace GildedStake.Web.Middleware;

/// <summary>
/// Centralized exception handler. Business-rule and not-found failures are
/// translated into a friendly redirect with a TempData-style flash message;
/// anything unexpected is logged (without leaking internals) and shown the
/// generic error page.
/// </summary>
public class ExceptionHandlingMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<ExceptionHandlingMiddleware> _logger;

    public ExceptionHandlingMiddleware(RequestDelegate next, ILogger<ExceptionHandlingMiddleware> logger)
    {
        _next = next;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        try
        {
            await _next(context);
        }
        catch (BusinessRuleException ex)
        {
            _logger.LogWarning(ex, "Business rule violation on {Path}", context.Request.Path);
            await RedirectWithMessageAsync(context, ex.Message, "danger");
        }
        catch (NotFoundException ex)
        {
            _logger.LogWarning(ex, "Not found on {Path}", context.Request.Path);
            context.Response.Redirect("/Home/HttpStatus?code=404");
        }
        catch (DbUpdateConcurrencyException ex)
        {
            _logger.LogWarning(ex, "Concurrency conflict on {Path}", context.Request.Path);
            await RedirectWithMessageAsync(
                context,
                "This record was changed by someone else while you were editing it. Please reload and try again.",
                "warning");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unhandled exception on {Path}", context.Request.Path);
            if (!context.Response.HasStarted)
            {
                context.Response.Redirect("/Home/Error");
            }
        }
    }

    private static async Task RedirectWithMessageAsync(HttpContext context, string message, string severity)
    {
        if (context.Response.HasStarted)
        {
            return;
        }

        var referer = context.Request.Headers.Referer.ToString();
        var target = string.IsNullOrWhiteSpace(referer) ? "/" : referer;

        // A lightweight flash cookie so the redirected request can render the message
        // without needing session state.
        context.Response.Cookies.Append("gs_flash_message", message, new CookieOptions { HttpOnly = false, Path = "/", MaxAge = TimeSpan.FromSeconds(15) });
        context.Response.Cookies.Append("gs_flash_severity", severity, new CookieOptions { HttpOnly = false, Path = "/", MaxAge = TimeSpan.FromSeconds(15) });

        context.Response.Redirect(target);
        await Task.CompletedTask;
    }
}
