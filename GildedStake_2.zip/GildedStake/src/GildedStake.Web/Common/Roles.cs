namespace GildedStake.Web.Common;

/// <summary>
/// The fixed set of roles recognised by The Gilded Stake. Centralising the
/// names here avoids magic strings scattered across controllers and views,
/// and gives one place to see the full role list.
/// </summary>
public static class Roles
{
    /// <summary>Full control: everything below, plus managing system (login) accounts and role assignment.</summary>
    public const string Administrator = "Administrator";

    /// <summary>Full control over clients, accounts and transactions, including closing accounts and editing posted transactions.</summary>
    public const string Manager = "Manager";

    /// <summary>Day-to-day operations: register clients, open accounts, post transactions. Cannot delete clients, close accounts, or edit posted transactions.</summary>
    public const string Teller = "Teller";

    /// <summary>Read-only access to every screen, for oversight and reconciliation. Cannot create, edit, delete, close or post anything.</summary>
    public const string Auditor = "Auditor";

    /// <summary>All roles, in the order they should generally appear in UI pickers.</summary>
    public static readonly string[] All = { Administrator, Manager, Teller, Auditor };

    /// <summary>Roles permitted to create/edit clients and accounts, and to post (create) transactions.</summary>
    public const string OperationalRoles = Administrator + "," + Manager + "," + Teller;

    /// <summary>Roles permitted to perform sensitive/oversight actions: delete a client, close/reopen an account, edit a posted transaction.</summary>
    public const string SupervisoryRoles = Administrator + "," + Manager;
}
