(function () {
    "use strict";

    function readCookie(name) {
        const match = document.cookie.match(new RegExp('(?:^|; )' + name + '=([^;]*)'));
        return match ? decodeURIComponent(match[1]) : null;
    }

    function eraseCookie(name) {
        document.cookie = name + '=; Path=/; Max-Age=0';
    }

    function showFlashFromCookie() {
        const message = readCookie('gs_flash_message');
        const severity = readCookie('gs_flash_severity') || 'success';
        if (!message) return;

        const container = document.getElementById('gsFlashContainer');
        if (!container) return;

        const icon = severity === 'danger' ? 'bi-exclamation-octagon'
            : severity === 'warning' ? 'bi-exclamation-triangle'
            : 'bi-check-circle';

        const toast = document.createElement('div');
        toast.className = 'gs-toast gs-toast-' + severity;
        toast.setAttribute('role', 'status');
        toast.innerHTML = '<i class="bi ' + icon + '"></i><span></span><button type="button" class="gs-toast-close" aria-label="Dismiss">&times;</button>';
        toast.querySelector('span').textContent = message;
        container.appendChild(toast);

        eraseCookie('gs_flash_message');
        eraseCookie('gs_flash_severity');

        wireDismiss(toast);
        autoDismiss(toast);
    }

    function wireDismiss(toast) {
        const closeBtn = toast.querySelector('.gs-toast-close');
        if (closeBtn) {
            closeBtn.addEventListener('click', function () {
                toast.remove();
            });
        }
    }

    function autoDismiss(toast) {
        setTimeout(function () {
            if (toast && toast.parentNode) {
                toast.style.transition = 'opacity 0.3s ease';
                toast.style.opacity = '0';
                setTimeout(function () { toast.remove(); }, 300);
            }
        }, 6000);
    }

    function wireExistingToasts() {
        document.querySelectorAll('.gs-toast').forEach(function (toast) {
            wireDismiss(toast);
            autoDismiss(toast);
        });
    }

    function initDatePickers() {
        // Native browser date inputs (type="date") already provide a full date-picker
        // UI. Here we clamp any such field to today, both as a UX nicety and a
        // client-side backstop for the server-side "no future dates" rule.
        const today = new Date().toISOString().split('T')[0];
        document.querySelectorAll('.gs-datepicker[type="date"]').forEach(function (el) {
            if (el.dataset.allowFuture !== 'true') {
                el.setAttribute('max', today);
            }
        });
    }

    document.addEventListener('DOMContentLoaded', function () {
        showFlashFromCookie();
        wireExistingToasts();
        initDatePickers();
    });
})();
