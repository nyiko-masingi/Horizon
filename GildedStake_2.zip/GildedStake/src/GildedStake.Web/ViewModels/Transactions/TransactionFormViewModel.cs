using System.ComponentModel.DataAnnotations;
using GildedStake.Web.Models;
using GildedStake.Web.Models.Enums;

namespace GildedStake.Web.ViewModels.Transactions;

public class TransactionFormViewModel
{
    public int Id { get; set; }

    public int AccountId { get; set; }

    public string? AccountNumber { get; set; }

    [Required(ErrorMessage = "Please select a transaction date.")]
    [DataType(DataType.Date)]
    [Display(Name = "Transaction date")]
    public DateOnly TransactionDate { get; set; } = DateOnly.FromDateTime(DateTime.Today);

    [Required(ErrorMessage = "Please choose Debit or Credit.")]
    public TransactionType Type { get; set; } = TransactionType.Credit;

    [Required(ErrorMessage = "Amount is required.")]
    [Range(0.01, 100000000, ErrorMessage = "Amount must be greater than zero.")]
    public decimal Amount { get; set; }

    [StringLength(240)]
    public string? Description { get; set; }

    public DateTime? CaptureDateUtc { get; set; }

    public byte[]? RowVersion { get; set; }

    public static TransactionFormViewModel FromEntity(Transaction transaction) => new()
    {
        Id = transaction.Id,
        AccountId = transaction.AccountId,
        AccountNumber = transaction.Account?.AccountNumber,
        TransactionDate = transaction.TransactionDate,
        Type = transaction.Type,
        Amount = transaction.Amount,
        Description = transaction.Description,
        CaptureDateUtc = transaction.CaptureDateUtc,
        RowVersion = transaction.RowVersion
    };

    public Transaction ToEntity() => new()
    {
        Id = Id,
        AccountId = AccountId,
        TransactionDate = TransactionDate,
        Type = Type,
        Amount = Amount,
        Description = Description?.Trim(),
        RowVersion = RowVersion
    };
}
