using GildedStake.Web.Models;

namespace GildedStake.Web.ViewModels.Users;

public class UserDetailsViewModel
{
    public UserFormViewModel Form { get; set; } = new();
    public List<Account> Accounts { get; set; } = new();
}
