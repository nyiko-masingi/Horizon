using GildedStake.Web.Models;
using GildedStake.Web.ViewModels.Shared;

namespace GildedStake.Web.ViewModels.Users;

public class UsersIndexViewModel
{
    public string? SearchTerm { get; set; }
    public PaginatedList<UserAccountSummary> Users { get; set; } = null!;
}
