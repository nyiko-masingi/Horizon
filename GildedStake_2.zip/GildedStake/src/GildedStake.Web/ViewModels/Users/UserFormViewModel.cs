using System.ComponentModel.DataAnnotations;
using GildedStake.Web.Models;

namespace GildedStake.Web.ViewModels.Users;

public class UserFormViewModel
{
    public int Id { get; set; }

    [Required(ErrorMessage = "First name is required.")]
    [StringLength(60)]
    [Display(Name = "First name")]
    public string FirstName { get; set; } = string.Empty;

    [Required(ErrorMessage = "Surname is required.")]
    [StringLength(60)]
    public string Surname { get; set; } = string.Empty;

    [Required(ErrorMessage = "ID number is required.")]
    [StringLength(20, MinimumLength = 5, ErrorMessage = "ID number must be between 5 and 20 characters.")]
    [Display(Name = "ID number")]
    public string IdNumber { get; set; } = string.Empty;

    [Required(ErrorMessage = "Email address is required.")]
    [EmailAddress(ErrorMessage = "Enter a valid email address.")]
    [StringLength(120)]
    public string Email { get; set; } = string.Empty;

    [Required(ErrorMessage = "Phone number is required.")]
    [Phone(ErrorMessage = "Enter a valid phone number.")]
    [StringLength(20)]
    [Display(Name = "Phone number")]
    public string PhoneNumber { get; set; } = string.Empty;

    [Required(ErrorMessage = "Date of birth is required.")]
    [DataType(DataType.Date)]
    [Display(Name = "Date of birth")]
    public DateOnly DateOfBirth { get; set; } = DateOnly.FromDateTime(DateTime.Today.AddYears(-18));

    public byte[]? RowVersion { get; set; }

    public static UserFormViewModel FromEntity(User user) => new()
    {
        Id = user.Id,
        FirstName = user.FirstName,
        Surname = user.Surname,
        IdNumber = user.IdNumber,
        Email = user.Email,
        PhoneNumber = user.PhoneNumber,
        DateOfBirth = user.DateOfBirth,
        RowVersion = user.RowVersion
    };

    public User ToEntity() => new()
    {
        Id = Id,
        FirstName = FirstName.Trim(),
        Surname = Surname.Trim(),
        IdNumber = IdNumber.Trim(),
        Email = Email.Trim(),
        PhoneNumber = PhoneNumber.Trim(),
        DateOfBirth = DateOfBirth,
        RowVersion = RowVersion
    };
}
