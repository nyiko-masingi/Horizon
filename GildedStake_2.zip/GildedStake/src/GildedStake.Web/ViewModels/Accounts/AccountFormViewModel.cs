using System.ComponentModel.DataAnnotations;
using GildedStake.Web.Models;

namespace GildedStake.Web.ViewModels.Accounts;

public class AccountFormViewModel
{
    public int Id { get; set; }

    public int UserId { get; set; }

    public string? UserFullName { get; set; }

    [Required(ErrorMessage = "Account number is required.")]
    [StringLength(30, MinimumLength = 3)]
    [Display(Name = "Account number")]
    public string AccountNumber { get; set; } = string.Empty;

    [Required(ErrorMessage = "Account name is required.")]
    [StringLength(60)]
    [Display(Name = "Account name")]
    public string AccountName { get; set; } = string.Empty;

    public decimal Balance { get; set; }

    public bool IsClosed { get; set; }

    public DateTime OpenedAtUtc { get; set; }

    public DateTime? ClosedAtUtc { get; set; }

    public byte[]? RowVersion { get; set; }

    public static AccountFormViewModel FromEntity(Account account) => new()
    {
        Id = account.Id,
        UserId = account.UserId,
        UserFullName = account.User?.FullName,
        AccountNumber = account.AccountNumber,
        AccountName = account.AccountName,
        Balance = account.Balance,
        IsClosed = account.IsClosed,
        OpenedAtUtc = account.OpenedAtUtc,
        ClosedAtUtc = account.ClosedAtUtc,
        RowVersion = account.RowVersion
    };

    public Account ToEntity() => new()
    {
        Id = Id,
        UserId = UserId,
        AccountNumber = AccountNumber.Trim(),
        AccountName = AccountName.Trim(),
        RowVersion = RowVersion
    };
}
