using GildedStake.Web.Models;

namespace GildedStake.Web.ViewModels.Accounts;

public class AccountDetailsViewModel
{
    public AccountFormViewModel Form { get; set; } = new();
    public List<Transaction> Transactions { get; set; } = new();
}
