using System.ComponentModel.DataAnnotations;

namespace GildedStake.Web.ViewModels.Contact;

public class ContactFormViewModel
{
    [Required(ErrorMessage = "Please tell us your name.")]
    [StringLength(100)]
    public string Name { get; set; } = string.Empty;

    [Required(ErrorMessage = "Please provide an email address so we can reply.")]
    [EmailAddress(ErrorMessage = "Enter a valid email address.")]
    [StringLength(120)]
    public string Email { get; set; } = string.Empty;

    [Required(ErrorMessage = "Please add a subject.")]
    [StringLength(120)]
    public string Subject { get; set; } = string.Empty;

    [Required(ErrorMessage = "Please write your message.")]
    [StringLength(2000, MinimumLength = 10, ErrorMessage = "Your message should be at least 10 characters.")]
    public string Message { get; set; } = string.Empty;
}
