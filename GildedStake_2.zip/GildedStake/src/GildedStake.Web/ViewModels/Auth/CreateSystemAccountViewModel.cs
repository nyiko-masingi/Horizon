using System.ComponentModel.DataAnnotations;
using GildedStake.Web.Common;

namespace GildedStake.Web.ViewModels.Auth;

public class CreateSystemAccountViewModel
{
    [Required(ErrorMessage = "First name is required.")]
    [StringLength(60)]
    [Display(Name = "First name")]
    public string FirstName { get; set; } = string.Empty;

    [Required(ErrorMessage = "Surname is required.")]
    [StringLength(60)]
    public string Surname { get; set; } = string.Empty;

    [Required(ErrorMessage = "Email address is required.")]
    [EmailAddress(ErrorMessage = "Enter a valid email address.")]
    [StringLength(120)]
    public string Email { get; set; } = string.Empty;

    [Required(ErrorMessage = "Password is required.")]
    [StringLength(100, MinimumLength = 8, ErrorMessage = "Password must be at least 8 characters.")]
    [DataType(DataType.Password)]
    public string Password { get; set; } = string.Empty;

    [Required(ErrorMessage = "Please choose a role.")]
    public string Role { get; set; } = Roles.Teller;

    public string[] AvailableRoles => Roles.All;
}
