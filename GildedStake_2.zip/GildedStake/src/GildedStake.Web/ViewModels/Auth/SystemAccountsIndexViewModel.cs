namespace GildedStake.Web.ViewModels.Auth;

public class SystemAccountListItemViewModel
{
    public string Id { get; set; } = string.Empty;
    public string FullName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string Role { get; set; } = string.Empty;
    public bool IsActive { get; set; }
    public DateTime CreatedAtUtc { get; set; }
    public bool IsCurrentUser { get; set; }
}

public class SystemAccountsIndexViewModel
{
    public List<SystemAccountListItemViewModel> Accounts { get; set; } = new();
}
