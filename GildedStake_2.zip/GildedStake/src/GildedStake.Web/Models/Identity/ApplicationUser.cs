using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Identity;

namespace GildedStake.Web.Models.Identity;

/// <summary>
/// A system (login) account — the person operating The Gilded Stake, as distinct
/// from a <see cref="GildedStake.Web.Models.User"/>, who is a wagering client.
/// Extends ASP.NET Core Identity's user with the display and status fields the
/// house needs.
/// </summary>
public class ApplicationUser : IdentityUser
{
    [Required, StringLength(60)]
    public string FirstName { get; set; } = string.Empty;

    [Required, StringLength(60)]
    public string Surname { get; set; } = string.Empty;

    /// <summary>
    /// When false, sign-in is refused even with a correct password. Lets an
    /// Administrator suspend an operator's access without deleting their
    /// history of who-did-what.
    /// </summary>
    public bool IsActive { get; set; } = true;

    public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;

    public string FullName => $"{FirstName} {Surname}";
}
