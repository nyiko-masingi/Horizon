using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using GildedStake.Web.Models.Enums;

namespace GildedStake.Web.Models;

/// <summary>
/// A single posted movement (stake, winning, deposit or withdrawal) against an account.
/// </summary>
public class Transaction
{
    public int Id { get; set; }

    public int AccountId { get; set; }
    public Account? Account { get; set; }

    /// <summary>The business-effective date of the transaction. Never in the future.</summary>
    [Required]
    public DateOnly TransactionDate { get; set; }

    /// <summary>System-controlled audit timestamp. Set on create, refreshed on every edit.</summary>
    public DateTime CaptureDateUtc { get; set; } = DateTime.UtcNow;

    [Required]
    public TransactionType Type { get; set; }

    /// <summary>Always stored as a positive value; direction is carried by <see cref="Type"/>.</summary>
    [Column(TypeName = "decimal(18,2)")]
    public decimal Amount { get; set; }

    [StringLength(240)]
    public string? Description { get; set; }

    [Timestamp]
    public byte[]? RowVersion { get; set; }
}
