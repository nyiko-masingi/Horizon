namespace GildedStake.Web.Models;

/// <summary>
/// Keyless read model mapped to the database view <c>vw_UserAccountSummary</c>.
/// Used by the presentation layer to render the Users list without loading
/// full aggregate graphs, and demonstrates the "read via SQL view" requirement.
/// </summary>
public class UserAccountSummary
{
    public int UserId { get; set; }
    public string FirstName { get; set; } = string.Empty;
    public string Surname { get; set; } = string.Empty;
    public string IdNumber { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string PhoneNumber { get; set; } = string.Empty;
    public int AccountCount { get; set; }
    public int OpenAccountCount { get; set; }
    public decimal TotalBalance { get; set; }
    public string? FirstAccountNumber { get; set; }
}
