namespace GildedStake.Web.Models.Enums;

/// <summary>
/// Direction of a monetary movement on a betting account.
/// Credit increases the outstanding balance (deposits, winnings).
/// Debit decreases the outstanding balance (withdrawals, stakes placed).
/// </summary>
public enum TransactionType
{
    Credit = 0,
    Debit = 1
}
