using System.ComponentModel.DataAnnotations;

namespace GildedStake.Web.Models;

/// <summary>A message submitted through the public Contact page.</summary>
public class ContactMessage
{
    public int Id { get; set; }

    [Required, StringLength(100)]
    public string Name { get; set; } = string.Empty;

    [Required, StringLength(120), EmailAddress]
    public string Email { get; set; } = string.Empty;

    [Required, StringLength(120)]
    public string Subject { get; set; } = string.Empty;

    [Required, StringLength(2000)]
    public string Message { get; set; } = string.Empty;

    public DateTime SentAtUtc { get; set; } = DateTime.UtcNow;
}
