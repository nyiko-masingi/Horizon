using System.ComponentModel.DataAnnotations;

namespace GildedStake.Web.Models;

/// <summary>
/// A client of the house. A user may hold an unlimited number of betting accounts.
/// </summary>
public class User
{
    public int Id { get; set; }

    [Required, StringLength(60)]
    public string FirstName { get; set; } = string.Empty;

    [Required, StringLength(60)]
    public string Surname { get; set; } = string.Empty;

    /// <summary>National identity number. Must be unique across all users.</summary>
    [Required, StringLength(20)]
    public string IdNumber { get; set; } = string.Empty;

    [Required, StringLength(120), EmailAddress]
    public string Email { get; set; } = string.Empty;

    [Required, StringLength(20)]
    public string PhoneNumber { get; set; } = string.Empty;

    [Required]
    public DateOnly DateOfBirth { get; set; }

    public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;

    [Timestamp]
    public byte[]? RowVersion { get; set; }

    public ICollection<Account> Accounts { get; set; } = new List<Account>();

    public string FullName => $"{FirstName} {Surname}";
}
