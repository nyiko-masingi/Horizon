using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GildedStake.Web.Models;

/// <summary>
/// A betting account belonging to a single user. The outstanding balance is
/// derived exclusively from posted transactions and is never directly editable.
/// </summary>
public class Account
{
    public int Id { get; set; }

    [Required, StringLength(30)]
    public string AccountNumber { get; set; } = string.Empty;

    [Required, StringLength(60)]
    public string AccountName { get; set; } = string.Empty;

    public int UserId { get; set; }
    public User? User { get; set; }

    [Column(TypeName = "decimal(18,2)")]
    public decimal Balance { get; set; }

    public bool IsClosed { get; set; }

    public DateTime OpenedAtUtc { get; set; } = DateTime.UtcNow;

    public DateTime? ClosedAtUtc { get; set; }

    [Timestamp]
    public byte[]? RowVersion { get; set; }

    public ICollection<Transaction> Transactions { get; set; } = new List<Transaction>();
}
