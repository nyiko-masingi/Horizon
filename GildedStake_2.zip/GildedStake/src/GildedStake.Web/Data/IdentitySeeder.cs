using GildedStake.Web.Common;
using GildedStake.Web.Models.Identity;
using Microsoft.AspNetCore.Identity;

namespace GildedStake.Web.Data;

/// <summary>
/// Ensures every role in <see cref="Roles"/> exists, and seeds one
/// demonstration system account per role so the application is immediately
/// usable and every permission tier can be exercised without manual setup.
///
/// SECURITY NOTE: the seeded passwords below are intentionally simple,
/// clearly-labelled demonstration credentials. Change or remove them before
/// any real deployment — see README.md.
/// </summary>
public static class IdentitySeeder
{
    public static async Task SeedAsync(IServiceProvider services)
    {
        var roleManager = services.GetRequiredService<RoleManager<IdentityRole>>();
        var userManager = services.GetRequiredService<UserManager<ApplicationUser>>();
        var logger = services.GetRequiredService<ILoggerFactory>().CreateLogger("IdentitySeeder");

        foreach (var role in Roles.All)
        {
            if (!await roleManager.RoleExistsAsync(role))
            {
                await roleManager.CreateAsync(new IdentityRole(role));
                logger.LogInformation("Created role {Role}", role);
            }
        }

        await EnsureDemoAccountAsync(userManager, logger,
            email: "admin@gildedstake.example", firstName: "Aurelia", surname: "Croft",
            role: Roles.Administrator, password: "Admin#12345");

        await EnsureDemoAccountAsync(userManager, logger,
            email: "manager@gildedstake.example", firstName: "Marcus", surname: "Delacroix",
            role: Roles.Manager, password: "Manager#12345");

        await EnsureDemoAccountAsync(userManager, logger,
            email: "teller@gildedstake.example", firstName: "Priya", surname: "Naidoo",
            role: Roles.Teller, password: "Teller#12345");

        await EnsureDemoAccountAsync(userManager, logger,
            email: "auditor@gildedstake.example", firstName: "Elias", surname: "Whitfield",
            role: Roles.Auditor, password: "Auditor#12345");
    }

    private static async Task EnsureDemoAccountAsync(
        UserManager<ApplicationUser> userManager,
        ILogger logger,
        string email,
        string firstName,
        string surname,
        string role,
        string password)
    {
        var existing = await userManager.FindByEmailAsync(email);
        if (existing is not null)
        {
            return;
        }

        var user = new ApplicationUser
        {
            UserName = email,
            Email = email,
            EmailConfirmed = true,
            FirstName = firstName,
            Surname = surname,
            IsActive = true,
        };

        var result = await userManager.CreateAsync(user, password);
        if (!result.Succeeded)
        {
            logger.LogError("Failed to seed demo account {Email}: {Errors}", email,
                string.Join("; ", result.Errors.Select(e => e.Description)));
            return;
        }

        await userManager.AddToRoleAsync(user, role);
        logger.LogInformation("Seeded demo account {Email} in role {Role}", email, role);
    }
}
