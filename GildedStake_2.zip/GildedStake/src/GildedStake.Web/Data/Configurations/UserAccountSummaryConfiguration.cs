using GildedStake.Web.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace GildedStake.Web.Data.Configurations;

/// <summary>
/// Maps the keyless read model onto the vw_UserAccountSummary database view
/// (created via raw SQL in <see cref="DbInitializer"/>). EF Core never generates
/// DDL for this view; it only ever reads from it.
/// </summary>
public class UserAccountSummaryConfiguration : IEntityTypeConfiguration<UserAccountSummary>
{
    public void Configure(EntityTypeBuilder<UserAccountSummary> builder)
    {
        builder.HasNoKey();
        builder.ToView("vw_UserAccountSummary");
    }
}
