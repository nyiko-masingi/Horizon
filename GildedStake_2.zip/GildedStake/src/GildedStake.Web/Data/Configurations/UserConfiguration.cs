using GildedStake.Web.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace GildedStake.Web.Data.Configurations;

public class UserConfiguration : IEntityTypeConfiguration<User>
{
    public void Configure(EntityTypeBuilder<User> builder)
    {
        builder.ToTable("Users");

        builder.HasKey(u => u.Id);

        builder.Property(u => u.FirstName).IsRequired().HasMaxLength(60);
        builder.Property(u => u.Surname).IsRequired().HasMaxLength(60);
        builder.Property(u => u.IdNumber).IsRequired().HasMaxLength(20);
        builder.Property(u => u.Email).IsRequired().HasMaxLength(120);
        builder.Property(u => u.PhoneNumber).IsRequired().HasMaxLength(20);

        // Business rule: a user can only be created once with the same ID Number.
        builder.HasIndex(u => u.IdNumber).IsUnique().HasDatabaseName("IX_Users_IdNumber");

        // Supports fast lookup/search by surname.
        builder.HasIndex(u => u.Surname).HasDatabaseName("IX_Users_Surname");

        builder.HasMany(u => u.Accounts)
               .WithOne(a => a.User)
               .HasForeignKey(a => a.UserId)
               .OnDelete(DeleteBehavior.Restrict);
    }
}
