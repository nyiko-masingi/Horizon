using GildedStake.Web.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace GildedStake.Web.Data.Configurations;

public class AccountConfiguration : IEntityTypeConfiguration<Account>
{
    public void Configure(EntityTypeBuilder<Account> builder)
    {
        builder.ToTable("Accounts");

        builder.HasKey(a => a.Id);

        builder.Property(a => a.AccountNumber).IsRequired().HasMaxLength(30);
        builder.Property(a => a.AccountName).IsRequired().HasMaxLength(60);
        builder.Property(a => a.Balance).HasColumnType("decimal(18,2)").HasDefaultValue(0m);

        // Business rule: you cannot have duplicated account numbers.
        builder.HasIndex(a => a.AccountNumber).IsUnique().HasDatabaseName("IX_Accounts_AccountNumber");

        // Supports fast lookup/search and per-user listing.
        builder.HasIndex(a => a.UserId).HasDatabaseName("IX_Accounts_UserId");

        builder.HasMany(a => a.Transactions)
               .WithOne(t => t.Account)
               .HasForeignKey(t => t.AccountId)
               .OnDelete(DeleteBehavior.Cascade);
    }
}
