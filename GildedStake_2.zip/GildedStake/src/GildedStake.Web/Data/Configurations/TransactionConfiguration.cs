using GildedStake.Web.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace GildedStake.Web.Data.Configurations;

public class TransactionConfiguration : IEntityTypeConfiguration<Transaction>
{
    public void Configure(EntityTypeBuilder<Transaction> builder)
    {
        builder.ToTable("Transactions");

        builder.HasKey(t => t.Id);

        builder.Property(t => t.Amount).HasColumnType("decimal(18,2)");
        builder.Property(t => t.Type).HasConversion<string>().HasMaxLength(10);
        builder.Property(t => t.Description).HasMaxLength(240);

        // Supports fast retrieval of an account's transaction history, ordered by date.
        builder.HasIndex(t => new { t.AccountId, t.TransactionDate })
               .HasDatabaseName("IX_Transactions_AccountId_TransactionDate");
    }
}
