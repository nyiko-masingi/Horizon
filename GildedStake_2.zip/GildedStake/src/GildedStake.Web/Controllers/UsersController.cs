using GildedStake.Web.Common;
using GildedStake.Web.Services;
using GildedStake.Web.ViewModels.Users;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace GildedStake.Web.Controllers;

/// <summary>
/// Client management. Every authenticated role may view (Index/Details);
/// creating and editing clients needs an operational role; deleting a
/// client is a supervisory action.
/// </summary>
public class UsersController : Controller
{
    private const int PageSize = 10;

    private readonly IUserService _userService;
    private readonly ILogger<UsersController> _logger;

    public UsersController(IUserService userService, ILogger<UsersController> logger)
    {
        _userService = userService;
        _logger = logger;
    }

    // GET /Users
    [HttpGet]
    public async Task<IActionResult> Index(string? searchTerm, int page = 1, CancellationToken ct = default)
    {
        var results = await _userService.SearchAsync(searchTerm, page, PageSize, ct);

        var model = new UsersIndexViewModel
        {
            SearchTerm = searchTerm,
            Users = results
        };

        return View(model);
    }

    // GET /Users/Create
    [HttpGet]
    [Authorize(Roles = Roles.OperationalRoles)]
    public IActionResult Create() => View(new UserFormViewModel());

    // POST /Users/Create
    [HttpPost]
    [Authorize(Roles = Roles.OperationalRoles)]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(UserFormViewModel model, CancellationToken ct)
    {
        if (!ModelState.IsValid)
        {
            return View(model);
        }

        var user = await _userService.CreateAsync(model.ToEntity(), ct);
        TempData["SuccessMessage"] = $"{user.FullName} was added successfully. You can now open a betting account for them.";
        return RedirectToAction(nameof(Details), new { id = user.Id });
    }

    // GET /Users/Details/5
    [HttpGet]
    public async Task<IActionResult> Details(int id, CancellationToken ct)
    {
        var user = await _userService.GetWithAccountsAsync(id, ct);
        if (user is null)
        {
            return RedirectToAction("HttpStatus", "Home", new { code = 404 });
        }

        var model = new UserDetailsViewModel
        {
            Form = UserFormViewModel.FromEntity(user),
            Accounts = user.Accounts.ToList()
        };

        return View(model);
    }

    // POST /Users/Details/5
    [HttpPost]
    [Authorize(Roles = Roles.OperationalRoles)]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Details(int id, UserDetailsViewModel model, CancellationToken ct)
    {
        model.Form.Id = id;

        if (!ModelState.IsValid)
        {
            var user = await _userService.GetWithAccountsAsync(id, ct);
            model.Accounts = user?.Accounts.ToList() ?? new();
            return View(model);
        }

        await _userService.UpdateAsync(model.Form.ToEntity(), ct);
        TempData["SuccessMessage"] = "User details were saved.";
        return RedirectToAction(nameof(Details), new { id });
    }

    // POST /Users/Delete/5
    [HttpPost]
    [Authorize(Roles = Roles.SupervisoryRoles)]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Delete(int id, CancellationToken ct)
    {
        await _userService.DeleteAsync(id, ct);
        TempData["SuccessMessage"] = "The user was deleted.";
        return RedirectToAction(nameof(Index));
    }
}
