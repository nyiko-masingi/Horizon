using GildedStake.Web.Common;
using GildedStake.Web.Models.Identity;
using GildedStake.Web.ViewModels.Auth;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace GildedStake.Web.Controllers;

/// <summary>
/// Sign-in, self-registration, and — for Administrators only — management of
/// system (login) accounts and their role assignments.
///
/// Named "Auth" (not "Account"/"Accounts") to stay unambiguous: this
/// controller manages who can log in and what they can do, while the
/// unrelated <see cref="AccountsController"/> manages wagering accounts.
/// </summary>
public class AuthController : Controller
{
    private readonly UserManager<ApplicationUser> _userManager;
    private readonly SignInManager<ApplicationUser> _signInManager;
    private readonly ILogger<AuthController> _logger;

    public AuthController(
        UserManager<ApplicationUser> userManager,
        SignInManager<ApplicationUser> signInManager,
        ILogger<AuthController> logger)
    {
        _userManager = userManager;
        _signInManager = signInManager;
        _logger = logger;
    }

    // ---------------------------------------------------------------
    // Sign in / sign out / self-registration
    // ---------------------------------------------------------------

    [HttpGet]
    [AllowAnonymous]
    public IActionResult Login(string? returnUrl = null)
    {
        if (User.Identity?.IsAuthenticated == true)
        {
            return RedirectToAction("Index", "Home");
        }

        return View(new LoginViewModel { ReturnUrl = returnUrl });
    }

    [HttpPost]
    [AllowAnonymous]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Login(LoginViewModel model, CancellationToken ct)
    {
        if (!ModelState.IsValid)
        {
            return View(model);
        }

        var user = await _userManager.FindByEmailAsync(model.Email);

        if (user is null)
        {
            ModelState.AddModelError(string.Empty, "Invalid email or password.");
            return View(model);
        }

        if (!user.IsActive)
        {
            ModelState.AddModelError(string.Empty, "This account has been deactivated. Please contact an administrator.");
            return View(model);
        }

        var result = await _signInManager.PasswordSignInAsync(user, model.Password, model.RememberMe, lockoutOnFailure: true);

        if (result.Succeeded)
        {
            _logger.LogInformation("User {Email} signed in", model.Email);
            TempData["SuccessMessage"] = $"Welcome back, {user.FirstName}.";

            if (!string.IsNullOrEmpty(model.ReturnUrl) && Url.IsLocalUrl(model.ReturnUrl))
            {
                return Redirect(model.ReturnUrl);
            }

            return RedirectToAction("Index", "Home");
        }

        if (result.IsLockedOut)
        {
            _logger.LogWarning("User {Email} is locked out", model.Email);
            ModelState.AddModelError(string.Empty, "Too many failed sign-in attempts. Please try again in a few minutes.");
            return View(model);
        }

        ModelState.AddModelError(string.Empty, "Invalid email or password.");
        return View(model);
    }

    [HttpPost]
    [Authorize]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Logout()
    {
        await _signInManager.SignOutAsync();
        TempData["SuccessMessage"] = "You have been signed out.";
        return RedirectToAction("Index", "Home");
    }

    [HttpGet]
    [AllowAnonymous]
    public IActionResult Register()
    {
        if (User.Identity?.IsAuthenticated == true)
        {
            return RedirectToAction("Index", "Home");
        }

        return View(new RegisterViewModel());
    }

    [HttpPost]
    [AllowAnonymous]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Register(RegisterViewModel model, CancellationToken ct)
    {
        if (!ModelState.IsValid)
        {
            return View(model);
        }

        var existing = await _userManager.FindByEmailAsync(model.Email);
        if (existing is not null)
        {
            ModelState.AddModelError(nameof(model.Email), "An account with this email address already exists.");
            return View(model);
        }

        var user = new ApplicationUser
        {
            UserName = model.Email,
            Email = model.Email,
            EmailConfirmed = true,
            FirstName = model.FirstName.Trim(),
            Surname = model.Surname.Trim(),
            IsActive = true,
        };

        var result = await _userManager.CreateAsync(user, model.Password);
        if (!result.Succeeded)
        {
            foreach (var error in result.Errors)
            {
                ModelState.AddModelError(string.Empty, error.Description);
            }
            return View(model);
        }

        // Self-registration always grants the least-privileged operational role.
        // An Administrator can promote the account afterwards from Manage Accounts.
        await _userManager.AddToRoleAsync(user, Roles.Teller);

        await _signInManager.SignInAsync(user, isPersistent: false);
        _logger.LogInformation("New account registered: {Email}", model.Email);

        TempData["SuccessMessage"] = $"Welcome to The Gilded Stake, {user.FirstName}. Your account has been created with Teller access.";
        return RedirectToAction("Index", "Home");
    }

    [HttpGet]
    [AllowAnonymous]
    public IActionResult AccessDenied()
    {
        return View();
    }

    // ---------------------------------------------------------------
    // Administrator-only: manage system accounts
    // ---------------------------------------------------------------

    [HttpGet]
    [Authorize(Roles = Roles.Administrator)]
    public async Task<IActionResult> ManageAccounts()
    {
        var currentUserId = _userManager.GetUserId(User);
        var accounts = new List<SystemAccountListItemViewModel>();

        foreach (var user in _userManager.Users.OrderBy(u => u.Surname).ThenBy(u => u.FirstName).ToList())
        {
            var roles = await _userManager.GetRolesAsync(user);
            accounts.Add(new SystemAccountListItemViewModel
            {
                Id = user.Id,
                FullName = user.FullName,
                Email = user.Email ?? string.Empty,
                Role = roles.FirstOrDefault() ?? "(none)",
                IsActive = user.IsActive,
                CreatedAtUtc = user.CreatedAtUtc,
                IsCurrentUser = user.Id == currentUserId,
            });
        }

        return View(new SystemAccountsIndexViewModel { Accounts = accounts });
    }

    [HttpGet]
    [Authorize(Roles = Roles.Administrator)]
    public IActionResult CreateAccount()
    {
        return View(new CreateSystemAccountViewModel());
    }

    [HttpPost]
    [Authorize(Roles = Roles.Administrator)]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> CreateAccount(CreateSystemAccountViewModel model, CancellationToken ct)
    {
        if (!Roles.All.Contains(model.Role))
        {
            ModelState.AddModelError(nameof(model.Role), "Choose a valid role.");
        }

        if (!ModelState.IsValid)
        {
            return View(model);
        }

        var existing = await _userManager.FindByEmailAsync(model.Email);
        if (existing is not null)
        {
            ModelState.AddModelError(nameof(model.Email), "An account with this email address already exists.");
            return View(model);
        }

        var user = new ApplicationUser
        {
            UserName = model.Email,
            Email = model.Email,
            EmailConfirmed = true,
            FirstName = model.FirstName.Trim(),
            Surname = model.Surname.Trim(),
            IsActive = true,
        };

        var result = await _userManager.CreateAsync(user, model.Password);
        if (!result.Succeeded)
        {
            foreach (var error in result.Errors)
            {
                ModelState.AddModelError(string.Empty, error.Description);
            }
            return View(model);
        }

        await _userManager.AddToRoleAsync(user, model.Role);
        _logger.LogInformation("Administrator {Admin} created system account {Email} with role {Role}", User.Identity?.Name, model.Email, model.Role);

        TempData["SuccessMessage"] = $"System account for {user.FullName} was created with {model.Role} access.";
        return RedirectToAction(nameof(ManageAccounts));
    }

    [HttpPost]
    [Authorize(Roles = Roles.Administrator)]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> ToggleActive(string id, CancellationToken ct)
    {
        var currentUserId = _userManager.GetUserId(User);
        if (id == currentUserId)
        {
            TempData["ErrorMessage"] = "You cannot deactivate your own account while signed in as it.";
            return RedirectToAction(nameof(ManageAccounts));
        }

        var user = await _userManager.FindByIdAsync(id);
        if (user is null)
        {
            return RedirectToAction("HttpStatus", "Home", new { code = 404 });
        }

        user.IsActive = !user.IsActive;
        await _userManager.UpdateAsync(user);
        // Refresh the security stamp so an active session for this account is
        // invalidated on its next validation pass rather than lingering.
        await _userManager.UpdateSecurityStampAsync(user);

        TempData["SuccessMessage"] = user.IsActive
            ? $"{user.FullName}'s account has been reactivated."
            : $"{user.FullName}'s account has been deactivated.";
        return RedirectToAction(nameof(ManageAccounts));
    }

    [HttpPost]
    [Authorize(Roles = Roles.Administrator)]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> ChangeRole(string id, string newRole, CancellationToken ct)
    {
        var currentUserId = _userManager.GetUserId(User);
        if (id == currentUserId)
        {
            TempData["ErrorMessage"] = "You cannot change your own role. Ask another Administrator to do this for you.";
            return RedirectToAction(nameof(ManageAccounts));
        }

        if (!Roles.All.Contains(newRole))
        {
            TempData["ErrorMessage"] = "Choose a valid role.";
            return RedirectToAction(nameof(ManageAccounts));
        }

        var user = await _userManager.FindByIdAsync(id);
        if (user is null)
        {
            return RedirectToAction("HttpStatus", "Home", new { code = 404 });
        }

        var currentRoles = await _userManager.GetRolesAsync(user);

        // Safety rule: never let the house end up with zero Administrators.
        if (currentRoles.Contains(Roles.Administrator) && newRole != Roles.Administrator)
        {
            var admins = await _userManager.GetUsersInRoleAsync(Roles.Administrator);
            if (admins.Count <= 1)
            {
                TempData["ErrorMessage"] = "This is the only remaining Administrator account, so its role cannot be changed.";
                return RedirectToAction(nameof(ManageAccounts));
            }
        }

        if (currentRoles.Count > 0)
        {
            await _userManager.RemoveFromRolesAsync(user, currentRoles);
        }
        await _userManager.AddToRoleAsync(user, newRole);

        TempData["SuccessMessage"] = $"{user.FullName} is now assigned the {newRole} role.";
        return RedirectToAction(nameof(ManageAccounts));
    }
}
