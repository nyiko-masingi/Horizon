using GildedStake.Web.Models;

namespace GildedStake.Web.Services;

public interface ITransactionService
{
    Task<Transaction?> GetByIdAsync(int id, CancellationToken ct = default);
    Task<Transaction> CreateAsync(int accountId, Transaction transaction, CancellationToken ct = default);
    Task UpdateAsync(Transaction transaction, CancellationToken ct = default);
}
