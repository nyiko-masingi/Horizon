using GildedStake.Web.Models;

namespace GildedStake.Web.Services;

public interface IAccountService
{
    Task<Account?> GetWithTransactionsAsync(int id, CancellationToken ct = default);
    Task<Account?> GetByIdAsync(int id, CancellationToken ct = default);
    Task<Account> CreateAsync(int userId, Account account, CancellationToken ct = default);
    Task UpdateAsync(Account account, CancellationToken ct = default);
    Task CloseAsync(int accountId, CancellationToken ct = default);
    Task ReopenAsync(int accountId, CancellationToken ct = default);
}
