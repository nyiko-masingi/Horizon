namespace GildedStake.Web.Services.Exceptions;

/// <summary>Thrown when a requested entity does not exist.</summary>
public class NotFoundException : Exception
{
    public NotFoundException(string message) : base(message)
    {
    }
}
