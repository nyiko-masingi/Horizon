namespace GildedStake.Web.Services.Exceptions;

/// <summary>
/// Thrown when an operation would violate a documented business rule
/// (e.g. duplicate ID number, closing an account with a non-zero balance).
/// Caught centrally and surfaced to the user as a friendly validation message.
/// </summary>
public class BusinessRuleException : Exception
{
    public BusinessRuleException(string message) : base(message)
    {
    }
}
