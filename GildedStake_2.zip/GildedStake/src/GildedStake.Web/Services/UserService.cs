using GildedStake.Web.Data;
using GildedStake.Web.Models;
using GildedStake.Web.Services.Exceptions;
using GildedStake.Web.ViewModels.Shared;
using Microsoft.EntityFrameworkCore;

namespace GildedStake.Web.Services;

public class UserService : IUserService
{
    private readonly ApplicationDbContext _context;
    private readonly ILogger<UserService> _logger;

    public UserService(ApplicationDbContext context, ILogger<UserService> logger)
    {
        _context = context;
        _logger = logger;
    }

    public async Task<PaginatedList<UserAccountSummary>> SearchAsync(string? searchTerm, int pageNumber, int pageSize, CancellationToken ct = default)
    {
        // Reads from the vw_UserAccountSummary SQL view rather than the raw tables.
        IQueryable<UserAccountSummary> query = _context.UserAccountSummaries.AsNoTracking();

        if (!string.IsNullOrWhiteSpace(searchTerm))
        {
            var term = searchTerm.Trim();
            query = query.Where(u =>
                EF.Functions.Like(u.Surname, $"%{term}%") ||
                EF.Functions.Like(u.IdNumber, $"%{term}%") ||
                (u.FirstAccountNumber != null && EF.Functions.Like(u.FirstAccountNumber, $"%{term}%")));
        }

        query = query.OrderBy(u => u.Surname).ThenBy(u => u.FirstName);

        return await PaginatedList<UserAccountSummary>.CreateAsync(query, pageNumber, pageSize);
    }

    public async Task<User?> GetByIdAsync(int id, CancellationToken ct = default) =>
        await _context.Users.AsNoTracking().FirstOrDefaultAsync(u => u.Id == id, ct);

    public async Task<User?> GetWithAccountsAsync(int id, CancellationToken ct = default) =>
        await _context.Users
            .Include(u => u.Accounts.OrderByDescending(a => a.OpenedAtUtc))
            .AsSplitQuery()
            .FirstOrDefaultAsync(u => u.Id == id, ct);

    public async Task<User> CreateAsync(User user, CancellationToken ct = default)
    {
        await EnsureUniqueIdNumberAsync(user.IdNumber, null, ct);

        user.CreatedAtUtc = DateTime.UtcNow;
        _context.Users.Add(user);
        await _context.SaveChangesAsync(ct);
        _logger.LogInformation("Created user {UserId} ({IdNumber})", user.Id, user.IdNumber);
        return user;
    }

    public async Task UpdateAsync(User user, CancellationToken ct = default)
    {
        var existing = await _context.Users.FirstOrDefaultAsync(u => u.Id == user.Id, ct)
            ?? throw new NotFoundException($"User {user.Id} was not found.");

        await EnsureUniqueIdNumberAsync(user.IdNumber, user.Id, ct);

        existing.FirstName = user.FirstName;
        existing.Surname = user.Surname;
        existing.IdNumber = user.IdNumber;
        existing.Email = user.Email;
        existing.PhoneNumber = user.PhoneNumber;
        existing.DateOfBirth = user.DateOfBirth;

        if (user.RowVersion is not null)
        {
            _context.Entry(existing).Property(u => u.RowVersion).OriginalValue = user.RowVersion;
        }

        await _context.SaveChangesAsync(ct);
        _logger.LogInformation("Updated user {UserId}", user.Id);
    }

    public async Task DeleteAsync(int id, CancellationToken ct = default)
    {
        var user = await _context.Users
            .Include(u => u.Accounts)
            .FirstOrDefaultAsync(u => u.Id == id, ct)
            ?? throw new NotFoundException($"User {id} was not found.");

        // Business rule: only users with no accounts or where all accounts are closed may be deleted.
        var hasOpenAccount = user.Accounts.Any(a => !a.IsClosed);
        if (hasOpenAccount)
        {
            throw new BusinessRuleException(
                "This user cannot be deleted because they still have one or more open accounts. Close every account first.");
        }

        _context.Users.Remove(user);
        await _context.SaveChangesAsync(ct);
        _logger.LogInformation("Deleted user {UserId}", id);
    }

    private async Task EnsureUniqueIdNumberAsync(string idNumber, int? excludingUserId, CancellationToken ct)
    {
        var duplicate = await _context.Users
            .AsNoTracking()
            .AnyAsync(u => u.IdNumber == idNumber && u.Id != (excludingUserId ?? 0), ct);

        if (duplicate)
        {
            throw new BusinessRuleException($"A user with ID number \"{idNumber}\" already exists.");
        }
    }
}
