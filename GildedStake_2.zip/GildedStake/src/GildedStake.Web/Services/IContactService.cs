using GildedStake.Web.Models;

namespace GildedStake.Web.Services;

public interface IContactService
{
    Task SubmitAsync(ContactMessage message, CancellationToken ct = default);
}
