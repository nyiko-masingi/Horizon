using GildedStake.Web.Models;
using GildedStake.Web.ViewModels.Shared;

namespace GildedStake.Web.Services;

public interface IUserService
{
    Task<PaginatedList<UserAccountSummary>> SearchAsync(string? searchTerm, int pageNumber, int pageSize, CancellationToken ct = default);
    Task<User?> GetByIdAsync(int id, CancellationToken ct = default);
    Task<User?> GetWithAccountsAsync(int id, CancellationToken ct = default);
    Task<User> CreateAsync(User user, CancellationToken ct = default);
    Task UpdateAsync(User user, CancellationToken ct = default);
    Task DeleteAsync(int id, CancellationToken ct = default);
}
