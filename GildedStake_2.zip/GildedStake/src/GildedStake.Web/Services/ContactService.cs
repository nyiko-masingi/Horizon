using GildedStake.Web.Data;
using GildedStake.Web.Models;

namespace GildedStake.Web.Services;

public class ContactService : IContactService
{
    private readonly ApplicationDbContext _context;
    private readonly ILogger<ContactService> _logger;

    public ContactService(ApplicationDbContext context, ILogger<ContactService> logger)
    {
        _context = context;
        _logger = logger;
    }

    public async Task SubmitAsync(ContactMessage message, CancellationToken ct = default)
    {
        message.SentAtUtc = DateTime.UtcNow;
        _context.ContactMessages.Add(message);
        await _context.SaveChangesAsync(ct);
        _logger.LogInformation("Received contact message from {Email}", message.Email);
    }
}
