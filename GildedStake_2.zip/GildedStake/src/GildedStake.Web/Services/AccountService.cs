using GildedStake.Web.Data;
using GildedStake.Web.Models;
using GildedStake.Web.Services.Exceptions;
using Microsoft.EntityFrameworkCore;

namespace GildedStake.Web.Services;

public class AccountService : IAccountService
{
    private readonly ApplicationDbContext _context;
    private readonly ILogger<AccountService> _logger;

    public AccountService(ApplicationDbContext context, ILogger<AccountService> logger)
    {
        _context = context;
        _logger = logger;
    }

    public async Task<Account?> GetWithTransactionsAsync(int id, CancellationToken ct = default)
    {
        var account = await _context.Accounts
            .Include(a => a.User)
            .FirstOrDefaultAsync(a => a.Id == id, ct);

        if (account is null)
        {
            return null;
        }

        if (_context.Database.IsRelational())
        {
            // Presentation-layer read via the sp_GetAccountStatement stored procedure
            // rather than a hand-rolled LINQ query.
            var accountIdParam = new Microsoft.Data.SqlClient.SqlParameter("@AccountId", id);
            account.Transactions = await _context.Transactions
                .FromSqlRaw("EXEC dbo.sp_GetAccountStatement @AccountId", accountIdParam)
                .AsNoTracking()
                .ToListAsync(ct);
        }
        else
        {
            // Non-relational providers (e.g. InMemory, used by unit tests) have no
            // stored procedure to call — fall back to an equivalent LINQ query.
            account.Transactions = await _context.Transactions
                .Where(t => t.AccountId == id)
                .OrderByDescending(t => t.TransactionDate)
                .ThenByDescending(t => t.Id)
                .AsNoTracking()
                .ToListAsync(ct);
        }

        return account;
    }

    public async Task<Account?> GetByIdAsync(int id, CancellationToken ct = default) =>
        await _context.Accounts.AsNoTracking().FirstOrDefaultAsync(a => a.Id == id, ct);

    public async Task<Account> CreateAsync(int userId, Account account, CancellationToken ct = default)
    {
        // Business rule: new accounts can only be added after the person is created.
        var userExists = await _context.Users.AsNoTracking().AnyAsync(u => u.Id == userId, ct);
        if (!userExists)
        {
            throw new NotFoundException($"User {userId} was not found.");
        }

        await EnsureUniqueAccountNumberAsync(account.AccountNumber, null, ct);

        account.UserId = userId;
        account.Balance = 0m; // The user is never allowed to set the opening balance directly.
        account.IsClosed = false;
        account.OpenedAtUtc = DateTime.UtcNow;

        _context.Accounts.Add(account);
        await _context.SaveChangesAsync(ct);
        _logger.LogInformation("Created account {AccountId} for user {UserId}", account.Id, userId);
        return account;
    }

    public async Task UpdateAsync(Account account, CancellationToken ct = default)
    {
        var existing = await _context.Accounts.FirstOrDefaultAsync(a => a.Id == account.Id, ct)
            ?? throw new NotFoundException($"Account {account.Id} was not found.");

        await EnsureUniqueAccountNumberAsync(account.AccountNumber, account.Id, ct);

        // The outstanding balance is deliberately never assigned from user input here.
        existing.AccountNumber = account.AccountNumber;
        existing.AccountName = account.AccountName;

        if (account.RowVersion is not null)
        {
            _context.Entry(existing).Property(a => a.RowVersion).OriginalValue = account.RowVersion;
        }

        await _context.SaveChangesAsync(ct);
        _logger.LogInformation("Updated account {AccountId}", account.Id);
    }

    public async Task CloseAsync(int accountId, CancellationToken ct = default)
    {
        var account = await _context.Accounts.FirstOrDefaultAsync(a => a.Id == accountId, ct)
            ?? throw new NotFoundException($"Account {accountId} was not found.");

        if (account.IsClosed)
        {
            throw new BusinessRuleException("This account is already closed.");
        }

        // Business rule: you cannot close an account when the balance is not zero.
        if (account.Balance != 0m)
        {
            throw new BusinessRuleException(
                $"This account cannot be closed while its balance is {account.Balance:C2}. The balance must be exactly zero.");
        }

        account.IsClosed = true;
        account.ClosedAtUtc = DateTime.UtcNow;
        await _context.SaveChangesAsync(ct);
        _logger.LogInformation("Closed account {AccountId}", accountId);
    }

    public async Task ReopenAsync(int accountId, CancellationToken ct = default)
    {
        var account = await _context.Accounts.FirstOrDefaultAsync(a => a.Id == accountId, ct)
            ?? throw new NotFoundException($"Account {accountId} was not found.");

        if (!account.IsClosed)
        {
            throw new BusinessRuleException("This account is already open.");
        }

        account.IsClosed = false;
        account.ClosedAtUtc = null;
        await _context.SaveChangesAsync(ct);
        _logger.LogInformation("Reopened account {AccountId}", accountId);
    }

    private async Task EnsureUniqueAccountNumberAsync(string accountNumber, int? excludingAccountId, CancellationToken ct)
    {
        var duplicate = await _context.Accounts
            .AsNoTracking()
            .AnyAsync(a => a.AccountNumber == accountNumber && a.Id != (excludingAccountId ?? 0), ct);

        if (duplicate)
        {
            throw new BusinessRuleException($"An account with number \"{accountNumber}\" already exists.");
        }
    }
}
