using GildedStake.Web.Data;
using GildedStake.Web.Models;
using GildedStake.Web.Models.Enums;
using GildedStake.Web.Services.Exceptions;
using Microsoft.EntityFrameworkCore;

namespace GildedStake.Web.Services;

public class TransactionService : ITransactionService
{
    private readonly ApplicationDbContext _context;
    private readonly ILogger<TransactionService> _logger;

    public TransactionService(ApplicationDbContext context, ILogger<TransactionService> logger)
    {
        _context = context;
        _logger = logger;
    }

    public async Task<Transaction?> GetByIdAsync(int id, CancellationToken ct = default) =>
        await _context.Transactions
            .Include(t => t.Account)
            .FirstOrDefaultAsync(t => t.Id == id, ct);

    public async Task<Transaction> CreateAsync(int accountId, Transaction transaction, CancellationToken ct = default)
    {
        ValidateTransactionShape(transaction);

        var account = await _context.Accounts.FirstOrDefaultAsync(a => a.Id == accountId, ct)
            ?? throw new NotFoundException($"Account {accountId} was not found.");

        // Business rule: no transactions may be posted to closed accounts.
        if (account.IsClosed)
        {
            throw new BusinessRuleException("Transactions cannot be posted to a closed account. Reopen the account first.");
        }

        transaction.AccountId = accountId;
        transaction.CaptureDateUtc = DateTime.UtcNow;
        account.Balance += transaction.Type == TransactionType.Credit ? transaction.Amount : -transaction.Amount;

        _context.Transactions.Add(transaction);

        // A single SaveChangesAsync call persists the new transaction and the
        // recalculated balance together inside one implicit database transaction,
        // so the two writes can never be observed independently.
        await _context.SaveChangesAsync(ct);

        _logger.LogInformation("Posted transaction {TransactionId} to account {AccountId}", transaction.Id, accountId);
        return transaction;
    }

    public async Task UpdateAsync(Transaction transaction, CancellationToken ct = default)
    {
        ValidateTransactionShape(transaction);

        var existing = await _context.Transactions.FirstOrDefaultAsync(t => t.Id == transaction.Id, ct)
            ?? throw new NotFoundException($"Transaction {transaction.Id} was not found.");

        var account = await _context.Accounts.FirstOrDefaultAsync(a => a.Id == existing.AccountId, ct)
            ?? throw new NotFoundException($"Account {existing.AccountId} was not found.");

        if (account.IsClosed)
        {
            throw new BusinessRuleException("Transactions on a closed account cannot be edited. Reopen the account first.");
        }

        // Reverse the original effect on the balance before applying the new amount/type.
        account.Balance -= existing.Type == TransactionType.Credit ? existing.Amount : -existing.Amount;

        existing.TransactionDate = transaction.TransactionDate;
        existing.Type = transaction.Type;
        existing.Amount = transaction.Amount;
        existing.Description = transaction.Description;
        existing.CaptureDateUtc = DateTime.UtcNow; // System-controlled: refreshed on every edit.

        if (transaction.RowVersion is not null)
        {
            _context.Entry(existing).Property(t => t.RowVersion).OriginalValue = transaction.RowVersion;
        }

        account.Balance += existing.Type == TransactionType.Credit ? existing.Amount : -existing.Amount;

        // Both the transaction edit and the recalculated balance are saved together
        // inside one implicit database transaction via a single SaveChangesAsync call.
        await _context.SaveChangesAsync(ct);
        _logger.LogInformation("Updated transaction {TransactionId}", transaction.Id);
    }

    private static void ValidateTransactionShape(Transaction transaction)
    {
        // Business rule: the transaction amount can never be zero.
        if (transaction.Amount == 0m)
        {
            throw new BusinessRuleException("The transaction amount cannot be zero.");
        }

        if (transaction.Amount < 0m)
        {
            throw new BusinessRuleException("The transaction amount must be entered as a positive value; use Debit or Credit to indicate direction.");
        }

        // Business rule: the transaction date can never be in the future.
        if (transaction.TransactionDate > DateOnly.FromDateTime(DateTime.UtcNow))
        {
            throw new BusinessRuleException("The transaction date cannot be in the future.");
        }
    }
}
