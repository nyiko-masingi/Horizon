import { useLocation } from 'react-router-dom';
import Hero from '../components/Hero.jsx';
import Reveal from '../components/Reveal.jsx';
import SectionHeading from '../components/SectionHeading.jsx';
import BookingForm from '../components/BookingForm.jsx';
import { CONTACT, TAGLINE } from '../data/content.js';

export default function Contact() {
  const location = useLocation();
  const corporate = Boolean(location.state?.corporate);

  return (
    <>
      <Hero
        page
        eyebrow="Get in Touch"
        title="Begin Your Elevated Journey"
        sub="We would be honoured to be your travel partner. Reserve below, call our 24-hour reservations line, or chat to us on WhatsApp."
      />

      <section className="section">
        <div className="container">
          <SectionHeading
            eyebrow={corporate ? 'Corporate Enquiries · Reservations' : 'Reservations'}
            title={corporate ? 'Corporate Accounts & Bookings' : 'Book a Journey'}
            lede={
              corporate
                ? 'For corporate accounts, mention your company name and expected monthly volume under Special Requests — our accounts team will structure a dedicated proposal.'
                : undefined
            }
          />

          <div className="contact-layout">
            <Reveal>
              <aside className="contact-panel">
                <dl>
                  <div>
                    <dt>Central Reservations</dt>
                    <dd><a href={CONTACT.reservationsHref}>{CONTACT.reservations}</a></dd>
                  </div>
                  <div>
                    <dt>24-Hour Emergency Line</dt>
                    <dd><a href={CONTACT.emergencyHref}>{CONTACT.emergency}</a></dd>
                  </div>
                  <div>
                    <dt>Email</dt>
                    <dd><a href={`mailto:${CONTACT.email}`}>{CONTACT.email}</a></dd>
                  </div>
                  <div>
                    <dt>Operating Hours</dt>
                    <dd>{CONTACT.hours}</dd>
                  </div>
                  <div>
                    <dt>Our Office · Pretoria</dt>
                    <dd>{CONTACT.office}</dd>
                  </div>
                </dl>

                <a className="whatsapp-cta" href={CONTACT.whatsappHref} target="_blank" rel="noreferrer">
                  WhatsApp Reservations
                </a>

                <p className="socials">
                  <strong>{CONTACT.social}</strong>
                  <br />
                  {CONTACT.socials.join(' · ')}
                </p>
              </aside>
            </Reveal>

            <Reveal delay={140}>
              <BookingForm />
            </Reveal>
          </div>
        </div>
      </section>

      <section className="cta-band" aria-label="Brand tagline">
        <div className="container">
          <Reveal>
            <h2>“{TAGLINE}”</h2>
          </Reveal>
        </div>
      </section>
    </>
  );
}
