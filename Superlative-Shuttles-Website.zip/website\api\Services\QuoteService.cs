using SuperlativeShuttles.Api.Models;

namespace SuperlativeShuttles.Api.Services;

/// <summary>
/// Fare estimation. Mirrors the dev middleware in client/vite.config.js —
/// if the algorithm changes, change both (the JSON contract must match).
/// </summary>
public sealed class QuoteService(RateCardService rateCards)
{
    public sealed class QuoteError(string message, int statusCode) : Exception(message)
    {
        public int StatusCode { get; } = statusCode;
    }

    public QuoteResponse Estimate(QuoteRequest req)
    {
        var card = rateCards.Current;

        var pickup = card.Zones.FirstOrDefault(z => z.Id == req.PickupZoneId)
                     ?? throw new QuoteError("Unknown pickup zone.", 400);
        var dropoff = card.Zones.FirstOrDefault(z => z.Id == req.DropoffZoneId)
                      ?? throw new QuoteError("Unknown drop-off zone.", 400);
        var vehicle = card.VehicleClasses.FirstOrDefault(v => v.Id == req.VehicleClassId)
                      ?? throw new QuoteError("Unknown vehicle class.", 400);

        if (pickup.Id == dropoff.Id)
            throw new QuoteError("Pickup and drop-off must differ.", 400);

        if (req.Passengers > vehicle.MaxPassengers)
            throw new QuoteError(
                $"{vehicle.Name} seats up to {vehicle.MaxPassengers} passengers. Please select a larger vehicle class.",
                422);

        var rawKm = HaversineKm(pickup, dropoff) * card.DistanceModel.RoadFactor;
        var km = Math.Max(card.DistanceModel.MinimumKm, (int)Math.Round(rawKm));

        var subtotal = vehicle.BaseFare + km * vehicle.PerKm;
        subtotal = Math.Max(subtotal, vehicle.MinimumFare);

        var lines = new List<QuoteLine>
        {
            new("Base fare", vehicle.BaseFare),
            new($"Distance (±{km} km)", Math.Round(km * vehicle.PerKm)),
        };

        if (pickup.Airport)
        {
            subtotal += card.Surcharges.AirportPickup;
            lines.Add(new("Airport meet & greet", card.Surcharges.AirportPickup));
        }

        if (IsAfterHours(req.PickupTime, card.Surcharges.AfterHours))
        {
            var s = Math.Round(subtotal * card.Surcharges.AfterHours.Rate);
            subtotal += s;
            lines.Add(new("After-hours service", s));
        }

        var spread = card.EstimateSpreadPercent / 100m;
        return new QuoteResponse(
            card.Currency,
            vehicle.Name,
            km,
            RoundTo10(subtotal * (1 - spread)),
            RoundTo10(subtotal * (1 + spread)),
            lines,
            "Estimate only. A firm, all-inclusive quotation is confirmed by our reservations team before every trip — no hidden fees, no surprises.");
    }

    private static decimal RoundTo10(decimal n) => Math.Round(n / 10m) * 10m;

    private static double HaversineKm(Zone a, Zone b)
    {
        const double R = 6371;
        double ToRad(double d) => d * Math.PI / 180;
        var dLat = ToRad(b.Lat - a.Lat);
        var dLng = ToRad(b.Lng - a.Lng);
        var s = Math.Pow(Math.Sin(dLat / 2), 2)
                + Math.Cos(ToRad(a.Lat)) * Math.Cos(ToRad(b.Lat)) * Math.Pow(Math.Sin(dLng / 2), 2);
        return 2 * R * Math.Asin(Math.Sqrt(s));
    }

    private static bool IsAfterHours(string? time, AfterHours cfg)
    {
        if (string.IsNullOrWhiteSpace(time) || !TimeOnly.TryParse(time, out var t))
            return false;
        var from = TimeOnly.Parse(cfg.From);
        var to = TimeOnly.Parse(cfg.To);
        return from > to ? t >= from || t < to : t >= from && t < to;
    }
}
