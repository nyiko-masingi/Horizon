using System.Net;
using System.Net.Mail;
using System.Text.Json;
using SuperlativeShuttles.Api.Models;

namespace SuperlativeShuttles.Api.Services;

/// <summary>
/// Persists booking requests and sends the confirmation notification.
/// Storage here is an append-only JSON file for simplicity — swap for
/// EF Core / Azure Table Storage when volumes require it (the interface
/// to the frontend does not change).
/// </summary>
public sealed class BookingService(IConfiguration config, IWebHostEnvironment env, ILogger<BookingService> logger)
{
    private readonly object _lock = new();

    public async Task<BookingResponse> SubmitAsync(BookingRequest req)
    {
        var reference = $"SS-{DateTimeOffset.UtcNow.ToUnixTimeMilliseconds():X}"[..9].ToUpperInvariant();

        Persist(reference, req);
        await NotifyAsync(reference, req);

        return new BookingResponse(
            reference,
            "received",
            "Reservation request received. Our reservations team will confirm within 30 minutes — 24 hours a day, 365 days a year.");
    }

    private void Persist(string reference, BookingRequest req)
    {
        var dir = Path.Combine(env.ContentRootPath, "App_Data");
        Directory.CreateDirectory(dir);
        var file = Path.Combine(dir, "bookings.json");

        lock (_lock)
        {
            var list = File.Exists(file)
                ? JsonSerializer.Deserialize<List<Dictionary<string, object?>>>(File.ReadAllText(file)) ?? []
                : [];
            list.Add(new Dictionary<string, object?>
            {
                ["reference"] = reference,
                ["receivedAt"] = DateTimeOffset.UtcNow.ToString("O"),
                ["booking"] = req,
            });
            File.WriteAllText(file, JsonSerializer.Serialize(list, new JsonSerializerOptions { WriteIndented = true }));
        }
    }

    private async Task NotifyAsync(string reference, BookingRequest req)
    {
        // SMTP settings live in appsettings / Azure App Service configuration.
        var smtp = config.GetSection("Smtp");
        var host = smtp["Host"];
        if (string.IsNullOrWhiteSpace(host))
        {
            logger.LogWarning("SMTP not configured — booking {Reference} stored without email notification.", reference);
            return;
        }

        using var client = new SmtpClient(host, smtp.GetValue("Port", 587))
        {
            EnableSsl = true,
            Credentials = new NetworkCredential(smtp["Username"], smtp["Password"]),
        };

        var ops = smtp["OperationsInbox"] ?? "info@superlativeshuttles.co.za";
        var from = smtp["From"] ?? "reservations@superlativeshuttles.co.za";

        var body = $"""
            New reservation request {reference}

            Name:        {req.FullName}
            Phone:       {req.Phone}
            Email:       {req.Email}
            Date / time: {req.Date} at {req.Time}
            Pickup:      {req.Pickup}
            Drop-off:    {req.Dropoff}
            Vehicle:     {req.VehicleClassId}
            Passengers:  {req.Passengers}
            Requests:    {req.SpecialRequests ?? "—"}
            """;

        // Operations copy
        await client.SendMailAsync(new MailMessage(from, ops, $"[{reference}] New reservation — {req.FullName}", body));

        // Client acknowledgement
        var ack = $"""
            Dear {req.FullName},

            Thank you for choosing Superlative Shuttles. Your reservation request {reference} has been
            received and our reservations team will confirm within 30 minutes.

            Central Reservations: +27 82 887 0505 (24 hours, 365 days a year)

            Beyond Transport. An Elevated Experience.
            Superlative Shuttles — Where Every Journey Is Extraordinary.
            """;
        await client.SendMailAsync(new MailMessage(from, req.Email, $"Your Superlative Shuttles reservation {reference}", ack));
    }
}
