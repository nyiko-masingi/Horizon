import Reveal from './Reveal.jsx';

/** Numbered card — used for both Services (01–05) and Why Choose Us (01–06). */
export default function ServiceCard({ numeral, title, copy, delay = 0 }) {
  return (
    <Reveal delay={delay}>
      <article className="service-card">
        <span className="service-card__numeral" aria-hidden="true">{numeral}</span>
        <h3>{title}</h3>
        <hr className="service-card__rule" />
        <p>{copy}</p>
      </article>
    </Reveal>
  );
}
