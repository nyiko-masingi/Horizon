import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const RATECARD_PATH = path.resolve(__dirname, '../rates/ratecard.json');
const DEV_DATA_DIR = path.resolve(__dirname, '../.dev-data');

/**
 * Local development stand-in for the production ASP.NET Core API
 * (website/api). It serves the exact same contract from the same
 * rates/ratecard.json so no pricing ever lives in the React code.
 * In production the frontend calls the Azure-hosted API instead.
 */
function devApiPlugin() {
  const loadRateCard = () =>
    JSON.parse(fs.readFileSync(RATECARD_PATH, 'utf-8'));

  const haversineKm = (a, b) => {
    const R = 6371;
    const toRad = (d) => (d * Math.PI) / 180;
    const dLat = toRad(b.lat - a.lat);
    const dLng = toRad(b.lng - a.lng);
    const s =
      Math.sin(dLat / 2) ** 2 +
      Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * Math.sin(dLng / 2) ** 2;
    return 2 * R * Math.asin(Math.sqrt(s));
  };

  const isAfterHours = (time, cfg) => {
    if (!time) return false;
    const [h, m] = time.split(':').map(Number);
    const mins = h * 60 + (m || 0);
    const [fh, fm] = cfg.from.split(':').map(Number);
    const [th, tm] = cfg.to.split(':').map(Number);
    const from = fh * 60 + fm;
    const to = th * 60 + tm;
    return from > to ? mins >= from || mins < to : mins >= from && mins < to;
  };

  const readBody = (req) =>
    new Promise((resolve, reject) => {
      let data = '';
      req.on('data', (c) => (data += c));
      req.on('end', () => {
        try {
          resolve(data ? JSON.parse(data) : {});
        } catch (e) {
          reject(e);
        }
      });
    });

  const json = (res, status, payload) => {
    res.statusCode = status;
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(payload));
  };

  return {
    name: 'superlative-dev-api',
    configureServer(server) {
      server.middlewares.use(async (req, res, next) => {
        if (!req.url.startsWith('/api/')) return next();
        const url = req.url.split('?')[0];
        const card = loadRateCard();

        // GET /api/rates/meta — zones + vehicle classes for form options
        // and "from" pricing display. Served, never hardcoded client-side.
        if (url === '/api/rates/meta' && req.method === 'GET') {
          return json(res, 200, {
            currency: card.currency,
            updated: card.updated,
            zones: card.zones.map(({ id, name, airport }) => ({ id, name, airport })),
            vehicleClasses: card.vehicleClasses.map((v) => ({
              id: v.id,
              name: v.name,
              examples: v.examples,
              maxPassengers: v.maxPassengers,
              hourlyRate: v.hourlyRate,
              minimumFare: v.minimumFare,
            })),
          });
        }

        // POST /api/quotes — server-side fare estimate
        if (url === '/api/quotes' && req.method === 'POST') {
          let body;
          try {
            body = await readBody(req);
          } catch {
            return json(res, 400, { error: 'Invalid JSON body.' });
          }
          const pickup = card.zones.find((z) => z.id === body.pickupZoneId);
          const dropoff = card.zones.find((z) => z.id === body.dropoffZoneId);
          const vehicle = card.vehicleClasses.find((v) => v.id === body.vehicleClassId);
          if (!pickup || !dropoff || !vehicle) {
            return json(res, 400, { error: 'Unknown zone or vehicle class.' });
          }
          if (pickup.id === dropoff.id) {
            return json(res, 400, { error: 'Pickup and drop-off must differ.' });
          }
          const passengers = Number(body.passengers) || 1;
          if (passengers > vehicle.maxPassengers) {
            return json(res, 422, {
              error: `${vehicle.name} seats up to ${vehicle.maxPassengers} passengers. Please select a larger vehicle class.`,
            });
          }

          const rawKm = haversineKm(pickup, dropoff) * card.distanceModel.roadFactor;
          const km = Math.max(card.distanceModel.minimumKm, Math.round(rawKm));
          let subtotal = vehicle.baseFare + km * vehicle.perKm;
          subtotal = Math.max(subtotal, vehicle.minimumFare);

          const lines = [
            { label: 'Base fare', amount: vehicle.baseFare },
            { label: `Distance (±${km} km)`, amount: Math.round(km * vehicle.perKm) },
          ];
          if (pickup.airport) {
            subtotal += card.surcharges.airportPickup;
            lines.push({ label: 'Airport meet & greet', amount: card.surcharges.airportPickup });
          }
          if (isAfterHours(body.pickupTime, card.surcharges.afterHours)) {
            const s = Math.round(subtotal * card.surcharges.afterHours.rate);
            subtotal += s;
            lines.push({ label: 'After-hours service', amount: s });
          }

          const spread = card.estimateSpreadPercent / 100;
          const round10 = (n) => Math.round(n / 10) * 10;
          return json(res, 200, {
            currency: card.currency,
            vehicleClass: vehicle.name,
            estimatedKm: km,
            low: round10(subtotal * (1 - spread)),
            high: round10(subtotal * (1 + spread)),
            breakdown: lines,
            disclaimer:
              'Estimate only. A firm, all-inclusive quotation is confirmed by our reservations team before every trip — no hidden fees, no surprises.',
          });
        }

        // POST /api/bookings — accepts a reservation request
        if (url === '/api/bookings' && req.method === 'POST') {
          let body;
          try {
            body = await readBody(req);
          } catch {
            return json(res, 400, { error: 'Invalid JSON body.' });
          }
          const required = ['fullName', 'email', 'phone', 'date', 'time', 'pickup', 'dropoff', 'vehicleClassId', 'passengers'];
          const missing = required.filter((k) => !String(body[k] ?? '').trim());
          if (missing.length) {
            return json(res, 400, { error: `Missing required fields: ${missing.join(', ')}` });
          }
          const reference = `SS-${Date.now().toString(36).toUpperCase().slice(-6)}`;
          fs.mkdirSync(DEV_DATA_DIR, { recursive: true });
          const file = path.join(DEV_DATA_DIR, 'bookings.json');
          const existing = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf-8')) : [];
          existing.push({ reference, receivedAt: new Date().toISOString(), ...body });
          fs.writeFileSync(file, JSON.stringify(existing, null, 2));
          // Production API also emails a confirmation — see api/Services/BookingService.cs
          return json(res, 201, {
            reference,
            status: 'received',
            message:
              'Reservation request received. Our reservations team will confirm within 30 minutes — 24 hours a day, 365 days a year.',
          });
        }

        return json(res, 404, { error: 'Not found.' });
      });
    },
  };
}

export default defineConfig({
  plugins: [react(), devApiPlugin()],
});
