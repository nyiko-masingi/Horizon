import { useEffect, useState } from 'react';
import { getRatesMeta, requestQuote } from '../lib/api.js';

const fmt = (n, currency) =>
  new Intl.NumberFormat('en-ZA', { style: 'currency', currency, maximumFractionDigits: 0 }).format(n);

/**
 * Interactive fare estimator. All pricing is calculated server-side against
 * the rate card — this component only collects inputs and renders the result.
 */
export default function QuoteCalculator() {
  const [meta, setMeta] = useState(null);
  const [metaError, setMetaError] = useState('');
  const [form, setForm] = useState({
    pickupZoneId: '',
    dropoffZoneId: '',
    vehicleClassId: '',
    passengers: 1,
    pickupTime: '',
  });
  const [quote, setQuote] = useState(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    getRatesMeta()
      .then(setMeta)
      .catch(() => setMetaError('Live rates are temporarily unavailable. Please call our reservations line for a quote.'));
  }, []);

  const set = (k) => (e) => {
    setForm((f) => ({ ...f, [k]: e.target.value }));
    setQuote(null);
    setError('');
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setQuote(null);
    if (!form.pickupZoneId || !form.dropoffZoneId || !form.vehicleClassId) {
      setError('Please choose a pickup area, drop-off area and vehicle class.');
      return;
    }
    if (form.pickupZoneId === form.dropoffZoneId) {
      setError('Pickup and drop-off areas must be different.');
      return;
    }
    setBusy(true);
    try {
      const q = await requestQuote({ ...form, passengers: Number(form.passengers) });
      setQuote(q);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  if (metaError) return <div className="form-alert form-alert--error">{metaError}</div>;
  if (!meta) return <p className="form-note">Loading live rate card…</p>;

  return (
    <form className="form-panel" onSubmit={onSubmit} noValidate>
      <div className="form-grid">
        <div className="form-field">
          <label htmlFor="q-pickup">Pickup Area</label>
          <select id="q-pickup" value={form.pickupZoneId} onChange={set('pickupZoneId')} required>
            <option value="">Select pickup…</option>
            {meta.zones.map((z) => (
              <option key={z.id} value={z.id}>{z.name}</option>
            ))}
          </select>
        </div>

        <div className="form-field">
          <label htmlFor="q-dropoff">Drop-off Area</label>
          <select id="q-dropoff" value={form.dropoffZoneId} onChange={set('dropoffZoneId')} required>
            <option value="">Select drop-off…</option>
            {meta.zones.map((z) => (
              <option key={z.id} value={z.id}>{z.name}</option>
            ))}
          </select>
        </div>

        <div className="form-field">
          <label htmlFor="q-vehicle">Vehicle Class</label>
          <select id="q-vehicle" value={form.vehicleClassId} onChange={set('vehicleClassId')} required>
            <option value="">Select vehicle…</option>
            {meta.vehicleClasses.map((v) => (
              <option key={v.id} value={v.id}>
                {v.name} — up to {v.maxPassengers} pax
              </option>
            ))}
          </select>
        </div>

        <div className="form-field">
          <label htmlFor="q-pax">Passengers</label>
          <input
            id="q-pax"
            type="number"
            min="1"
            max="65"
            value={form.passengers}
            onChange={set('passengers')}
          />
        </div>

        <div className="form-field form-field--full">
          <label htmlFor="q-time">Pickup Time (optional — after-hours trips carry a small surcharge)</label>
          <input id="q-time" type="time" value={form.pickupTime} onChange={set('pickupTime')} />
        </div>
      </div>

      <div className="form-actions">
        <button className="btn btn--solid" type="submit" disabled={busy}>
          {busy ? 'Calculating…' : 'Estimate My Fare'}
        </button>
        <span className="form-note">Calculated live against our rate card — never a guess.</span>
      </div>

      {error && <div className="form-alert form-alert--error" role="alert">{error}</div>}

      {quote && (
        <div className="quote-result" aria-live="polite">
          <div className="quote-result__range">
            {fmt(quote.low, quote.currency)} – {fmt(quote.high, quote.currency)}
            <small>
              {quote.vehicleClass} · approx. {quote.estimatedKm} km
            </small>
          </div>
          <table className="quote-result__breakdown">
            <tbody>
              {quote.breakdown.map((line) => (
                <tr key={line.label}>
                  <td>{line.label}</td>
                  <td>{fmt(line.amount, quote.currency)}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <p className="quote-result__disclaimer">{quote.disclaimer}</p>
        </div>
      )}
    </form>
  );
}
