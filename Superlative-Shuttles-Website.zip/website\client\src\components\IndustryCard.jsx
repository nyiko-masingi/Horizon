import Reveal from './Reveal.jsx';

export default function IndustryCard({ title, copy, delay = 0 }) {
  return (
    <Reveal delay={delay}>
      <article className="industry-card">
        <h3>{title}</h3>
        <p>{copy}</p>
      </article>
    </Reveal>
  );
}
