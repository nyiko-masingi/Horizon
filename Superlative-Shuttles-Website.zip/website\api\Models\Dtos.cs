using System.ComponentModel.DataAnnotations;

namespace SuperlativeShuttles.Api.Models;

public sealed record QuoteRequest(
    string PickupZoneId,
    string DropoffZoneId,
    string VehicleClassId,
    int Passengers,
    string? PickupTime);

public sealed record QuoteLine(string Label, decimal Amount);

public sealed record QuoteResponse(
    string Currency,
    string VehicleClass,
    int EstimatedKm,
    decimal Low,
    decimal High,
    IReadOnlyList<QuoteLine> Breakdown,
    string Disclaimer);

public sealed class BookingRequest
{
    [Required, StringLength(120)]
    public string FullName { get; set; } = string.Empty;

    [Required, EmailAddress]
    public string Email { get; set; } = string.Empty;

    [Required, StringLength(24, MinimumLength = 8)]
    public string Phone { get; set; } = string.Empty;

    [Required]
    public string Date { get; set; } = string.Empty;

    [Required]
    public string Time { get; set; } = string.Empty;

    [Required, StringLength(240)]
    public string Pickup { get; set; } = string.Empty;

    [Required, StringLength(240)]
    public string Dropoff { get; set; } = string.Empty;

    [Required]
    public string VehicleClassId { get; set; } = string.Empty;

    [Range(1, 65)]
    public int Passengers { get; set; } = 1;

    [StringLength(1000)]
    public string? SpecialRequests { get; set; }
}

public sealed record BookingResponse(string Reference, string Status, string Message);
