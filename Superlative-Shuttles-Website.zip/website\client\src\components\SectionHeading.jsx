import Reveal from './Reveal.jsx';

/** Eyebrow + serif heading + thin gold rule — the recurring brand motif. */
export default function SectionHeading({ eyebrow, title, lede, center = false }) {
  return (
    <Reveal className={`section-heading ${center ? 'section-heading--center' : ''}`}>
      {eyebrow && <p className="eyebrow">{eyebrow}</p>}
      <h2>{title}</h2>
      <hr className="gold-rule" />
      {lede && <p className="lede">{lede}</p>}
    </Reveal>
  );
}
