/**
 * Site copy — sourced from the Superlative Shuttles 2026 Company Profile.
 * Editorial content only. Pricing NEVER lives here; it is served by the API
 * from rates/ratecard.json.
 */

export const CONTACT = {
  reservations: '+27 82 887 0505',
  reservationsHref: 'tel:+27828870505',
  whatsappHref: 'https://wa.me/27828870505',
  emergency: '+27 69 707 8842',
  emergencyHref: 'tel:+27697078842',
  email: 'info@superlativeshuttles.co.za',
  hours: '24 hours · 7 days · 365 days a year',
  office: '44 Hamilton Street, Arcadia, Pretoria',
  social: '@SuperlativeShuttles',
  socials: ['Facebook', 'Instagram', 'LinkedIn', 'X (Twitter)'],
};

export const TAGLINE = 'Beyond Transport. An Elevated Experience.';
export const SIGNOFF = 'Superlative Shuttles — Where Every Journey Is Extraordinary.';

export const STATS = [
  { value: '100%', label: 'Client Satisfaction' },
  { value: '24/7', label: 'Availability & Support' },
  { value: 'SA', label: 'National Reach' },
  { value: '5', label: 'Luxury Standard Fleet' },
  { value: '0', label: 'Compromise on Quality' },
];

export const SERVICES = [
  {
    numeral: '01',
    title: 'Airport Transfers',
    copy: 'Seamless meet-and-greet at all major South African airports. We monitor flight status in real time, adjusting for delays so you never wait and never rush. Every arrival and departure is orchestrated with military precision.',
  },
  {
    numeral: '02',
    title: 'Corporate Transfers & Shuttles',
    copy: 'Scheduled and on-demand transport for executives, board members and corporate delegations. We partner with businesses to design bespoke daily shuttle routes and provide dedicated vehicles for ongoing corporate accounts.',
  },
  {
    numeral: '03',
    title: 'Chauffeur Services',
    copy: 'Travel in quiet luxury with our uniformed, professionally trained chauffeurs in Mercedes-Benz and premium sedans. Available hourly, half-day or full-day. Discretion, punctuality and elegance — guaranteed.',
  },
  {
    numeral: '04',
    title: 'MICE Event Transport',
    copy: 'End-to-end transport management for Meetings, Incentives, Conferences and Events. Route planning, priority access, VIP transfers and dedicated project managers — for fleets from small delegations to large-scale events.',
  },
  {
    numeral: '05',
    title: 'Tours & Travel',
    copy: 'Tailor-made day tours, pre-event and post-event travel across South Africa’s most iconic destinations. Expert guides, luxury coaches and curated itineraries that turn every transfer into an experience worth remembering.',
  },
];

export const DIFFERENTIATORS = [
  {
    numeral: '01',
    title: 'Professional & Uniformed Drivers',
    copy: 'Every driver undergoes rigorous vetting, criminal background checks and customer-service training. They arrive in uniform, on time, and ready to exceed your every expectation.',
  },
  {
    numeral: '02',
    title: '24/7 Availability',
    copy: 'Our operations centre never sleeps. Whether it’s a 3am airport departure or a midnight event transfer, we are always one call away — 365 days a year.',
  },
  {
    numeral: '03',
    title: 'Real-Time Flight & Route Monitoring',
    copy: 'We track your flight status live. If your flight is delayed, we adjust seamlessly — so you never have to worry about waiting, rushing, or communicating changes.',
  },
  {
    numeral: '04',
    title: 'Diverse, Luxury Fleet',
    copy: 'From executive sedans and premium MPVs to luxury coaches, our immaculately maintained fleet is equipped with climate control, Wi-Fi capability and premium interiors.',
  },
  {
    numeral: '05',
    title: 'National Reach, Local Knowledge',
    copy: 'We combine national coverage with deep local expertise — knowing every route, every airport, every venue, and every client’s preference, inside out.',
  },
  {
    numeral: '06',
    title: 'Transparent, Competitive Pricing',
    copy: 'No hidden fees. No surprises. We provide clear, upfront quotes and honour them — because trust is the foundation of every great partnership.',
  },
];

export const VALUES = [
  { title: 'Integrity', copy: 'We operate with transparency and honesty in every transaction and commitment we make.' },
  { title: 'Excellence', copy: 'Ordinary is not in our vocabulary. We set and exceed the highest bar in everything we do.' },
  { title: 'Punctuality', copy: 'Time is the most precious commodity our clients possess. We honour it, always.' },
  { title: 'Safety', copy: 'Every passenger is someone’s loved one. We treat them and their safety accordingly.' },
  { title: 'Innovation', copy: 'We continuously invest in better vehicles, smarter systems and refined processes.' },
  { title: 'Discretion', copy: 'Corporate and private clients trust us with their itineraries. That trust is sacred.' },
];

export const MVP = [
  {
    title: 'Mission',
    copy: 'To deliver superior, cost-effective luxury transport solutions that place every passenger at their destination safely, comfortably and precisely on time — every single time.',
  },
  {
    title: 'Vision',
    copy: 'To be the most trusted and celebrated luxury transport partner in South Africa, synonymous with excellence, reliability and an uncompromising standard of class.',
  },
  {
    title: 'Philosophy',
    copy: 'We represent your brand in every journey. Our drivers are ambassadors, our vehicles are statements, and our service is an art form. Ordinary is simply not in our vocabulary.',
  },
];

export const APPROACH = [
  {
    title: 'Bespoke Service',
    copy: 'Every transport solution we provide is tailored to the specific needs, schedule and expectations of each client. We do not offer off-the-shelf packages.',
  },
  {
    title: 'Discretion & Professionalism',
    copy: 'We understand that our clients often require confidentiality and impeccable conduct. All drivers and staff are trained to the highest professional standards.',
  },
  {
    title: 'Reliability at Every Level',
    copy: 'Whether it is a single executive transfer or a multi-day event fleet, our commitment to punctuality, safety and quality never changes.',
  },
];

export const FLEET = [
  {
    type: 'Executive Sedans',
    models: 'BMW 3 Series, Mercedes-Benz E-Class',
    capacity: '1–3 pax',
    idealFor: 'Airport, corporate, chauffeur',
  },
  {
    type: 'Premium MPVs',
    models: 'Mercedes-Benz V-Class & equivalents',
    capacity: '1–6 pax',
    idealFor: 'Family, group & VIP transfers',
  },
  {
    type: 'Luxury Minibuses',
    models: '14–22 seater luxury minibuses',
    capacity: 'Up to 22',
    idealFor: 'Corporate groups, tours, events',
  },
  {
    type: 'Luxury Coaches',
    models: '45–65 seater luxury coaches',
    capacity: 'Up to 65',
    idealFor: 'Conferences, large tours',
  },
];

export const FLEET_ASSURANCES = [
  'Comprehensively insured',
  'GPS-tracked',
  'Air-conditioned',
  'Sanitised before every trip',
  'Roadworthy certified',
];

export const DRIVER_STANDARDS = [
  'Full PDP / Professional Driving Permit',
  'Background & criminal record checks',
  'Customer service & etiquette training',
  'First-aid certification',
  'Bilingual English proficiency',
  'Smart uniform at all times',
];

export const VEHICLE_FEATURES = [
  'Premium leather interiors',
  'Climate-controlled cabin environments',
  'In-vehicle Wi-Fi connectivity',
  'Complimentary water & refreshments',
  'Privacy glass',
  'Quiet ride noise insulation',
];

export const INDUSTRIES = [
  {
    title: 'Government & Public Sector',
    copy: 'We have provided professional transport solutions to government departments, public entities and official delegations, ensuring that all engagements are handled with the requisite protocol, discretion and reliability.',
  },
  {
    title: 'Corporate & Executive Clients',
    copy: 'From listed companies to owner-managed businesses, we serve corporate clients who demand consistency, punctuality and a premium level of service for their executives, staff and visiting stakeholders.',
  },
  {
    title: 'Entertainment & Creative Industry',
    copy: 'Superlative Shuttles has served artists, performers, production teams and entertainment professionals, providing discreet, flexible and reliable transport that fits around demanding schedules and high-profile engagements.',
  },
  {
    title: 'Events & Conferences',
    copy: 'We provide comprehensive transport coordination for conferences, exhibitions, product launches and gala events of all scales — ensuring that guests and delegates arrive safely, on time and in the right impression.',
  },
  {
    title: 'Academic & Institutional Clients',
    copy: 'Universities, schools and academic institutions trust us for staff shuttles, student transport programmes and institutional event logistics, where safety and schedule reliability are non-negotiable.',
  },
  {
    title: 'Private & Leisure Clients',
    copy: 'Discerning individuals choose Superlative Shuttles for personal chauffeur services, private tours, special occasions and airport transfers — where comfort, privacy and a personal touch make every journey memorable.',
  },
];

export const SUSTAIN_ENV = [
  { title: 'Vehicle Maintenance', copy: 'Strict service schedules ensure optimal fuel efficiency and minimal emissions across our entire fleet.' },
  { title: 'Fuel Monitoring', copy: 'Daily fuel usage reporting keeps consumption lean and supports our carbon-reduction targets.' },
  { title: 'Eco-Friendly Products', copy: 'All vehicle cleaning products are 100% biodegradable and environmentally certified.' },
  { title: 'Digital Operations', copy: 'Paperless booking, invoicing and route planning dramatically reduce our paper footprint.' },
  { title: 'Route Optimisation', copy: 'Smart routing software minimises unnecessary mileage — reducing costs and carbon emissions.' },
  { title: 'Recycling Programmes', copy: 'A structured recycling programme is maintained across all our offices and facilities.' },
];

export const SUSTAIN_SOCIAL = [
  { title: 'Local Employment', copy: 'We actively recruit from local communities, contributing to job creation and skills development.' },
  { title: 'Learnership Support', copy: 'Structured programmes offer young South Africans a formal pathway into the transport industry.' },
  { title: 'Driver Wellness', copy: 'We invest in ongoing training, mental wellness support and advancement of all our staff.' },
  { title: 'Community Giving', copy: 'A portion of annual profits is channelled into community development in the areas we serve.' },
];

export const STORY = [
  'Superlative Shuttles is a premier South African luxury transport company, dedicated to redefining the travel experience for the country’s most discerning individuals, corporations and institutions.',
  'We were born from a simple belief: that the gap between ordinary and extraordinary transport is not about the vehicle — it is about the experience. Our founders, seasoned transport professionals, set out to build a company that redefined what clients could expect.',
  'Founded on a single conviction — that every passenger deserves to feel truly valued — Superlative Shuttles brings together professionally trained drivers, a handpicked fleet of luxury vehicles, and a passion for hospitality that sets us apart in every mile we travel.',
  'Today, we proudly serve individuals, corporates, event organisers and institutions across South Africa, maintaining the highest standards of vehicle care, driver excellence and client communication. From seamless airport transfers and bespoke chauffeur engagements to full-scale event transport logistics, we treat every booking as a privilege and every client as a VIP.',
];
