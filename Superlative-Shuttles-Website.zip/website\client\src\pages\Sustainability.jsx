import Hero from '../components/Hero.jsx';
import Reveal from '../components/Reveal.jsx';
import SectionHeading from '../components/SectionHeading.jsx';
import CtaBand from '../components/CtaBand.jsx';
import { SUSTAIN_ENV, SUSTAIN_SOCIAL } from '../data/content.js';

export default function Sustainability() {
  return (
    <>
      <Hero
        page
        eyebrow="Sustainability"
        title="Greening & Social Responsibility"
        sub="The transport sector carries a profound responsibility toward our environment and our communities. We have embedded sustainable practices into every aspect of our operations — because excellence extends beyond the journey."
      />

      <section className="section">
        <div className="container sustain-cols" style={{ marginTop: 0 }}>
          <Reveal>
            <div className="sustain-col">
              <h3>Environmental Responsibility</h3>
              {SUSTAIN_ENV.map((s) => (
                <div className="sustain-item" key={s.title}>
                  <h4>{s.title}</h4>
                  <p>{s.copy}</p>
                </div>
              ))}
            </div>
          </Reveal>
          <Reveal delay={140}>
            <div className="sustain-col">
              <h3>Social Responsibility</h3>
              {SUSTAIN_SOCIAL.map((s) => (
                <div className="sustain-item" key={s.title}>
                  <h4>{s.title}</h4>
                  <p>{s.copy}</p>
                </div>
              ))}
            </div>
          </Reveal>
        </div>
      </section>

      <CtaBand title="Excellence extends beyond the journey." ctaLabel="Travel With Us" />
    </>
  );
}
