import Reveal from './Reveal.jsx';
import { FLEET, FLEET_ASSURANCES } from '../data/content.js';

export default function FleetTable() {
  return (
    <>
      <Reveal className="fleet-table-wrap">
        <table className="fleet-table">
          <thead>
            <tr>
              <th scope="col">Vehicle Type</th>
              <th scope="col">Models</th>
              <th scope="col">Capacity</th>
              <th scope="col">Ideal For</th>
            </tr>
          </thead>
          <tbody>
            {FLEET.map((v) => (
              <tr key={v.type}>
                <td>{v.type}</td>
                <td>{v.models}</td>
                <td>{v.capacity}</td>
                <td>{v.idealFor}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Reveal>
      <Reveal delay={120}>
        <p className="fleet-footnote">
          {FLEET_ASSURANCES.map((a, i) => (
            <span key={a}>
              {a}
              {i < FLEET_ASSURANCES.length - 1 && <i aria-hidden="true">·</i>}
            </span>
          ))}
        </p>
      </Reveal>
    </>
  );
}
