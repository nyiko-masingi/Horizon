import { useEffect, useRef, useState } from 'react';

/**
 * Slow, confident scroll-fade — the site's signature motion.
 * Uses IntersectionObserver, with a direct viewport check on mount and a
 * scroll-event fallback so content can never be stuck invisible.
 */
export default function Reveal({ children, delay = 0, as: Tag = 'div', className = '', ...rest }) {
  const ref = useRef(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    const inView = () => {
      const r = el.getBoundingClientRect();
      return r.top < window.innerHeight - 40 && r.bottom > 0;
    };

    if (inView()) {
      setVisible(true);
      return;
    }

    let io;
    const onScroll = () => {
      if (inView()) show();
    };
    const cleanup = () => {
      io?.disconnect();
      window.removeEventListener('scroll', onScroll);
    };
    const show = () => {
      setVisible(true);
      cleanup();
    };

    if ('IntersectionObserver' in window) {
      io = new IntersectionObserver(
        ([entry]) => {
          if (entry.isIntersecting) show();
        },
        { threshold: 0.12, rootMargin: '0px 0px -40px 0px' }
      );
      io.observe(el);
    }
    window.addEventListener('scroll', onScroll, { passive: true });
    return cleanup;
  }, []);

  return (
    <Tag
      ref={ref}
      className={`reveal ${visible ? 'is-visible' : ''} ${className}`}
      style={{ '--reveal-delay': `${delay}ms` }}
      {...rest}
    >
      {children}
    </Tag>
  );
}
