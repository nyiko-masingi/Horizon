import { Link } from 'react-router-dom';
import Reveal from './Reveal.jsx';

export default function CtaBand({
  title = 'We would be honoured to be your travel partner.',
  ctaLabel = 'Reserve Your Ride',
  ctaTo = '/contact',
}) {
  return (
    <section className="cta-band">
      <div className="container">
        <Reveal>
          <h2>{title}</h2>
        </Reveal>
        <Reveal delay={150}>
          <Link to={ctaTo} className="btn btn--solid">{ctaLabel}</Link>
        </Reveal>
      </div>
    </section>
  );
}
