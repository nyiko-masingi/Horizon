using Microsoft.AspNetCore.Mvc;
using SuperlativeShuttles.Api.Models;
using SuperlativeShuttles.Api.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddSingleton<RateCardService>();
builder.Services.AddSingleton<QuoteService>();
builder.Services.AddSingleton<BookingService>();

builder.Services.AddCors(o => o.AddDefaultPolicy(p =>
    p.WithOrigins(builder.Configuration.GetSection("AllowedOrigins").Get<string[]>()
                  ?? ["http://localhost:5173"])
     .AllowAnyHeader()
     .AllowAnyMethod()));

var app = builder.Build();
app.UseCors();

// GET /api/rates/meta — zones + vehicle classes for form options and
// "from" pricing display. The frontend never hardcodes pricing.
app.MapGet("/api/rates/meta", (RateCardService rateCards) =>
{
    var card = rateCards.Current;
    return Results.Ok(new
    {
        currency = card.Currency,
        updated = card.Updated,
        zones = card.Zones.Select(z => new { z.Id, z.Name, z.Airport }),
        vehicleClasses = card.VehicleClasses.Select(v => new
        {
            v.Id,
            v.Name,
            v.Examples,
            v.MaxPassengers,
            v.HourlyRate,
            v.MinimumFare,
        }),
    });
});

// POST /api/quotes — server-side fare estimate against the rate card.
app.MapPost("/api/quotes", (QuoteRequest req, QuoteService quotes) =>
{
    try
    {
        return Results.Ok(quotes.Estimate(req));
    }
    catch (QuoteService.QuoteError e)
    {
        return Results.Json(new { error = e.Message }, statusCode: e.StatusCode);
    }
});

// POST /api/bookings — accepts a reservation request, persists it and
// triggers the confirmation email.
app.MapPost("/api/bookings", async ([FromBody] BookingRequest req, BookingService bookings) =>
{
    var ctx = new System.ComponentModel.DataAnnotations.ValidationContext(req);
    var results = new List<System.ComponentModel.DataAnnotations.ValidationResult>();
    if (!System.ComponentModel.DataAnnotations.Validator.TryValidateObject(req, ctx, results, true))
    {
        return Results.Json(
            new { error = string.Join(" ", results.Select(r => r.ErrorMessage)) },
            statusCode: 400);
    }

    var response = await bookings.SubmitAsync(req);
    return Results.Created($"/api/bookings/{response.Reference}", response);
});

app.Run();
