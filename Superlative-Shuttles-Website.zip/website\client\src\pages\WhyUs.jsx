import Hero from '../components/Hero.jsx';
import SectionHeading from '../components/SectionHeading.jsx';
import ServiceCard from '../components/ServiceCard.jsx';
import CtaBand from '../components/CtaBand.jsx';
import { DIFFERENTIATORS } from '../data/content.js';

export default function WhyUs() {
  return (
    <>
      <Hero
        page
        eyebrow="Our Difference"
        title="Why Choose Superlative Shuttles"
        sub="In a market crowded with transport providers, Superlative Shuttles stands apart through our relentless focus on the details that matter most to you."
      />

      <section className="section section--dark">
        <div className="container">
          <SectionHeading eyebrow="The Superlative Difference" title="Six Reasons Clients Stay" />
          <div className="services-grid">
            {DIFFERENTIATORS.map((d, i) => (
              <ServiceCard key={d.numeral} {...d} delay={i * 80} />
            ))}
          </div>
        </div>
      </section>

      <CtaBand />
    </>
  );
}
