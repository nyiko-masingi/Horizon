import Reveal from './Reveal.jsx';

/**
 * Full-bleed dark hero. Uses a gradient panel + subtle compass watermark in
 * place of photography until real fleet/interior shots are supplied.
 */
export default function Hero({ eyebrow, title, sub, ctas, page = false, children }) {
  return (
    <section className={`hero ${page ? 'hero--page' : ''}`}>
      <img className="hero__watermark" src="/brand/mark-white.png" alt="" aria-hidden="true" />
      <div className="container hero__inner">
        {eyebrow && (
          <Reveal>
            <p className="eyebrow">{eyebrow}</p>
          </Reveal>
        )}
        <Reveal delay={120}>
          <h1>{title}</h1>
        </Reveal>
        {sub && (
          <Reveal delay={240}>
            <p className="hero__sub">{sub}</p>
          </Reveal>
        )}
        {ctas && (
          <Reveal delay={360}>
            <div className="hero__ctas">{ctas}</div>
          </Reveal>
        )}
        {children}
      </div>
      {!page && <div className="hero__scrollhint" aria-hidden="true" />}
    </section>
  );
}
