import Reveal from './Reveal.jsx';
import { STATS } from '../data/content.js';

export default function StatsBand() {
  return (
    <section className="section section--dark" aria-label="Superlative Shuttles at a glance">
      <div className="container stats">
        {STATS.map((s, i) => (
          <Reveal key={s.label} delay={i * 90}>
            <div className="stat">
              <div className="stat__value">{s.value}</div>
              <div className="stat__label">{s.label}</div>
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
