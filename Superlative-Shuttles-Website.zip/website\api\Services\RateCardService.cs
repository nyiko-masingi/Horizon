using System.Text.Json;
using SuperlativeShuttles.Api.Models;

namespace SuperlativeShuttles.Api.Services;

/// <summary>
/// Loads Data/ratecard.json (a copy of rates/ratecard.json) and caches it,
/// re-reading when the file changes so pricing updates need no redeploy.
/// </summary>
public sealed class RateCardService
{
    private static readonly JsonSerializerOptions JsonOpts = new()
    {
        PropertyNameCaseInsensitive = true,
        ReadCommentHandling = JsonCommentHandling.Skip,
    };

    private readonly string _path;
    private readonly object _lock = new();
    private RateCard? _cached;
    private DateTime _cachedWriteTime;

    public RateCardService(IWebHostEnvironment env)
    {
        _path = Path.Combine(env.ContentRootPath, "Data", "ratecard.json");
    }

    public RateCard Current
    {
        get
        {
            var writeTime = File.GetLastWriteTimeUtc(_path);
            lock (_lock)
            {
                if (_cached is null || writeTime != _cachedWriteTime)
                {
                    _cached = JsonSerializer.Deserialize<RateCard>(File.ReadAllText(_path), JsonOpts)
                              ?? throw new InvalidOperationException("ratecard.json could not be parsed.");
                    _cachedWriteTime = writeTime;
                }
                return _cached;
            }
        }
    }
}
