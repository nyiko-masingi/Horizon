# Superlative Shuttles — Website

> *Beyond Transport. An Elevated Experience.*

The premium chauffeur/shuttle division of Superlative Solutions, Pretoria.
React frontend + ASP.NET Core Web API, with all pricing served from a single
rate-card config.

## Structure

```
website/
├── client/           React (Vite) frontend — the full site
│   ├── public/brand/ Logo variants + generated compass-mark favicons
│   └── src/
│       ├── styles/tokens.css   ← DESIGN TOKENS (palette / type / spacing)
│       ├── data/content.js     ← editorial copy (no pricing, ever)
│       ├── components/         Hero, ServiceCard, FleetTable, QuoteCalculator,
│       │                       BookingForm, StatsBand, ValuesGrid, IndustryCard, Footer…
│       └── pages/              Home, About, Services, Fleet, WhyUs, Industries,
│                               Sustainability, Rates, Contact
├── api/              ASP.NET Core 8 Web API (quotes, bookings, email notify)
│   └── Data/ratecard.json      copy of the rate card (deployed with the API)
└── rates/ratecard.json         ★ SINGLE SOURCE OF TRUTH for all pricing
```

## Running locally

```bash
cd client
npm install
npm run dev            # http://localhost:5173
```

The Vite dev server includes a middleware (`client/vite.config.js`) that
serves the same API contract (`/api/rates/meta`, `/api/quotes`,
`/api/bookings`) directly from `rates/ratecard.json` — so the quote
calculator and booking form work with **no .NET SDK installed**. Dev
bookings are appended to `website/.dev-data/bookings.json`.

### Running the real API (requires .NET 8 SDK)

```bash
cd api
dotnet run             # then set VITE_API_BASE to its URL for the client
```

> **Note:** this machine did not have the .NET SDK installed, so the API
> project is written but has not been compiled here. Run `dotnet build`
> after installing the SDK from https://dotnet.microsoft.com/download.

## Updating prices

Edit `rates/ratecard.json` only (and re-copy to `api/Data/ratecard.json`,
or make that copy your deploy artifact). Fares, zones, surcharges and the
after-hours window are all config — no layout code involved. The API
re-reads the file on change; no redeploy needed for price updates.

## Deployment (matches Superlative Solutions architecture)

- **Frontend** → Vercel/Netlify. Set `VITE_API_BASE=https://<your-api>.azurewebsites.net`.
- **API** → Azure App Service (.NET 8). Configure `Smtp__Host`, `Smtp__Username`,
  `Smtp__Password` and `AllowedOrigins` in App Service settings.

## Brand asset usage

| File | Use on |
|---|---|
| `logo-colour-transparent.png` | Light/ivory backgrounds (black wordmark) |
| `logo-mono-transparent.png` | Dark/onyx backgrounds (white wordmark) — nav & footer |
| `logo-colour-on-white.png` | Social/OG images, print |
| `mark-colour.png` / `mark-white.png` | Compass-only mark (generated crop) — favicons, watermarks |
| `favicon-32/64.png`, `icon-192/512.png` | Browser tab / mobile icons (generated) |

The compass-only favicon crop requested in the brief **has been generated**
from the supplied artwork (see `client/public/brand/`). If the designer
supplies an official fifth "mark only" file, drop it over `mark-colour.png`.

Placeholder imagery: all photography slots use branded gradient panels
labelled "Placeholder — … photography pending". Swap them for real fleet /
interior shots (WebP/AVIF) when the shoot is done.
