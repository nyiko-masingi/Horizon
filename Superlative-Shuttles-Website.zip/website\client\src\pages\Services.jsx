import { Link } from 'react-router-dom';
import Hero from '../components/Hero.jsx';
import SectionHeading from '../components/SectionHeading.jsx';
import ServiceCard from '../components/ServiceCard.jsx';
import CtaBand from '../components/CtaBand.jsx';
import { SERVICES } from '../data/content.js';

export default function Services() {
  return (
    <>
      <Hero
        page
        eyebrow="What We Offer"
        title="Portfolio of Services"
        sub="From executive transfers to large-scale conference logistics, a comprehensive suite of transport solutions — each tailored precisely to your needs."
        ctas={<Link to="/rates" className="btn btn--solid">Request a Quote</Link>}
      />

      <section className="section">
        <div className="container">
          <SectionHeading
            eyebrow="Tailored Transport"
            title="Five Ways We Elevate the Journey"
          />
          <div className="services-grid">
            {SERVICES.map((s, i) => (
              <ServiceCard key={s.numeral} {...s} delay={i * 80} />
            ))}
          </div>
        </div>
      </section>

      <CtaBand title="Tell us where you need to be — we will handle everything in between." ctaLabel="Book a Journey" />
    </>
  );
}
