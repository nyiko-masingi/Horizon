import { useEffect, useState } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';

const LINKS = [
  { to: '/about', label: 'About' },
  { to: '/services', label: 'Services' },
  { to: '/fleet', label: 'Fleet' },
  { to: '/why-us', label: 'Why Us' },
  { to: '/industries', label: 'Industries' },
  { to: '/sustainability', label: 'Sustainability' },
  { to: '/rates', label: 'Rates' },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => setOpen(false), [location.pathname]);

  return (
    <header className={`nav ${scrolled ? 'is-scrolled' : ''}`}>
      <div className="container nav__inner">
        <Link to="/" className="nav__logo" aria-label="Superlative Shuttles — home">
          {/* White-wordmark variant: the nav always sits on dark */}
          <img src="/brand/logo-mono-transparent.png" alt="Superlative Shuttles" />
        </Link>

        <nav>
          <ul id="primary-nav" className={`nav__links ${open ? 'is-open' : ''}`}>
            {LINKS.map((l) => (
              <li key={l.to}>
                <NavLink to={l.to}>{l.label}</NavLink>
              </li>
            ))}
            <li className="nav__cta">
              <Link to="/contact" className="btn btn--solid">
                Reserve Your Ride
              </Link>
            </li>
          </ul>
        </nav>

        <button
          className="nav__toggle"
          aria-expanded={open}
          aria-controls="primary-nav"
          aria-label={open ? 'Close menu' : 'Open menu'}
          onClick={() => setOpen((v) => !v)}
        >
          {open ? '✕' : '☰'}
        </button>
      </div>
    </header>
  );
}
