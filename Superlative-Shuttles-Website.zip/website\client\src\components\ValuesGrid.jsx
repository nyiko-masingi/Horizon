import Reveal from './Reveal.jsx';
import { VALUES } from '../data/content.js';

export default function ValuesGrid() {
  return (
    <div className="values-grid">
      {VALUES.map((v, i) => (
        <Reveal key={v.title} delay={i * 70}>
          <article className="value-card">
            <h3>{v.title}</h3>
            <p>{v.copy}</p>
          </article>
        </Reveal>
      ))}
    </div>
  );
}
