import Hero from '../components/Hero.jsx';
import Reveal from '../components/Reveal.jsx';
import SectionHeading from '../components/SectionHeading.jsx';
import FleetTable from '../components/FleetTable.jsx';
import CtaBand from '../components/CtaBand.jsx';
import { DRIVER_STANDARDS, VEHICLE_FEATURES } from '../data/content.js';

export default function Fleet() {
  return (
    <>
      <Hero
        page
        eyebrow="Our Vehicles"
        title="The Superlative Fleet"
        sub="Curated with one philosophy: every vehicle must reflect the standard our clients deserve. We invest continuously in newer models, ensuring comfort, safety and style travel together on every journey."
      />

      <section className="section">
        <div className="container">
          <SectionHeading eyebrow="Fleet Categories" title="A Vehicle for Every Occasion" />
          <FleetTable />

          <div className="split" style={{ marginTop: 'var(--space-6)' }}>
            <Reveal>
              <div className="photo-placeholder">
                <span>Placeholder — BMW 3 Series exterior, golden hour</span>
              </div>
            </Reveal>
            <Reveal delay={140}>
              <div className="photo-placeholder">
                <span>Placeholder — leather interior detail, V-Class</span>
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      <section className="section section--dark" style={{ paddingTop: 'var(--space-5)' }}>
        <div className="container">
          <SectionHeading
            eyebrow="The Standard"
            title="Drivers & Vehicles, Held to the Same Bar"
          />
          <div className="feature-grids">
            <Reveal>
              <div className="feature-list">
                <h3>Driver Standards</h3>
                <ul>
                  {DRIVER_STANDARDS.map((d) => (
                    <li key={d}>{d}</li>
                  ))}
                </ul>
              </div>
            </Reveal>
            <Reveal delay={130}>
              <div className="feature-list">
                <h3>Vehicle Features</h3>
                <ul>
                  {VEHICLE_FEATURES.map((f) => (
                    <li key={f}>{f}</li>
                  ))}
                </ul>
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      <CtaBand title="Choose the vehicle. We will perfect the journey." ctaLabel="Get a Fare Estimate" ctaTo="/rates" />
    </>
  );
}
