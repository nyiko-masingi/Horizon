import Hero from '../components/Hero.jsx';
import SectionHeading from '../components/SectionHeading.jsx';
import IndustryCard from '../components/IndustryCard.jsx';
import CtaBand from '../components/CtaBand.jsx';
import { INDUSTRIES } from '../data/content.js';

export default function Industries() {
  return (
    <>
      <Hero
        page
        eyebrow="Our Experience"
        title="Industries & Clients We Serve"
        sub="The same commitment to excellence, whether we are moving a single executive or coordinating logistics for a large-scale event."
      />

      <section className="section section--dark">
        <div className="container">
          <SectionHeading eyebrow="Trusted Across Sectors" title="A Reputation Built Mile by Mile" />
          <div className="industries-grid">
            {INDUSTRIES.map((ind, i) => (
              <IndustryCard key={ind.title} {...ind} delay={i * 80} />
            ))}
          </div>
        </div>
      </section>

      <CtaBand title="Whatever your industry, arrive in the right impression." ctaLabel="Discuss Your Requirements" />
    </>
  );
}
