namespace SuperlativeShuttles.Api.Models;

/// <summary>
/// Strongly-typed mirror of rates/ratecard.json — the single source of truth
/// for all pricing. Update the JSON, never the code, to change fares.
/// </summary>
public sealed class RateCard
{
    public string Currency { get; set; } = "ZAR";
    public string Updated { get; set; } = string.Empty;
    public int EstimateSpreadPercent { get; set; } = 8;
    public List<VehicleClass> VehicleClasses { get; set; } = [];
    public List<Zone> Zones { get; set; } = [];
    public DistanceModel DistanceModel { get; set; } = new();
    public Surcharges Surcharges { get; set; } = new();
}

public sealed class VehicleClass
{
    public string Id { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string Examples { get; set; } = string.Empty;
    public int MaxPassengers { get; set; }
    public decimal BaseFare { get; set; }
    public decimal PerKm { get; set; }
    public decimal HourlyRate { get; set; }
    public decimal MinimumFare { get; set; }
}

public sealed class Zone
{
    public string Id { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public double Lat { get; set; }
    public double Lng { get; set; }
    public bool Airport { get; set; }
}

public sealed class DistanceModel
{
    public double RoadFactor { get; set; } = 1.32;
    public int MinimumKm { get; set; } = 8;
}

public sealed class Surcharges
{
    public decimal AirportPickup { get; set; }
    public AfterHours AfterHours { get; set; } = new();
}

public sealed class AfterHours
{
    public decimal Rate { get; set; }
    public string From { get; set; } = "21:00";
    public string To { get; set; } = "05:00";
}
