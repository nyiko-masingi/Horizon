import Hero from '../components/Hero.jsx';
import Reveal from '../components/Reveal.jsx';
import SectionHeading from '../components/SectionHeading.jsx';
import ValuesGrid from '../components/ValuesGrid.jsx';
import CtaBand from '../components/CtaBand.jsx';
import { STORY, APPROACH, MVP } from '../data/content.js';

export default function About() {
  return (
    <>
      <Hero
        page
        eyebrow="Who We Are"
        title="About Superlative Shuttles"
        sub="The gap between ordinary and extraordinary transport is not about the vehicle — it is about the experience."
      />

      <section className="section">
        <div className="container split">
          <div>
            <SectionHeading eyebrow="Our Story" title="Founded on a Single Conviction" />
            <Reveal delay={140}>
              <div className="prose" style={{ marginTop: 'var(--space-4)' }}>
                {STORY.map((p, i) => (
                  <p key={i}>{p}</p>
                ))}
              </div>
            </Reveal>
          </div>
          <Reveal delay={200}>
            <div className="photo-placeholder" style={{ minHeight: 460 }}>
              <span>Placeholder — chauffeur &amp; E-Class photography pending</span>
            </div>
          </Reveal>
        </div>
      </section>

      <section className="section" style={{ paddingTop: 0 }}>
        <div className="container">
          <SectionHeading eyebrow="Our Approach" title="How We Work" />
          <div className="approach-grid">
            {APPROACH.map((a, i) => (
              <Reveal key={a.title} delay={i * 90}>
                <article className="value-card">
                  <h3>{a.title}</h3>
                  <p>{a.copy}</p>
                </article>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="section section--dark">
        <div className="container">
          <SectionHeading
            eyebrow="Core Pillars"
            title="Mission, Vision & Philosophy"
            lede="The principles behind every journey."
          />
          <div className="mvp-stack">
            {MVP.map((m, i) => (
              <Reveal key={m.title} delay={i * 110}>
                <article className="mvp-panel">
                  <h3>{m.title}</h3>
                  <p>{m.copy}</p>
                </article>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <SectionHeading
            eyebrow="Our Values"
            title="What We Stand For"
          />
          <ValuesGrid />
        </div>
      </section>

      <CtaBand />
    </>
  );
}
