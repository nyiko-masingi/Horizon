import { Link } from 'react-router-dom';
import { CONTACT, SIGNOFF } from '../data/content.js';

export default function Footer() {
  return (
    <footer className="footer">
      <div className="container footer__grid">
        <div className="footer__brand">
          {/* White-wordmark variant on the dark footer */}
          <img src="/brand/logo-mono-transparent.png" alt="Superlative Shuttles" />
          <p>
            Premier South African luxury transport — redefining the travel experience for the
            country’s most discerning individuals, corporations and institutions.
          </p>
        </div>

        <div>
          <h4>Explore</h4>
          <ul>
            <li><Link to="/about">About Us</Link></li>
            <li><Link to="/services">Services</Link></li>
            <li><Link to="/fleet">Our Fleet</Link></li>
            <li><Link to="/why-us">Why Choose Us</Link></li>
            <li><Link to="/industries">Industries We Serve</Link></li>
            <li><Link to="/sustainability">Sustainability</Link></li>
          </ul>
        </div>

        <div>
          <h4>Reserve</h4>
          <ul>
            <li><Link to="/rates">Rates & Quotes</Link></li>
            <li><Link to="/contact">Book a Journey</Link></li>
            <li><a href={CONTACT.whatsappHref} target="_blank" rel="noreferrer">WhatsApp Reservations</a></li>
            <li><a href={`mailto:${CONTACT.email}`}>{CONTACT.email}</a></li>
          </ul>
        </div>

        <div>
          <h4>Get in Touch</h4>
          <ul className="footer__contact">
            <li><strong>Central Reservations</strong><br /><a href={CONTACT.reservationsHref}>{CONTACT.reservations}</a></li>
            <li><strong>24-Hour Emergency</strong><br /><a href={CONTACT.emergencyHref}>{CONTACT.emergency}</a></li>
            <li><strong>Office</strong><br />{CONTACT.office}</li>
            <li><strong>{CONTACT.social}</strong><br />{CONTACT.socials.join(' · ')}</li>
          </ul>
        </div>
      </div>

      <div className="container footer__bottom">
        <span className="footer__signoff">{SIGNOFF}</span>
        <span>Superlative Shuttles (Pty) Ltd · South Africa · © 2026 All Rights Reserved</span>
      </div>
    </footer>
  );
}
