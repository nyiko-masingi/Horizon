import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import Hero from '../components/Hero.jsx';
import Reveal from '../components/Reveal.jsx';
import SectionHeading from '../components/SectionHeading.jsx';
import QuoteCalculator from '../components/QuoteCalculator.jsx';
import { getRatesMeta } from '../lib/api.js';
import { CONTACT } from '../data/content.js';

const fmt = (n, currency = 'ZAR') =>
  new Intl.NumberFormat('en-ZA', { style: 'currency', currency, maximumFractionDigits: 0 }).format(n);

export default function Rates() {
  const [meta, setMeta] = useState(null);

  useEffect(() => {
    getRatesMeta().then(setMeta).catch(() => setMeta(null));
  }, []);

  return (
    <>
      <Hero
        page
        eyebrow="Transparent Pricing"
        title="Rates & Instant Estimates"
        sub="No hidden fees. No surprises. Clear, upfront quotes we honour — because trust is the foundation of every great partnership."
      />

      <section className="section">
        <div className="container">
          <SectionHeading
            eyebrow="Fare Estimator"
            title="Estimate Your Journey"
            lede="Choose your route and vehicle class for a live estimate, calculated against our current rate card. Your final quotation is confirmed by our reservations team before every trip."
          />

          <div className="rates-layout">
            <Reveal>
              <QuoteCalculator />
            </Reveal>

            <Reveal delay={140}>
              <div className="rate-summary">
                {(meta?.vehicleClasses || []).map((v) => (
                  <div className="rate-summary__card" key={v.id}>
                    <div>
                      <h4>{v.name}</h4>
                      <p>{v.examples} · up to {v.maxPassengers} pax</p>
                    </div>
                    <div className="rate-summary__price">
                      {fmt(v.hourlyRate, meta.currency)}
                      <small>per hour, from</small>
                    </div>
                  </div>
                ))}
                {!meta && (
                  <p className="form-note">
                    Live rate card unavailable — call {CONTACT.reservations} for pricing.
                  </p>
                )}
              </div>
            </Reveal>
          </div>

          <Reveal delay={120}>
            <div className="corp-band">
              <div>
                <p className="eyebrow" style={{ marginBottom: '0.4rem' }}>Corporate Accounts</p>
                <h3>Moving executives regularly?</h3>
                <p>
                  Dedicated vehicles, bespoke daily shuttle routes, consolidated monthly billing and a
                  named account manager. Corporate rates are structured separately from individual fares.
                </p>
              </div>
              <Link
                to="/contact"
                state={{ corporate: true }}
                className="btn btn--ghost"
              >
                Enquire About Corporate Accounts
              </Link>
            </div>
          </Reveal>
        </div>
      </section>
    </>
  );
}
