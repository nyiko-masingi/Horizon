import { useEffect, useState } from 'react';
import { getRatesMeta, submitBooking } from '../lib/api.js';
import { CONTACT } from '../data/content.js';

const EMPTY = {
  fullName: '',
  email: '',
  phone: '',
  date: '',
  time: '',
  pickup: '',
  dropoff: '',
  vehicleClassId: '',
  passengers: 1,
  specialRequests: '',
};

function validate(form) {
  const errors = {};
  if (!form.fullName.trim()) errors.fullName = 'Please enter your full name.';
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(form.email)) errors.email = 'Please enter a valid email address.';
  if (!/^[+\d][\d\s()-]{7,}$/.test(form.phone.trim())) errors.phone = 'Please enter a valid phone number.';
  if (!form.date) errors.date = 'Please choose a travel date.';
  if (!form.time) errors.time = 'Please choose a pickup time.';
  if (!form.pickup.trim()) errors.pickup = 'Please enter a pickup address.';
  if (!form.dropoff.trim()) errors.dropoff = 'Please enter a drop-off address.';
  if (!form.vehicleClassId) errors.vehicleClassId = 'Please select a vehicle class.';
  if (!form.passengers || Number(form.passengers) < 1) errors.passengers = 'At least one passenger.';
  return errors;
}

export default function BookingForm() {
  const [meta, setMeta] = useState(null);
  const [form, setForm] = useState(EMPTY);
  const [errors, setErrors] = useState({});
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState(null);
  const [submitError, setSubmitError] = useState('');

  useEffect(() => {
    getRatesMeta().then(setMeta).catch(() => setMeta({ vehicleClasses: [] }));
  }, []);

  const set = (k) => (e) => {
    setForm((f) => ({ ...f, [k]: e.target.value }));
    setErrors((er) => ({ ...er, [k]: undefined }));
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    setSubmitError('');
    const errs = validate(form);
    setErrors(errs);
    if (Object.keys(errs).length) return;
    setBusy(true);
    try {
      const res = await submitBooking({ ...form, passengers: Number(form.passengers) });
      setResult(res);
    } catch (err) {
      setSubmitError(err.message);
    } finally {
      setBusy(false);
    }
  };

  if (result) {
    return (
      <div className="form-panel booking-success" aria-live="polite">
        <p className="eyebrow">Reservation Received</p>
        <h3>Thank you — your journey is in motion.</h3>
        <p className="ref">{result.reference}</p>
        <p style={{ marginTop: '1rem', maxWidth: '48ch', marginInline: 'auto' }}>{result.message}</p>
        <a className="whatsapp-cta" href={CONTACT.whatsappHref} target="_blank" rel="noreferrer">
          Chat to Reservations on WhatsApp
        </a>
      </div>
    );
  }

  const field = (key, label, input) => (
    <div className="form-field">
      <label htmlFor={`b-${key}`}>{label}</label>
      {input}
      {errors[key] && <span className="field-error" role="alert">{errors[key]}</span>}
    </div>
  );

  return (
    <form className="form-panel" onSubmit={onSubmit} noValidate>
      <div className="form-grid">
        {field('fullName', 'Full Name', (
          <input id="b-fullName" type="text" autoComplete="name" value={form.fullName} onChange={set('fullName')} required />
        ))}
        {field('phone', 'Phone', (
          <input id="b-phone" type="tel" autoComplete="tel" placeholder="+27…" value={form.phone} onChange={set('phone')} required />
        ))}
        <div className="form-field form-field--full">
          <label htmlFor="b-email">Email</label>
          <input id="b-email" type="email" autoComplete="email" value={form.email} onChange={set('email')} required />
          {errors.email && <span className="field-error" role="alert">{errors.email}</span>}
        </div>
        {field('date', 'Date', (
          <input id="b-date" type="date" value={form.date} onChange={set('date')} required />
        ))}
        {field('time', 'Pickup Time', (
          <input id="b-time" type="time" value={form.time} onChange={set('time')} required />
        ))}
        {field('pickup', 'Pickup Address', (
          <input id="b-pickup" type="text" placeholder="e.g. O.R. Tambo International, Terminal A" value={form.pickup} onChange={set('pickup')} required />
        ))}
        {field('dropoff', 'Drop-off Address', (
          <input id="b-dropoff" type="text" placeholder="e.g. 44 Hamilton Street, Arcadia" value={form.dropoff} onChange={set('dropoff')} required />
        ))}
        {field('vehicleClassId', 'Vehicle Class', (
          <select id="b-vehicleClassId" value={form.vehicleClassId} onChange={set('vehicleClassId')} required>
            <option value="">Select vehicle…</option>
            {(meta?.vehicleClasses || []).map((v) => (
              <option key={v.id} value={v.id}>{v.name} — up to {v.maxPassengers} pax</option>
            ))}
          </select>
        ))}
        {field('passengers', 'Passengers', (
          <input id="b-passengers" type="number" min="1" max="65" value={form.passengers} onChange={set('passengers')} required />
        ))}
        <div className="form-field form-field--full">
          <label htmlFor="b-special">Special Requests (optional)</label>
          <textarea
            id="b-special"
            rows="4"
            placeholder="Flight number, child seat, refreshments, multiple stops…"
            value={form.specialRequests}
            onChange={set('specialRequests')}
          />
        </div>
      </div>

      <div className="form-actions">
        <button className="btn btn--solid" type="submit" disabled={busy}>
          {busy ? 'Sending…' : 'Request Reservation'}
        </button>
        <span className="form-note">
          Confirmed by our reservations team — {CONTACT.hours.toLowerCase()}.
        </span>
      </div>

      {submitError && <div className="form-alert form-alert--error" role="alert">{submitError}</div>}
    </form>
  );
}
