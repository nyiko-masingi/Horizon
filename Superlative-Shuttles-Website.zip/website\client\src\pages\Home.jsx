import { Link } from 'react-router-dom';
import Hero from '../components/Hero.jsx';
import Reveal from '../components/Reveal.jsx';
import SectionHeading from '../components/SectionHeading.jsx';
import StatsBand from '../components/StatsBand.jsx';
import ServiceCard from '../components/ServiceCard.jsx';
import FleetTable from '../components/FleetTable.jsx';
import CtaBand from '../components/CtaBand.jsx';
import { SERVICES, DIFFERENTIATORS, TAGLINE } from '../data/content.js';

const WHY_PREVIEW = [DIFFERENTIATORS[0], DIFFERENTIATORS[2], DIFFERENTIATORS[4]];

export default function Home() {
  return (
    <>
      <Hero
        eyebrow="Pretoria · South Africa"
        title={
          <>
            Beyond Transport. <em>An Elevated Experience.</em>
          </>
        }
        sub="Premier luxury chauffeur and shuttle services for South Africa's most discerning individuals, corporations and institutions — every booking a privilege, every client a VIP."
        ctas={
          <>
            <Link to="/contact" className="btn btn--solid">Reserve Your Ride</Link>
            <Link to="/rates" className="btn btn--ghost">Request a Quote</Link>
          </>
        }
      />

      <div className="trust-strip">
        <div className="container trust-strip__inner">
          <span>Luxury</span>
          <i aria-hidden="true">◆</i>
          <span>Precision</span>
          <i aria-hidden="true">◆</i>
          <span>Excellence</span>
        </div>
      </div>

      <StatsBand />

      <section className="section">
        <div className="container">
          <SectionHeading
            eyebrow="What We Offer"
            title="A Portfolio of Services"
            lede="From executive transfers to large-scale conference logistics — a comprehensive suite of transport solutions, each tailored precisely to your needs."
          />
          <div className="services-grid">
            {SERVICES.map((s, i) => (
              <ServiceCard key={s.numeral} {...s} delay={i * 80} />
            ))}
          </div>
          <Reveal delay={200}>
            <div className="form-actions" style={{ justifyContent: 'center' }}>
              <Link to="/services" className="btn btn--ghost-dark">Explore All Services</Link>
            </div>
          </Reveal>
        </div>
      </section>

      <section className="section section--dark">
        <div className="container">
          <SectionHeading
            eyebrow="Our Difference"
            title="Why Choose Superlative Shuttles"
            lede="In a market crowded with transport providers, we stand apart through a relentless focus on the details that matter most to you."
          />
          <div className="services-grid">
            {WHY_PREVIEW.map((d, i) => (
              <ServiceCard key={d.numeral} {...d} delay={i * 90} />
            ))}
          </div>
          <Reveal delay={200}>
            <div className="form-actions" style={{ justifyContent: 'center' }}>
              <Link to="/why-us" className="btn btn--ghost">See All Six Reasons</Link>
            </div>
          </Reveal>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <SectionHeading
            eyebrow="Our Vehicles"
            title="The Superlative Fleet"
            lede="Every vehicle must reflect the standard our clients deserve — comfort, safety and style travelling together on every journey."
          />
          <FleetTable />
          <Reveal delay={160}>
            <div className="form-actions" style={{ justifyContent: 'center' }}>
              <Link to="/fleet" className="btn btn--ghost-dark">Discover the Fleet</Link>
            </div>
          </Reveal>
        </div>
      </section>

      <CtaBand />
    </>
  );
}
